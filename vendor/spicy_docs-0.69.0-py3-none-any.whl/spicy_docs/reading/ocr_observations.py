"""Bind unplaced OCR text to an exact, measured source-image region.

Source readers decide which rows a region contains and how to associate them.
These shared objects retain input identity without assigning model geometry.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass

from spicy_docs.extraction import Box, Raster
from spicy_docs.extraction.model import Observation, Recognition
from spicy_docs.extraction.pages import crop


def evidence_sha256(data):
    return "sha256:" + hashlib.sha256(data).hexdigest()


def box_coordinates(box):
    return [box.x0, box.y0, box.x1, box.y1]


@dataclass(frozen=True)
class OcrRegion:
    id: str
    raster: Raster
    row_ids: tuple[str, ...]
    field_block_index: int | None = None


@dataclass(frozen=True)
class OcrView:
    region: OcrRegion
    reading: Recognition | Observation

    @property
    def text(self):
        """Keep Docling's original VLM lines before Markdown conversion."""
        raw = self.reading.raw
        if isinstance(raw, dict) and "pages" in raw:
            pages = raw["pages"]
            if len(pages) != 1:
                raise ValueError("An OCR view must contain exactly one model page")
            response = pages[0].get("predictions", {}).get("vlm_response")
            if response is not None:
                return response["text"]
        if self.reading.text_format != "plain":
            raise ValueError("OCR association requires original plain model lines")
        return self.reading.text

    @property
    def evidence(self):
        return {
            "id": self.region.id,
            "input_sha256": evidence_sha256(self.region.raster.data),
            "response_text_sha256": evidence_sha256(self.text.encode()),
            "configuration_sha256": evidence_sha256(
                json.dumps(self.reading.configuration, sort_keys=True, separators=(",", ":")).encode()
            ),
            "region": box_coordinates(self.region.raster.box),
            "model_geometry": None,
        }


def validate_view_image(image, view):
    """Refuse claimed regions whose actual pixels differ from the source crop."""
    raster = view.region.raster
    expected = image if raster.box == Box() else crop(image, raster.box)
    if expected.data != raster.data or (expected.width, expected.height) != (raster.width, raster.height):
        raise ValueError("OCR view bytes do not match its claimed original-image crop")
