"""Read reviewed House ledger field roles without inventing native geometry.

The caller first replays the retained capture with ``ocr_observations``. A
separate original-image review binds the complete row/cell membership, printed
roles and known context. Text that was not independently transcribed remains
explicitly unqualified. This reader does not infer office continuity or payees.
"""

import hashlib
import json
import re
from copy import deepcopy
from datetime import date
from decimal import Decimal

from spicy_docs.reading.house_disbursements_pdf import expand_house_ditto_payee, normalize_house_fields
from spicy_docs.reading.ocr_observations import apply_reviewed_observation_fields
from spicy_docs.schemas.senate_expenditure_tables import parse_amount

RULE = "house-disbursement-reviewed-observation/1"
METHOD = "reviewed_structured_observation"
QUALIFICATION = "reviewed-house-ledger-observation/1"
STATUS = "reviewed_fields_with_unresolved_text_or_context"
RAW_FIELDS = (
    "transaction_date",
    "data_source",
    "document",
    "vendor_name",
    "service_start_date",
    "service_end_date",
    "description",
    "ytd_amount",
    "qtd_amount",
)
CONTEXT_FIELDS = ("organizational_group", "organization", "fiscal_or_legislative_year", "program", "cost_category")
ROW_KINDS = {"transaction", "summary", "subtotal", "organization_total"}


def _digest(value):
    return "sha256:" + hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _amount(value):
    if value is None or value == "":
        return None
    amount = parse_amount(value.replace("–", "-").replace("−", "-"))
    if amount is None:
        raise ValueError("Reviewed House money cell is not an exact monetary literal")
    formatted = format(amount, ".2f")
    if Decimal(formatted) != amount:
        raise ValueError("Reviewed House money cell cannot be represented exactly in cents")
    return formatted


def _payee_witness(item, qualification, position, raw, kind, records):
    witness = item.get("payee_witness")
    if witness is None:
        return None
    target = {
        "source_sha256": qualification["source_sha256"],
        "page": qualification["page"],
        "table": item["table"],
        "row": item["row"],
    }
    if (
        kind != "transaction"
        or raw["vendor_name"] != "DO"
        or not isinstance(witness, dict)
        or set(witness) != {"value", "target", "origin", "review_evidence"}
        or not isinstance(witness["value"], str)
        or witness["target"] != target
        or any(type(witness["target"][key]) is not int for key in ("page", "table", "row"))
    ):
        raise ValueError("Reviewed payee witness must name this exact printed DO occurrence")
    origin = witness["origin"]
    if (
        not isinstance(origin, dict)
        or set(origin) != {"method", "source_sha256", "page", "visual_row", "locator"}
        or origin["method"] != "reviewed_source_predecessor"
        or not isinstance(origin["source_sha256"], str)
        or re.fullmatch(r"sha256:[0-9a-f]{64}", origin["source_sha256"]) is None
        or origin["source_sha256"] != target["source_sha256"]
        or type(origin["page"]) is not int
        or origin["page"] < 1
        or not isinstance(origin["locator"], str)
        or not origin["locator"].strip()
        or (origin["visual_row"] is not None and (type(origin["visual_row"]) is not int or origin["visual_row"] < 1))
    ):
        raise ValueError("Reviewed payee witness requires an original-page predecessor locator")
    if origin["page"] > target["page"] or (
        origin["page"] == target["page"] and (origin["visual_row"] is None or origin["visual_row"] >= position)
    ):
        raise ValueError("Reviewed payee witness must precede this source occurrence")
    if origin["page"] == target["page"]:
        prior = records[origin["visual_row"] - 1]
        if (
            prior["raw_fields"]["vendor_name"] in (None, "", "DO")
            or witness["value"] != prior["raw_fields"]["vendor_name"]
        ):
            raise ValueError("Reviewed payee witness contradicts its bound explicit predecessor")
        for index in range(origin["visual_row"] - 1, position - 1):
            earlier = records[index]
            if (
                earlier["row_kind"] != "transaction"
                or any(earlier[key] != item["context"][key] for key in CONTEXT_FIELDS)
                or (index >= origin["visual_row"] and earlier["raw_fields"]["vendor_name"] != "DO")
            ):
                raise ValueError("Reviewed payee witness crosses an intervening name, blank or account scope")
    evidence = witness["review_evidence"]
    if (
        not isinstance(evidence, list)
        or not evidence
        or any(ref not in qualification["review_evidence"] for ref in evidence)
    ):
        raise ValueError("Reviewed payee witness evidence must be retained with the qualification")
    return {
        "value": witness["value"],
        "origin": {**deepcopy(origin), "target": target, "review_evidence": deepcopy(evidence)},
    }


def _records(outcome, qualification):
    selected = qualification["rows"]
    if not selected or any(type(item[key]) is not int for item in selected for key in ("table", "row")):
        raise ValueError("Reviewed House field map requires explicit integer row coordinates")
    coordinates = [(table, row) for table, grid in enumerate(outcome["tables"]) for row in range(len(grid["rows"]))]
    if [(item["table"], item["row"]) for item in selected] != coordinates:
        raise ValueError("Reviewed House field map omits, repeats or reorders an observed row")
    period = tuple(date.fromisoformat(qualification[key]) for key in ("report_period_start", "report_period_end"))
    records = []
    for position, item in enumerate(selected, 1):
        table, number = item["table"], item["row"]
        observed = outcome["tables"][table]["rows"][number]
        fields, kind = item["fields"], item["row_kind"]
        if (
            kind not in ROW_KINDS
            or not item.get("source_role")
            or any(type(field["cell"]) is not int for field in fields)
            or [field["cell"] for field in fields] != list(range(len(observed["cells"])))
            or len({field["field"] for field in fields}) != len(fields)
            or any(field["field"] not in RAW_FIELDS for field in fields)
        ):
            raise ValueError("Reviewed House field map has invalid roles or cell membership")
        raw = dict.fromkeys(RAW_FIELDS)
        for field in fields:
            literal = observed["cells"][field["cell"]]
            if not isinstance(literal, str) or field["literal"] != literal:
                raise ValueError("Reviewed House field differs from its exact observed literal")
            raw[field["field"]] = literal
        context = item["context"]
        if set(context) != set(CONTEXT_FIELDS) or any(
            value is not None and not isinstance(value, str) for value in context.values()
        ):
            raise ValueError("Reviewed House context requires explicit known or unresolved fields")
        values, issues = normalize_house_fields(
            raw, row_kind=kind, period=period, century=qualification["two_digit_year_century"]
        )
        ytd, qtd = _amount(raw["ytd_amount"]), _amount(raw["qtd_amount"])
        if ytd is None and qtd is None:
            raise ValueError("Reviewed House financial row contains no printed amount")
        if kind == "transaction" and (qtd is None or ytd is not None):
            raise ValueError("Reviewed House transaction requires its quarterly amount and blank YTD")
        prior = _payee_witness(item, qualification, position, raw, kind, records)
        if prior is not None:
            # Normalize a reviewed source literal once. Native state already
            # contains a normalized predecessor, so the shared expansion itself
            # must preserve that value without cleaning it again.
            predecessor_values, _ = normalize_house_fields(
                {"vendor_name": prior["value"]},
                row_kind="summary",
                period=period,
                century=qualification["two_digit_year_century"],
            )
            prior["value"] = predecessor_values["vendor_name"]
        normalizations = []
        if raw["vendor_name"] == "DO":
            values["vendor_name"], normalizations = expand_house_ditto_payee(prior)
            if prior is None:
                issues.append("ditto_payee_unresolved_in_observation")
        required_context = CONTEXT_FIELDS if kind == "transaction" else CONTEXT_FIELDS[:3]
        for key in required_context:
            if context[key] is None:
                issues.append(key + "_context_unresolved")
        if not isinstance(item.get("issues"), list) or any(not isinstance(issue, str) for issue in item["issues"]):
            raise ValueError("Reviewed House row must retain its source-review issues")
        records.append(
            {
                "line": None,
                "row_kind": kind,
                "source_role": item["source_role"],
                **context,
                **values,
                "amount": qtd if kind == "transaction" else None,
                "ytd_amount": ytd,
                "qtd_amount": qtd,
                "raw_fields": raw,
                "word_indices": None,
                "office_origin": None,
                "normalizations": normalizations,
                "repairs": [],
                "source_origin": {
                    "method": METHOD,
                    "table": table,
                    "row": number,
                    "visual_row": position,
                    "fields": deepcopy(fields),
                    "geometry": None,
                },
                "issues": list(dict.fromkeys(["text_not_fully_source_qualified", *item["issues"], *issues])),
            }
        )
    return records


def read_house_ledger_observation(outcome, *, binding, qualification, configuration):
    """Map an offline-replayed observation using an independently reviewed field map.

    The host checks the original, capture and review file pins. This function
    checks exact observation identity, applies the shared reviewed corrections,
    and preserves all row/cell occurrences. It grants no full-page qualification.
    """
    if (
        qualification.get("schema") != QUALIFICATION
        or qualification.get("status") != STATUS
        or not qualification.get("review_evidence")
        or qualification.get("binding") != binding
        or any(qualification.get(key) != binding.get(key) for key in ("source_sha256", "source_byte_size", "page"))
        or qualification.get("raw_outcome_sha256") != _digest(outcome)
        or type(binding.get("page")) is not int
        or not 1 <= binding["page"] <= qualification["physical_pages"]
    ):
        raise ValueError("House observation differs from its reviewed identity or scope")
    normalized, audit = apply_reviewed_observation_fields(
        outcome,
        binding=binding,
        corrections=qualification.get("corrections", []),
    )
    if qualification["normalized_outcome_sha256"] != _digest(normalized):
        raise ValueError("House observation differs from its reviewed corrected outcome")
    records = _records(normalized, qualification)
    issues = ["text_not_fully_source_qualified"]
    if any(
        issue.endswith("_context_unresolved") or issue == "ditto_payee_unresolved_in_observation"
        for record in records
        for issue in record["issues"]
    ):
        issues.append("context_requires_original_continuity")
    return {
        "rule": RULE,
        "reading_method": METHOD,
        "source_sha256": binding["source_sha256"],
        "source_byte_size": binding["source_byte_size"],
        "page": binding["page"],
        "source_page": binding["page"],
        "physical_pages": qualification["physical_pages"],
        "printed_page": normalized["page_label"],
        "header": None,
        "header_basis": "independent_source_field_review",
        "records": records,
        "issues": issues,
        "status": STATUS,
        "structured_observation": deepcopy(outcome),
        "normalized_observation": normalized,
        "observation_corrections": audit,
        "structured_provenance": {
            "qualification": deepcopy(qualification),
            "binding": deepcopy(binding),
            "configuration": deepcopy(configuration),
            "geometry": None,
        },
    }


def validate_house_ledger_observation(page):
    """Reconstruct exact field membership; the host also replays the capture bytes."""
    provenance = page["structured_provenance"]
    expected = read_house_ledger_observation(
        page["structured_observation"],
        binding=provenance["binding"],
        qualification=provenance["qualification"],
        configuration=provenance["configuration"],
    )
    if page != expected:
        raise ValueError("House structured ledger differs from its retained observation and reviewed fields")
