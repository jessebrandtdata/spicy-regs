"""Bounded exact HTTP captures shared by source-specific acquisition clients.

Source modules choose URLs, validate identities and decide fallback. This client
owns request counts, pacing and complete response bytes; it never persists them.
Install spicy-docs[acquisition] to use its optional HTTPX dependency.
"""

from __future__ import annotations

import time
from collections.abc import Callable, Iterator, Mapping
from contextlib import closing, contextmanager
from dataclasses import dataclass
from datetime import datetime

import httpx

from spicy_docs.reading.refusals import RefusedResponse, attach_refused_response
from spicy_docs.transport.bounded import bounded_response_chunks
from spicy_docs.transport.byte_range import content_range
from spicy_docs.transport.captured import CapturedBodyResponse, attach_capture, observed_instant, refused_capture
from spicy_docs.transport.credentials import CredentialRefusedError
from spicy_docs.transport.http import RetryableHTTPStatusError
from spicy_docs.transport.retry import retry_after_seconds, retry_http


@dataclass
class _TraversalAllocation:
    max_requests: int
    max_wait_seconds: float
    requests: int = 0
    waited_seconds: float = 0.0


class _RetryableTransportError(ConnectionError):
    """Transport failed without copying arbitrary provider text into logs."""


def _evidence_media_type(response: httpx.Response) -> str:
    """The media type raw evidence bytes are: the stated one, unless the body is encoded."""
    if response.headers.get("content-encoding", "identity").strip().lower() != "identity":
        # Raw encoded bytes are evidence, not the decoded format named by the header.
        return "application/octet-stream"
    return (response.headers.get("content-type") or "application/octet-stream").split(";", 1)[0]


def _stated_length(response: httpx.Response) -> int | None:
    """The response's ``Content-Length`` as an integer, or ``None`` when it states none or an invalid one."""
    stated = response.headers.get("content-length")
    return int(stated) if stated is not None and stated.isascii() and stated.isdigit() else None


def _check_byte_range(
    response: httpx.Response, requested: tuple[int, int], size: int, error_type: type[ValueError]
) -> None:
    """A ranged answer must be ``206`` stating exactly the requested positions, and carry exactly that many bytes."""
    if response.status_code != 206:
        raise error_type(f"Body source answered HTTP {response.status_code} to a byte-range request")
    stated = content_range(response.headers.get("content-range"))
    first, last = requested
    if stated is None or stated[:2] != requested or stated[2] <= last:
        raise error_type("Body source Content-Range differs from the requested byte range")
    if size != last - first + 1:
        raise error_type("Body source byte-range response size differs from the requested range")


def _access_refusal(response: httpx.Response, url: str, max_bytes: int) -> RefusedResponse:
    """Retain complete bounded raw evidence for a 401/403; a failed read marks it unavailable, never absent."""
    media_type = _evidence_media_type(response)
    body = bytearray()
    try:
        for chunk in response.iter_raw(chunk_size=min(max_bytes + 1, 64 * 1024)):
            observed = len(body) + len(chunk)
            if observed > max_bytes:
                return RefusedResponse(
                    url, "transport", None, media_type, "response-byte-limit", observed, _stated_length(response)
                )
            body.extend(chunk)
    except httpx.RequestError:
        return RefusedResponse(url, "transport", None, media_type, "response-unavailable", len(body))
    return RefusedResponse(url, "transport", bytes(body), media_type, "access-refused", len(body))


class BoundedHttpCapture:
    """One sequential client with per-operation counts and persistent pacing.

    The owning source validates configuration and calls reset_budget before each
    public operation. Every attempt consumes one request, including retries.
    Injected transports must not add hidden requests or authentication.
    A transport's optional ``replay_response(request)`` may return a verified
    local response or None, but must never make a network request. Only that
    local response skips pacing; it still consumes an attempt and byte limits.
    """

    def __init__(
        self,
        *,
        max_requests: int,
        timeout_seconds: float,
        min_request_interval_seconds: float,
        user_agent: str,
        error_type: type[Exception],
        transport: httpx.BaseTransport | None,
        clock: Callable[[], datetime],
        headers: Mapping[str, str] | None = None,
        retain_refusal_bodies: bool = False,
    ) -> None:
        """``headers`` adds fixed request headers, such as a credential header; they never enter URLs.

        ``retain_refusal_bodies`` is for keyless routes, where a 401/403 is a bot
        wall rather than a rejected key and its body is evidence; a keyed route
        must leave it off, since the body can echo the key.
        """
        self.max_requests = max_requests
        self.retain_refusal_bodies = retain_refusal_bodies
        self.min_request_interval_seconds = min_request_interval_seconds
        self.error_type = error_type
        self._clock = clock
        self._last_request_start: float | None = None
        self._request_count = 0
        self._closed = False
        self._traversal: _TraversalAllocation | None = None
        self._replay_response = getattr(transport, "replay_response", None)
        if self._replay_response is not None and not callable(self._replay_response):
            raise TypeError("replay_response must be callable")
        self._client = httpx.Client(
            transport=transport,
            timeout=httpx.Timeout(timeout_seconds),
            follow_redirects=False,
            trust_env=False,
            headers={"User-Agent": user_agent, "Accept-Encoding": "identity", **dict(headers or {})},
        )

    @property
    def request_count(self) -> int:
        return self._request_count

    def reset_budget(self) -> None:
        if self._closed:
            raise ValueError("Source acquisition client is closed")
        self._request_count = 0

    def close(self) -> None:
        if not self._closed:
            self._closed = True
            self._client.close()

    @contextmanager
    def traversal_budget(self, *, max_requests: int, max_wait_seconds: float) -> Iterator[None]:
        """Share a caller-validated allocation across operations; page resets cannot replenish it."""
        if self._traversal is not None:
            raise ValueError("Source acquisition already has an active traversal")
        self._traversal = _TraversalAllocation(max_requests, max_wait_seconds)
        try:
            yield
        finally:
            self._traversal = None

    def _deferred(self, reason: str, retry_after: float | None = None) -> Exception:
        error = self.error_type(f"Source traversal incomplete: deferred because {reason}")
        allocation = self._traversal
        assert allocation is not None
        error.__dict__["traversal_allocation"] = {
            "requestCount": allocation.requests,
            "maxRequests": allocation.max_requests,
            "waitedSeconds": allocation.waited_seconds,
            "maxWaitSeconds": allocation.max_wait_seconds,
            "retryAfterSeconds": retry_after,
        }
        return error

    def _wait(self, delay: float, *, retry_after: float | None = None) -> None:
        allocation = self._traversal
        if allocation is not None:
            if delay > allocation.max_wait_seconds - allocation.waited_seconds:
                raise self._deferred("the wait would exceed its traversal allocation", retry_after)
            allocation.waited_seconds += delay
        time.sleep(delay)

    def _retry_after(self, error: Exception) -> float | None:
        if isinstance(error, RetryableHTTPStatusError) and error.response.status_code == 429:
            return retry_after_seconds(error.response.headers.get("Retry-After"), now=self._clock())
        return None

    def _wait_for_retry(self, error: Exception, delay: float) -> None:
        retry_after = self._retry_after(error)
        allocation = self._traversal
        assert allocation is not None
        if allocation.requests >= allocation.max_requests:
            raise self._deferred("its total request allocation is exhausted", retry_after)
        self._wait(delay if retry_after is None else retry_after, retry_after=retry_after)

    def _check_request_budget(self) -> None:
        if self._closed:
            raise ValueError("Source acquisition client is closed")
        if self._request_count >= self.max_requests:
            raise self.error_type("Source acquisition exhausted its total request budget")
        if self._traversal is not None and self._traversal.requests >= self._traversal.max_requests:
            raise self._deferred("its total request allocation is exhausted")

    def _count_request(self) -> None:
        self._request_count += 1
        if self._traversal is not None:
            self._traversal.requests += 1

    def start_request(self) -> None:
        """Charge and pace a network attempt, including external transports."""
        self._check_request_budget()
        if self._last_request_start is not None:
            while (delay := self.min_request_interval_seconds - (time.monotonic() - self._last_request_start)) > 0:
                self._wait(delay)
        self._last_request_start = time.monotonic()
        self._count_request()

    @contextmanager
    def _response(self, method, url, headers, content):
        if self._replay_response is not None:
            # Exhaustion must refuse before consuming the checkpoint's next page.
            self._check_request_budget()
            self._client.cookies.clear()
            try:
                request = self._client.build_request(method, url, headers=headers, content=content)
                retained = self._replay_response(request)
                if retained is not None and not isinstance(retained, httpx.Response):
                    raise TypeError("Replay lookup must return a local HTTP response or None")
            except Exception:
                self._count_request()  # A refused local attempt still consumes its allocation.
                raise
            if retained is not None:
                self._count_request()
                with closing(retained):
                    yield retained
                return
        self.start_request()
        # A previous response's cookies must not steer page selection.
        self._client.cookies.clear()
        with self._client.stream(method, url, headers=headers, content=content) as response:
            yield response

    def capture(
        self,
        url: str,
        *,
        max_bytes: int,
        allow_unavailable: bool = False,
        allow_gzip: bool = False,
        method: str = "GET",
        content: bytes | None = None,
        request_headers: Mapping[str, str] | None = None,
        retain_dropped_body: bool = False,
        max_attempts: int | None = None,
        byte_range: tuple[int, int] | None = None,
    ) -> CapturedBodyResponse:
        """``POST`` sends ``content`` verbatim and records it on the capture; credentials never belong in it.

        ``max_attempts`` caps this call's retries below the remaining budget; a
        ladder rung passes ``1`` so its one attempt is recorded, not retried.

        ``byte_range`` ``(first, last)``, inclusive, asks for exactly those bytes
        of the resource (``Range: bytes=first-last``) and accepts only ``206``
        whose ``Content-Range`` states the same positions within its total and
        whose body is exactly that long: a web archive's record is a slice of a
        much larger file, and a server that ignored the range and sent ``200``
        with the whole file is refused, not truncated into evidence.

        ``retain_dropped_body`` keeps what a body delivered before any
        ``httpx.RequestError`` cut it short (a dropped connection, a reset, a read
        timeout) as the transport refusal's evidence, marked
        ``response-incomplete`` so it is never read as the whole answer. The
        failure is retried exactly as without it; the error that finally escapes
        carries the last attempt's bytes. It is for keyless routes only: those
        bytes never reach the credential-echo check a completed capture gets.
        """
        if self._closed:
            raise ValueError("Source acquisition client is closed")
        if method not in ("GET", "POST"):
            raise ValueError("method must be GET or POST")
        if (content is not None) != (method == "POST"):
            raise ValueError("POST requires a request body and GET forbids one")
        if max_attempts is not None and (
            isinstance(max_attempts, bool) or not isinstance(max_attempts, int) or max_attempts <= 0
        ):
            raise ValueError("max_attempts must be a positive integer")
        if byte_range is not None:
            first, last = byte_range
            if any(isinstance(v, bool) or not isinstance(v, int) for v in byte_range) or not 0 <= first <= last:
                raise ValueError("byte_range must be (first, last) with 0 <= first <= last")
        headers = {"Accept-Encoding": "gzip" if allow_gzip else "identity", **dict(request_headers or {})}
        if byte_range is not None:
            headers["Range"] = f"bytes={byte_range[0]}-{byte_range[1]}"

        def attempt() -> CapturedBodyResponse:
            try:
                with self._response(method, url, headers, content) as response:
                    if response.status_code in (401, 403):
                        error = CredentialRefusedError(
                            f"Body source answered HTTP {response.status_code}; stopping acquisition"
                        )
                        if self.retain_refusal_bodies:
                            attach_refused_response(error, _access_refusal(response, url, max_bytes))
                        raise error
                    if response.status_code == 429 or response.status_code >= 500:
                        raise RetryableHTTPStatusError(
                            f"Body source answered retryable HTTP {response.status_code}",
                            request=response.request,
                            response=response,
                        )
                    encoding = response.headers.get("content-encoding", "identity").strip().lower()
                    if encoding not in ({"identity", "gzip"} if allow_gzip else {"identity"}):
                        raise self.error_type("Body source response uses unsupported content encoding")
                    stated_length = response.headers.get("content-length")
                    body = bytearray()
                    # HTTPX's chunker yields at most this size, including over
                    # short transport reads. A complete capture needs EOF. The
                    # chunker loses what it holds when the stream fails, so a
                    # dropped body is kept only by reading chunks as they arrive.
                    try:
                        for chunk in bounded_response_chunks(
                            response,
                            max_bytes=max_bytes,
                            error_type=self.error_type,
                            retain_dropped_body=retain_dropped_body,
                            check_length=False,
                        ):
                            body.extend(chunk)
                    except httpx.RequestError:
                        if not retain_dropped_body:
                            raise
                        dropped = _RetryableTransportError("Body source transport failed while acquiring a response")
                        attach_refused_response(
                            dropped,
                            RefusedResponse(
                                url,
                                "transport",
                                bytes(body),
                                _evidence_media_type(response),
                                "response-incomplete",
                                len(body),
                            ),
                        )
                        raise dropped from None
                    capture = CapturedBodyResponse(
                        requested_url=url,
                        resolved_url=str(response.url),
                        status_code=response.status_code,
                        content_type=response.headers.get("content-type"),
                        observed_at=(
                            response.extensions["spicy_docs_retained_observed_at"]
                            if "spicy_docs_retained_observed_at" in response.extensions
                            else observed_instant(self._clock)
                        ),
                        body=bytes(body),
                        content_encoding=encoding,
                        method=method,
                        request_body=content,
                    )
                    try:
                        if stated_length is not None and int(stated_length) != capture.byte_size:
                            raise self.error_type("Body source response size differs from Content-Length")
                        if capture.resolved_url != url:
                            raise self.error_type("Body source response final URL differs from its request")
                        if allow_unavailable and response.status_code in (404, 410):
                            pass
                        elif byte_range is not None:
                            _check_byte_range(response, byte_range, capture.byte_size, self.error_type)
                        elif response.status_code != 200:
                            raise self.error_type(f"Body source answered HTTP {response.status_code}")
                    except self.error_type as error:
                        attach_capture(error, capture)
                        attach_refused_response(error, refused_capture(capture, stage="transport"))
                        raise
                    return capture
            except httpx.RequestError:
                raise _RetryableTransportError("Body source transport failed while acquiring a response") from None

        try:
            remaining = self.max_requests - self._request_count
            if remaining <= 0:
                error = self.error_type("Source acquisition exhausted its total request budget")
                attach_refused_response(
                    error,
                    RefusedResponse(
                        url, "before-request", None, "application/octet-stream", "request-budget-exhausted"
                    ),
                )
                raise error
            return retry_http(
                attempt,
                retryable=(_RetryableTransportError, RetryableHTTPStatusError),
                max_attempts=remaining if max_attempts is None else min(remaining, max_attempts),
                wait=self._wait_for_retry if self._traversal is not None else None,
            )
        except Exception as error:
            if self._traversal is not None and isinstance(error, (_RetryableTransportError, RetryableHTTPStatusError)):
                error = self._deferred("the page retry bound was reached", self._retry_after(error))
                attach_refused_response(
                    error,
                    RefusedResponse(url, "transport", None, "application/octet-stream", "response-unavailable"),
                )
                raise error from None
            attach_refused_response(
                error,
                RefusedResponse(url, "transport", None, "application/octet-stream", "response-unavailable"),
            )
            raise
