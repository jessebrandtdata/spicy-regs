"""One reading of an HTTP ``Content-Range`` header, shared by every ranged transfer."""

from __future__ import annotations

import re

_CONTENT_RANGE = re.compile(r"bytes ([0-9]+)-([0-9]+)/([0-9]+)")


def content_range(value: str | None) -> tuple[int, int, int] | None:
    """``(first, last, total)`` of a complete numeric ``bytes first-last/total``; ``None`` for anything else.

    An unknown total (``/*``), a list of ranges and a missing header are all
    ``None``: each caller refuses what it cannot check rather than guessing.
    The positions are returned as stated; whether they cover the bytes the
    caller asked for is the caller's own rule.
    """
    match = _CONTENT_RANGE.fullmatch(value.strip()) if isinstance(value, str) else None
    if match is None:
        return None
    first, last, total = (int(group) for group in match.groups())
    return first, last, total
