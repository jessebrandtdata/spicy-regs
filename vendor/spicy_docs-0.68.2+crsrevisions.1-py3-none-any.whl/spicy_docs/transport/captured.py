"""The exact captured response and its refusal adapter, importable without an HTTP client.

Validators and readers reference these; only the bounded client in
``capture.py`` needs the optional HTTPX dependency.
"""

from __future__ import annotations

import hashlib
from collections.abc import Callable, Iterator
from dataclasses import dataclass, field
from datetime import UTC, datetime

from rulespec_artifacts import BlobSource

from spicy_docs.reading.refusals import RefusedResponse
from spicy_docs.storage.blobs import iter_verified_blob


def observed_instant(clock: Callable[[], datetime]) -> str:
    """The clock's instant as the UTC ``Z`` string a capture records; a naive clock refuses."""
    observed_at = clock()
    if observed_at.tzinfo is None or observed_at.utcoffset() is None:
        raise ValueError("Source acquisition clock must return a timezone-aware instant")
    return observed_at.astimezone(UTC).isoformat().replace("+00:00", "Z")


@dataclass(frozen=True, slots=True)
class CapturedBodyResponse:
    """Exact response payload bytes, before any content decoding, and observed facts."""

    requested_url: str
    resolved_url: str
    status_code: int
    content_type: str | None
    observed_at: str
    body: bytes = field(repr=False)
    content_encoding: str = "identity"
    method: str = "GET"
    request_body: bytes | None = field(default=None, repr=False)
    _digest: str | None = field(default=None, init=False, repr=False, compare=False)

    @property
    def byte_size(self) -> int:
        return len(self.body)

    @property
    def sha256(self) -> str:
        """The pinned digest, computed once and cached; the body is immutable bytes."""
        if self._digest is None:
            object.__setattr__(self, "_digest", "sha256:" + hashlib.sha256(self.body).hexdigest())
        return self._digest


def attach_capture(error: Exception, capture: CapturedBodyResponse) -> None:
    """Carry the complete response a refusal was decided on, without changing the error."""
    error.__dict__["capture"] = capture


def attached_capture(error: BaseException) -> CapturedBodyResponse | None:
    """The capture ``attach_capture`` left on a refusal, or ``None`` if it kept none."""
    capture = error.__dict__.get("capture")
    return capture if isinstance(capture, CapturedBodyResponse) else None


def refused_capture(capture: CapturedBodyResponse, *, stage: str) -> RefusedResponse:
    """Adapt one capture into refusal evidence, media type stripped of parameters."""
    return RefusedResponse(
        request_key=capture.requested_url,
        stage=stage,
        response_bytes=capture.body,
        media_type=(capture.content_type or "application/octet-stream").split(";", 1)[0].strip(),
        observed_byte_size=capture.byte_size,
    )


@dataclass(frozen=True, slots=True)
class CompletedCapture:
    """A retained raw response, issued after the capture journal is durable.

    This identifies bytes and the issuing evidence policy, not source meaning
    or successful decoding. Each complete replay renews size and SHA-256
    integrity; earlier chunks remain provisional. The source must open pinned
    files without a preliminary whole-file scan. Independent owner validation
    and publication admission remain necessary.
    """

    source: BlobSource = field(repr=False, compare=False)
    sha256: str
    byte_size: int
    capture_id: str
    publisher_id: str | None
    evidence_policy: str
    parser_version: str
    policy_decision_id: str
    content_encoding: str
    _failure: Callable[[str], Exception] = field(repr=False, compare=False)

    def iter_bytes(self) -> Iterator[bytes]:
        """Read the retained raw bytes in bounded chunks; exhaustion proves identity."""
        try:
            yield from iter_verified_blob(self.source, self.sha256, self.byte_size)
        except Exception as error:
            raise self._failure("Retained capture bytes failed integrity verification") from error
