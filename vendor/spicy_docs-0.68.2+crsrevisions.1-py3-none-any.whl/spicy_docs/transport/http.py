"""HTTPX acquisition and retry rules, loaded only for HTTP-backed operations."""

from __future__ import annotations

from collections.abc import Callable
from datetime import datetime

import httpx

from spicy_docs.sources.federal_register.native import MAX_PAGE_BYTES, FederalRegisterSourceError
from spicy_docs.sources.public_comments.native import MAX_PARTITION_BYTES, PublicTableCapture, PublicTableSourceError
from spicy_docs.transport.acquisition import capture_instant
from spicy_docs.transport.bounded import bounded_response_chunks
from spicy_docs.transport.retry import retry_http


class RetryableHTTPStatusError(httpx.HTTPStatusError):
    """A 429 or 5xx response -- worth retrying, unlike any other 4xx.

    A distinct subclass (rather than the plain ``httpx.HTTPStatusError`` that
    ``response.raise_for_status()`` raises) lets ``retry_http`` tell "the
    server asked us to back off or is failing" apart from "this request is
    simply wrong" without inspecting exception messages. Both still satisfy
    ``isinstance(error, httpx.HTTPError)``, so a persistent 429/5xx that
    outlasts every attempt is still classified as ``transport-failed`` same
    as before.
    """


class _EmptyFederalRegisterResponse(FederalRegisterSourceError):
    """An empty success can be a transient publisher failure."""


class _EmptyPublicTableResponse(PublicTableSourceError):
    """An empty partition can be a transient mirror failure."""


def fetch_federal_register(client: httpx.Client, url: str) -> bytes:
    """Fetch one URL, retrying transport errors, 429/5xx and empty responses; return the exact bytes."""

    def _attempt() -> bytes:
        with client.stream("GET", url, headers={"Accept-Encoding": "identity"}) as response:
            if response.status_code == 429 or response.status_code >= 500:
                raise RetryableHTTPStatusError(
                    "retryable Federal Register response",
                    request=response.request,
                    response=response,
                )
            response.raise_for_status()
            body = b"".join(
                bounded_response_chunks(
                    response,
                    max_bytes=MAX_PAGE_BYTES,
                    error_type=FederalRegisterSourceError,
                    raw=False,
                )
            )
            if not body:
                raise _EmptyFederalRegisterResponse("Federal Register returned an empty response")
            return body

    return retry_http(
        _attempt,
        retryable=(httpx.RequestError, RetryableHTTPStatusError, _EmptyFederalRegisterResponse),
    )


def fetch_public_table(
    client: httpx.Client,
    locator: str,
    *,
    clock: Callable[[], datetime],
) -> PublicTableCapture | None:
    """Fetch one whole partition object, or ``None`` when the mirror has none (404).

    Retries transport errors, 429/5xx and empty partitions; oversized bodies stop. Returns the
    capture with its ETag and Last-Modified.
    """

    def _attempt() -> PublicTableCapture | None:
        with client.stream("GET", locator, headers={"Accept-Encoding": "identity"}) as response:
            if response.status_code == 404:
                return None
            if response.status_code == 429 or response.status_code >= 500:
                raise RetryableHTTPStatusError(
                    "retryable spicy-regs public-table response",
                    request=response.request,
                    response=response,
                )
            response.raise_for_status()
            body = b"".join(
                bounded_response_chunks(
                    response,
                    max_bytes=MAX_PARTITION_BYTES,
                    error_type=PublicTableSourceError,
                    raw=False,
                )
            )
            if not body:
                raise _EmptyPublicTableResponse("the spicy-regs public tables returned an empty partition")
            return PublicTableCapture(
                locator=locator,
                content=body,
                fetched_at=capture_instant(clock),
                etag=response.headers.get("etag"),
                last_modified=response.headers.get("last-modified"),
            )

    return retry_http(
        _attempt,
        retryable=(httpx.RequestError, RetryableHTTPStatusError, _EmptyPublicTableResponse),
    )
