"""Bounded response iteration shared by HTTP acquisition adapters."""

from __future__ import annotations

from collections.abc import Iterator

import httpx

from spicy_docs.reading.refusals import RefusedResponse, attach_refused_response


def bounded_response_chunks(
    response: httpx.Response,
    *,
    max_bytes: int,
    error_type: type[Exception],
    raw: bool = True,
    retain_dropped_body: bool = False,
    check_length: bool = True,
) -> Iterator[bytes]:
    """Bound raw or identity bytes before buffering; declared oversize is terminal.

    HTTPX rechunks reads to at most 64 KiB (or limit + 1 for small limits).
    Dropped-body evidence opts out of rechunking so partial bytes survive a
    transport interruption. Source fetch adapters request identity and
    refuse other encodings before reading: HTTPX otherwise decompresses a
    whole raw chunk before applying its output chunk size. Raw capture callers
    may preserve an explicitly allowed encoding for later source decoding.
    """
    if type(max_bytes) is not int or max_bytes <= 0:
        raise ValueError("max_bytes must be positive")
    encoding = response.headers.get("content-encoding", "identity").strip().lower()
    if not raw and encoding != "identity":
        raise error_type("Body source response uses unsupported content encoding; identity was requested")
    length = response.headers.get("content-length")
    if length is not None and (not length.isascii() or not length.isdigit()):
        raise error_type("Body source response Content-Length is invalid")
    stated = None if length is None else int(length)
    if stated is not None and stated > max_bytes:
        error = error_type("Body source response exceeds its byte bound")
        attach_refused_response(
            error,
            RefusedResponse(
                str(response.url),
                "transport",
                None,
                "application/octet-stream",
                "response-byte-limit",
                stated_byte_size=stated,
            ),
        )
        raise error
    chunk_size = None if retain_dropped_body else min(max_bytes + 1, 64 * 1024)
    chunks = response.iter_raw(chunk_size=chunk_size) if raw else response.iter_bytes(chunk_size=chunk_size)
    observed = 0
    for chunk in chunks:
        observed += len(chunk)
        if observed > max_bytes:
            error = error_type("Body source response exceeds its byte bound")
            attach_refused_response(
                error,
                RefusedResponse(
                    str(response.url),
                    "transport",
                    None,
                    "application/octet-stream",
                    "response-byte-limit",
                    observed,
                    stated,
                ),
            )
            raise error
        yield chunk
    if check_length and stated is not None and stated != observed:
        raise error_type("Body source response size differs from Content-Length")
