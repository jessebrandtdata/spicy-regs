"""Lazy PDF rendering and image decoding; all optional imports stay at use sites."""

from __future__ import annotations

import io
import math
from collections import Counter
from contextlib import contextmanager
from importlib.metadata import version

from .font_glyphs import counts, map_line, unmapped_by_font
from .model import Box, ExtractionError, ProcessingIssue, Raster, Recognition, TableObservation, TextBlock


def _png(image) -> bytes:
    out = io.BytesIO()
    image.save(out, format="PNG")
    return out.getvalue()


def _display_box(page, rect_like, width: float, height: float) -> Box | None:
    """Map a PyMuPDF page-space rect into normalized displayed-page coordinates.

    Shared by ``_PDFPage.native``'s line boxes and ``_PDFPage.find_tables``'s
    table and cell boxes: the same rotation-matrix transform, clipped to the
    displayed page rect. ``None`` means the rect has no area on the displayed
    page (a table cell PyMuPDF reports no bounding box for, or geometry
    entirely outside the crop), not a zero-sized box.
    """
    import pymupdf

    rect = pymupdf.Rect(rect_like) * page.rotation_matrix
    rect &= page.rect
    if rect.is_empty:
        return None
    return Box(rect.x0 / width, rect.y0 / height, rect.x1 / width, rect.y1 / height)


def _pixel_bounds(box: Box, width: int, height: int) -> tuple[int, int, int, int]:
    return (
        math.floor(box.x0 * width),
        math.floor(box.y0 * height),
        math.ceil(box.x1 * width),
        math.ceil(box.y1 * height),
    )


def rounded(box: Box, image: Raster) -> Box:
    """The page region :func:`crop` would actually cut for ``box``: its bounds rounded outward to pixels."""
    x0, y0, x1, y1 = _pixel_bounds(box, image.width, image.height)
    return image.box.place(Box(x0 / image.width, y0 / image.height, x1 / image.width, y1 / image.height))


def crop(image: Raster, box: Box) -> Raster:
    """Crop to pixel-rounded bounds and return a PNG whose box is the actual rounded region."""
    from PIL import Image

    with Image.open(io.BytesIO(image.data)) as source:
        part = source.crop(_pixel_bounds(box, source.width, source.height))
        return Raster(_png(part), part.width, part.height, rounded(box, image))


class DefaultReader:
    """Open PDFs through PyMuPDF and images through Pillow, loading each backend only when used.

    PDF pages expose their native text layer and render at ``dpi``; every render
    is refused above ``max_pixels``. Encrypted PDFs are refused here.
    """

    def __init__(self, *, dpi: int = 200, max_pixels: int = 20_000_000):
        if not 36 <= dpi <= 1200 or max_pixels < 1:
            raise ValueError("dpi must be 36..1200 and max_pixels must be positive")
        self.dpi, self.max_pixels = dpi, max_pixels

    @contextmanager
    def open(self, source: bytes, media_type: str):
        if media_type == "application/pdf":
            import pymupdf

            with pymupdf.open(stream=source, filetype="pdf") as document:
                if document.needs_pass:
                    raise ExtractionError("encrypted PDF requires decryption before extraction")
                yield _PDF(document, self)
        else:
            from PIL import Image

            with Image.open(io.BytesIO(source)) as document:
                actual = Image.MIME.get(document.format)
                if actual != media_type:
                    raise ValueError(f"image bytes have media type {actual}, not {media_type}")
                yield _Images(document, self)

    def check_pixels(self, width: int, height: int):
        """Refuse a nonexistent or over-``max_pixels`` raster before it is allocated."""
        if width < 1 or height < 1 or width * height > self.max_pixels:
            raise ExtractionError("render exceeds max_pixels; reduce DPI or choose a larger explicit limit")


class _PDF:
    def __init__(self, document, reader):
        self.document, self.reader, self.page_count = document, reader, len(document)
        #: Font xref -> codes its ToUnicode map omits, so each font is parsed once per document, not per page.
        self.unmapped: dict[int, frozenset[int] | None] = {}

    def page(self, number):
        return _PDFPage(self.document[number - 1], number, self.reader, self.unmapped)


class _PDFPage:
    has_native_layer = True

    def __init__(self, page, number, reader, unmapped=None):
        self.page, self.number, self.reader = page, number, reader
        self.unmapped = {} if unmapped is None else unmapped
        self.geometry = {
            "kind": "pdf",
            "rotation": page.rotation,
            "cropbox": list(page.cropbox),
            "mediabox": list(page.mediabox),
            "display_rect": list(page.rect),
            "dpi": reader.dpi,
        }

    def native(self):
        """PyMuPDF's line-grouped text in reading order, one block per line.

        Text outside the displayed page is refused. GPO symbol-font glyphs are mapped by
        ``font_glyphs`` (the raw spans keep the literal glyph) and each mapping is a
        ``font-glyph-mapped`` issue, or ``font-glyph-unresolved`` where the table leaves it. A
        character whose code its font's ToUnicode map omits is an ``unmapped-glyph-code`` issue
        naming the line's index in ``blocks`` and carrying its box, which
        ``NativeWithRegions(unmapped_glyphs=True)`` sends to OCR. A font whose
        dictionary or map cannot be read is an ``unmapped-glyph-check-skipped`` issue; its text is
        extracted as it would be without the check.
        """
        import pymupdf

        # Image bytes are retained by the source, not duplicated into native text extraction.
        raw = self.page.get_text("dict", flags=pymupdf.TEXTFLAGS_DICT & ~pymupdf.TEXT_PRESERVE_IMAGES)
        unmapped, unreadable = unmapped_by_font(self.page.parent, self.page.get_fonts(), self.unmapped)
        blocks = []
        issues = [
            ProcessingIssue("unmapped-glyph-check-skipped", f"{name}: font dictionary or Unicode map unreadable")
            for name in unreadable
        ]
        tally = Counter()
        width, height = self.page.rect.width, self.page.rect.height
        for block in raw["blocks"]:
            for line in block.get("lines", []):
                text = map_line(line["spans"], tally, line["dir"])
                box = _display_box(self.page, line["bbox"], width, height)
                if box is None:
                    if text.strip():
                        raise ExtractionError("native text falls outside displayed page bounds", details=line)
                    continue
                issues.extend(_unmapped_issues(line["spans"], unmapped, len(blocks), box))
                blocks.append(TextBlock(text, box))
        for glyph in counts(self.number, tally):
            mapped = glyph.replacement is not None
            issues.append(
                ProcessingIssue(
                    "font-glyph-mapped" if mapped else "font-glyph-unresolved",
                    f"{glyph.rule}: {glyph.font} {glyph.original!r} -> "
                    f"{glyph.replacement if mapped else 'kept'!r} x{glyph.count}",
                )
            )
        return Recognition(
            "\n".join(b.text for b in blocks),
            {"backend": "pymupdf", "version": version("pymupdf"), "sort": False},
            raw,
            tuple(blocks),
            issues=tuple(issues),
        )

    def render(self):
        """Render the page at the reader's DPI as an alpha-free PNG, bounded by ``max_pixels``."""
        width = math.ceil(self.page.rect.width * self.reader.dpi / 72)
        height = math.ceil(self.page.rect.height * self.reader.dpi / 72)
        self.reader.check_pixels(width, height)
        pix = self.page.get_pixmap(dpi=self.reader.dpi, alpha=False)
        self.reader.check_pixels(pix.width, pix.height)
        return Raster(pix.tobytes("png"), pix.width, pix.height)

    def find_tables(self):
        """PyMuPDF's ruled tables with cell text and normalized cell boxes.

        A table with no displayed area is skipped.
        """
        width, height = self.page.rect.width, self.page.rect.height
        observations = []
        for table in self.page.find_tables().tables:
            box = _display_box(self.page, table.bbox, width, height)
            if box is None:
                continue  # table geometry has no area on the displayed page
            cells = tuple(tuple(row) for row in table.extract())
            cell_boxes = tuple(
                tuple(_display_box(self.page, cell, width, height) if cell is not None else None for cell in row.cells)
                for row in table.rows
            )
            observations.append(TableObservation(self.number, box, table.row_count, table.col_count, cells, cell_boxes))
        return tuple(observations)


def _unmapped_issues(spans, unmapped, index, box):
    """One ``unmapped-glyph-code`` issue per flagged (font, character) on a line, placed at the line's box."""
    if not unmapped:
        return ()
    seen = dict.fromkeys(
        (span["font"], char) for span in spans for char in span["text"] if ord(char) in unmapped.get(span["font"], ())
    )
    return tuple(
        ProcessingIssue(
            "unmapped-glyph-code",
            f"line {index}: {font} code 0x{ord(char):02X} has no Unicode map entry; extracted as {char!r}",
            box,
        )
        for font, char in seen
    )


class _Images:
    def __init__(self, document, reader):
        self.document, self.reader = document, reader
        self.page_count = getattr(document, "n_frames", 1)

    def page(self, number):
        from PIL import Image, ImageOps

        self.document.seek(number - 1)
        self.reader.check_pixels(self.document.width, self.document.height)
        geometry = {
            "kind": "image",
            "original_size": list(self.document.size),
            "exif_orientation": self.document.getexif().get(274, 1),
            "pillow_version": version("pillow"),
            "background": "white",
        }
        oriented = ImageOps.exif_transpose(self.document)
        if "A" in oriented.getbands() or "transparency" in oriented.info:
            rgba = oriented.convert("RGBA")
            oriented = Image.new("RGB", rgba.size, "white")
            oriented.paste(rgba, mask=rgba.getchannel("A"))
        else:
            oriented = oriented.convert("RGB")
        geometry["display_size"] = list(oriented.size)
        return _ImagePage(oriented, number, geometry)


class _ImagePage:
    has_native_layer = False

    def __init__(self, image, number, geometry):
        self.image, self.number, self.geometry = image, number, geometry

    def native(self):
        """Refuse: an image carries no native text layer."""
        raise ExtractionError("image has no native text layer")

    def render(self):
        """The oriented frame as a PNG at its own size."""
        return Raster(_png(self.image), self.image.width, self.image.height)

    def find_tables(self):
        """Empty, not an error: no table finder runs over image input."""
        return ()
