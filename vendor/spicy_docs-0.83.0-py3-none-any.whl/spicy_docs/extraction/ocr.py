"""Optional local recognition providers; engines load once on first use."""

from __future__ import annotations

import functools
import io
import math
import platform
import plistlib
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any, cast

# The Docling adapter is separate so importing OCR providers does not load Docling.
from .docling import Docling, DoclingSettings, DoclingVlmSettings  # noqa: F401
from .model import RAW_RGB, Box, ExtractionError, Raster, Recognition, TextBlock


def _version(package):
    try:
        return version(package)
    except PackageNotFoundError:
        return None


def _box(x0, y0, x1, y1):
    # Providers can put edges just outside an image. Preserve original coordinates in raw.
    return Box(max(0, x0), max(0, y0), min(1, x1), min(1, y1))


class RapidOCR:
    def __init__(self, *, engine=None, **options: Any):
        self.engine = engine
        self._injected = engine is not None
        if self._injected and options:
            raise ValueError("configure an injected RapidOCR engine before passing it")
        self.options: dict[str, Any] = {"intra_op_num_threads": 4, "inter_op_num_threads": 1, **options}

    def recognize(self, image: Raster) -> Recognition:
        if self.engine is None:
            from rapidocr_onnxruntime import RapidOCR as Engine

            self.engine = Engine(**self.options)
        result, elapsed = self.engine(image.data)
        detections, blocks = [], []
        for points, text, confidence in result or []:
            points = [[float(x), float(y)] for x, y in points]
            xs, ys = zip(*points, strict=True)
            box = _box(min(xs) / image.width, min(ys) / image.height, max(xs) / image.width, max(ys) / image.height)
            blocks.append(TextBlock(text, box, float(confidence)))
            detections.append({"points": points, "text": text, "confidence": float(confidence)})
        return Recognition(
            "\n".join(b.text for b in blocks),
            {
                "backend": "rapidocr",
                "version": _version("rapidocr-onnxruntime"),
                "engine_injected": self._injected,
                "options": None if self._injected else self.options,
            },
            {"detections": detections, "engine_elapsed": elapsed, "coordinates": "image pixels; top-left origin"},
            tuple(blocks),
        )


@functools.cache
def _vision_host() -> dict[str, str | None]:
    """The PyObjC binding and the running macOS version and build (``ProductBuildVersion``), read once a process."""
    try:
        with open("/System/Library/CoreServices/SystemVersion.plist", "rb") as plist:
            build = plistlib.load(plist).get("ProductBuildVersion")
    except (OSError, plistlib.InvalidFileException):
        build = None
    return {"version": _version("pyobjc-framework-Vision"), "macos": platform.mac_ver()[0], "macos_build": build}


class _Vision:
    """One ``VNRecognizeTextRequest``, configured once and performed per raster.

    An encoded raster goes to Vision as bytes (Vision decodes it); ``RAW_RGB`` samples go as a ``CGImage``, so no
    image is encoded or decoded. Detections keep ocrmac's shape, so output matches the ocrmac path it replaced.
    """

    def __init__(self, level: str, languages: tuple[str, ...], language_correction: bool):
        if platform.system() != "Darwin":
            raise ExtractionError("Apple Vision requires macOS")
        import Foundation
        import Quartz
        import Vision

        self.foundation, self.quartz, self.vision = Foundation, Quartz, Vision
        self.request = request = Vision.VNRecognizeTextRequest.alloc().init()
        request.setRecognitionLevel_(1 if level == "fast" else 0)
        supported = request.supportedRecognitionLanguagesAndReturnError_(None)[0]
        if not set(languages) <= set(supported):
            raise ValueError(f"languages must be among Vision's {sorted(supported)}")
        request.setRecognitionLanguages_(list(languages))
        request.setUsesLanguageCorrection_(language_correction)
        self.revision = int(request.revision())

    def __call__(self, image: Raster) -> list[tuple[str, float, list[float]]]:
        import objc

        with objc.autorelease_pool():
            handler = self.vision.VNImageRequestHandler.alloc()
            if image.media_type == RAW_RGB:
                handler = handler.initWithCGImage_options_(self._cgimage(image), None)
            else:
                handler = handler.initWithData_options_(image.data, None)
            done = handler.performRequests_error_([self.request], None)
            ok, error = done if isinstance(done, tuple) else (bool(done), None)
            if not ok or error is not None:
                raise ExtractionError("Apple Vision recognition failed", details={"error": str(error)})
            detections = []
            for result in self.request.results() or ():
                box = result.boundingBox()
                detections.append(
                    (
                        str(result.text()),
                        float(result.confidence()),
                        [box.origin.x, box.origin.y, box.size.width, box.size.height],
                    )
                )
            return detections

    def _cgimage(self, image: Raster):
        # CGDataProviderCreateWithData(None, data, ...) leaks the whole buffer under PyObjC, with or without a release
        # callback: 10.2 MB a 200-DPI page (congressional-tech pdf-text-census-20261108, leak/). An NSData copy is
        # Objective-C's to free with the autorelease pool: 0.2 MB a page, the same text and speed.
        q = self.quartz
        provider = q.CGDataProviderCreateWithCFData(
            self.foundation.NSData.dataWithBytes_length_(image.data, len(image.data))
        )
        return q.CGImageCreate(
            image.width,
            image.height,
            8,
            24,
            image.width * 3,
            q.CGColorSpaceCreateDeviceRGB(),
            q.kCGBitmapByteOrderDefault | q.kCGImageAlphaNone,
            provider,
            None,
            False,
            q.kCGRenderingIntentDefault,
        )


#: Each band reaches this share of the page height past its boundaries, as the census's band probe did.
_BAND_OVERLAP = 0.02
#: A detection this close (share of page height) to a band's inner edge may be a line the edge cut.
_BAND_EDGE = 0.005


def _rgb_samples(image: Raster) -> bytes:
    """The raster's unencoded RGB samples, decoding an encoded image once."""
    if image.media_type == RAW_RGB:
        return image.data
    from PIL import Image

    with Image.open(io.BytesIO(image.data)) as source:
        return source.convert("RGB").tobytes()


def _same_line(a, b) -> bool:
    """Two detections' boxes overlap by more than half the smaller box in each direction."""
    (ax, ay, aw, ah), (bx, by, bw, bh) = a[2], b[2]
    across = min(ax + aw, bx + bw) - max(ax, bx)
    down = min(ay + ah, by + bh) - max(ay, by)
    return across > min(aw, bw) / 2 and down > min(ah, bh) / 2


def _banded(engine, image: Raster, bands: int):
    """Recognize ``bands`` horizontal strips of ``image``, keeping one copy of each line in strip order.

    Each strip reaches ``_BAND_OVERLAP`` of the height past its core rows, so a line on a boundary is whole in both
    strips. A strip's detections whose centre lies in its core are taken first, then the rest; a detection is
    dropped if a strip beside it already kept the same line (boxes overlapping by more than half), or if it lies
    outside its core and touches the strip's inner edge, where a cut line would. Returns the kept detections and
    the dropped ones in whole-image coordinates, and each strip's pixel rows. Each detection is compared with the
    lines kept so far: quadratic in a page's lines, a few thousand box tests beside seconds of recognition.
    """
    height, row, reach = image.height, image.width * 3, math.ceil(image.height * _BAND_OVERLAP)
    samples, strips, own, other = _rgb_samples(image), [], [], []
    for i in range(bands):
        start, end = height * i / bands, height * (i + 1) / bands
        top, bottom = max(0, math.floor(start) - reach), min(height, math.ceil(end) + reach)
        strip = Raster(samples[top * row : bottom * row], image.width, bottom - top, media_type=RAW_RGB)
        found = []
        for text, confidence, (x, y, w, h) in engine(strip):
            upper, lower = top + (1 - y - h) * (bottom - top), top + (1 - y) * (bottom - top)
            middle, j = (upper + lower) / 2, len(found)
            found.append((text, confidence, [x, 1 - lower / height, w, (lower - upper) / height]))
            cut = (top > 0 and upper - top < height * _BAND_EDGE) or (
                bottom < height and bottom - lower < height * _BAND_EDGE
            )
            if start <= middle < end or (i == bands - 1 and middle == end):
                own.append((i, j))
            elif not cut:
                other.append((i, j))
        strips.append(([top, bottom], found))
    kept: set[tuple[int, int]] = set()
    for i, j in own + other:
        line = strips[i][1][j]
        if not any(abs(k - i) == 1 and _same_line(line, strips[k][1][m]) for k, m in kept):
            kept.add((i, j))
    ordered = [(i, j) for i, (_, found) in enumerate(strips) for j in range(len(found))]
    return (
        [strips[i][1][j] for i, j in ordered if (i, j) in kept],
        [strips[i][1][j] for i, j in ordered if (i, j) not in kept],
        [rows for rows, _ in strips],
    )


class AppleVision:
    """Apple Vision text recognition through PyObjC, one request per instance reused for every page.

    Takes an encoded raster or, from ``DefaultReader(raw_rgb=True)``, raw RGB samples without any PNG step.
    ``language_correction`` sets Vision's ``usesLanguageCorrection``; the default, on, reproduces the earlier
    ocrmac output byte for byte. Off, a 200-DPI page took 0.19 s instead of 0.36 s at the same agreement with
    the native text layer (congressional-tech investigation ``pdf-text-vision-path-20261108``). An injected
    ``engine`` is called with each raster and returns ``(text, confidence, [x, y, width, height])`` detections
    in Vision's normalized bottom-left coordinates. The request is not shared across threads: one instance
    per serial worker.

    ``bands > 1`` recognizes that many horizontal strips, each 2% of the page taller at a shared boundary, and
    keeps one copy of a line both read (:func:`_banded`); the engine then sees raw RGB strips. Whole-page accurate
    Vision drops lines of tightly set type: on two born-digital GPO hearing pages it read 32% of the native layer,
    three bands 86-101%, and on 1,000 OCR-flagged pages three bands read at least 25% more on 18.8%
    (congressional-tech ``pdf-text-census-20261108``).
    """

    def __init__(
        self,
        *,
        recognition_level="accurate",
        languages=("en-US",),
        language_correction=True,
        bands=1,
        engine=None,
    ):
        if recognition_level not in {"accurate", "fast"}:
            raise ValueError("recognition_level must be accurate or fast")
        if type(bands) is not int or bands < 1:
            raise ValueError("bands must be a positive integer")
        self.level, self.languages, self.language_correction = recognition_level, tuple(languages), language_correction
        self.bands, self.engine, self._injected = bands, engine, engine is not None

    def configuration(self) -> dict[str, Any]:
        """Effective settings and the macOS build, which names Vision's models; the request revision once built."""
        return {
            "backend": "apple-vision",
            **_vision_host(),
            "recognition_level": self.level,
            "languages": list(self.languages),
            "language_correction": self.language_correction,
            "bands": self.bands,
            "engine_injected": self._injected,
            "request_revision": getattr(self.engine, "revision", None) if not self._injected else None,
        }

    def require_reproducible_identity(self) -> dict[str, Any]:
        """The configuration a host keys a re-read on; refuses an injected engine, whose model is unknown."""
        if self._injected:
            raise ValueError("an injected Apple Vision engine has no reproducible identity")
        self._engine()
        return self.configuration()

    def _engine(self):
        if self.engine is None:
            self.engine = _Vision(self.level, self.languages, self.language_correction)
        return self.engine

    def recognize(self, image: Raster) -> Recognition:
        raw: dict[str, Any] = {"coordinates": "normalized x/y/width/height; bottom-left origin"}
        if self.bands == 1:
            detections = self._engine()(image)
        else:
            detections, raw["overlap_duplicates"], raw["band_rows"] = _banded(self._engine(), image, self.bands)
        blocks = tuple(
            TextBlock(text, _box(x, 1 - y - h, x + w, 1 - y), float(conf)) for text, conf, (x, y, w, h) in detections
        )
        return Recognition(
            "\n".join(b.text for b in blocks), self.configuration(), {"detections": detections, **raw}, blocks
        )


class MLX:
    """MLX-VLM with explicit model, revision and prompt; reusable across pages.

    Hugging Face identifiers require a revision. Local directories are caller-pinned.
    This object and MLX's generator are intended for serial use in one worker.
    """

    def __init__(
        self,
        model: str,
        *,
        revision: str | None = None,
        prompt: str = "",
        max_tokens: int = 8192,
        temperature: float = 0,
        seed: int = 0,
        text_format: str = "plain",
    ):
        if max_tokens < 1 or temperature < 0:
            raise ValueError("max_tokens must be positive and temperature nonnegative")
        if not Path(model).is_dir() and not revision:
            raise ValueError("a remote model identifier requires an explicit revision")
        self.model, self.revision, self.prompt = model, revision, prompt
        self.max_tokens, self.temperature, self.seed = max_tokens, temperature, seed
        if text_format not in {"plain", "markdown", "html"}:
            raise ValueError("text_format must be plain, markdown or html")
        self.text_format = text_format
        self._loaded: tuple[Any, Any, dict, str] | None = None

    @classmethod
    def lighton(
        cls,
        *,
        model="mlx-community/LightOnOCR-2-1B-bf16",
        revision="16e06849ba5c689f782473651914d6613d25d884",
        **options: Any,
    ):
        return cls(model, revision=revision, **options)

    @classmethod
    def glm(
        cls,
        *,
        task="text",
        model="mlx-community/GLM-OCR-bf16",
        revision="24f15402e83baa0a80eeeaecf5480e172abc6f2e",
        **options: Any,
    ):
        prompts = {"text": "Text Recognition:", "table": "Table Recognition:", "formula": "Formula Recognition:"}
        if task not in prompts:
            raise ValueError("GLM task must be text, table or formula")
        options.setdefault("prompt", prompts[task])
        options.setdefault("text_format", "html" if task == "table" else "plain")
        return cls(model, revision=revision, **options)

    def recognize(self, image: Raster) -> Recognition:
        import mlx.core as mx
        from mlx_vlm import load, stream_generate
        from mlx_vlm.prompt_utils import apply_chat_template
        from mlx_vlm.utils import load_config

        if self._loaded is None:
            path = self.model
            if not Path(path).is_dir():
                from huggingface_hub import snapshot_download

                path = snapshot_download(path, revision=self.revision)
            model, processor = load(path)
            self._loaded = model, processor, load_config(path), path
        model, processor, config, path = self._loaded
        # MLX-VLM's loader annotation omits the detokenizer it installs at runtime.
        processor = cast(Any, processor)
        formatted = apply_chat_template(processor, config, self.prompt, num_images=1)
        if not isinstance(formatted, str):
            raise ExtractionError("selected MLX model requires an unsupported prompt template", details=formatted)
        settings = {
            "backend": "mlx-vlm",
            "version": _version("mlx-vlm"),
            "model": self.model,
            "revision": self.revision,
            "resolved_path": path,
            "prompt": self.prompt,
            "formatted_prompt": formatted,
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
            "seed": self.seed,
            "text_format": self.text_format,
        }
        mx.random.seed(self.seed)
        parts, last = [], None
        # Use MLX-VLM's supported path input, as in the qualified experiment.
        with TemporaryDirectory(prefix="spicy-docs-mlx-") as directory:
            source = Path(directory) / "page.png"
            source.write_bytes(image.data)
            for item in stream_generate(
                model, processor, formatted, image=str(source), max_tokens=self.max_tokens, temperature=self.temperature
            ):
                parts.append(item.text)
                last = item
        text = "".join(parts)
        raw = {
            "text": text,
            "finish_reason": getattr(last, "finish_reason", None),
            "prompt_tokens": getattr(last, "prompt_tokens", None),
            "generation_tokens": getattr(last, "generation_tokens", None),
        }
        if last is None or raw["finish_reason"] != "stop" or (raw["generation_tokens"] or 0) >= self.max_tokens:
            raise ExtractionError("MLX generation did not complete", details={"configuration": settings, "raw": raw})
        return Recognition(text, settings, raw, text_format=self.text_format)

    def close(self):
        self._loaded = None
