"""The one owner of "is this answer an error, wall or interstitial page, not the requested object?"

Every check here reads the answer's own bytes (and, for GovInfo, the URL it
came from); none decides what a source does about it. Callers:

* the walled-fetch ladder (``sources/walled_fetch.py``) escalates to its next
  rung on any match of :func:`detect_error_page`;
* sources name their refusals from :func:`detect_wall` families
  (CFTC, FCC ECFS, FERC, USITC, regulations.gov attachments);
* GovInfo's soft-404 witnesses refuse its HTTP-200 error page
  (GovInfo bodies, BILLS bulk, the Federal Register granule route);
* page readers refuse a whole error title (:func:`error_page_title`; SpicyRegs' FEC context pages);
* SpicyRegs' evidence audit sniffs HTML where data was expected (:func:`sniff`).

Source-specific content assertions -- a portal's own page marker, a caption
naming the requested session, an XML root -- stay with their source: they say
what the right page is, which this module cannot know.

This module imports only :mod:`spicy_docs.reading.pdf_bytes`, so a validator
that needs one rule here does not import a source family.
"""

from __future__ import annotations

import html
import re
from typing import Final, Literal, Self
from urllib.parse import urlsplit

from spicy_docs.reading.pdf_bytes import PDF_MAGIC

type WallFamily = Literal["akamai", "cloudflare", "cloudfront", "datadome", "generic"]
#: A wall family, or a page that is not a wall but is still not the requested object.
type ErrorPageFamily = (
    WallFamily | Literal["govinfo-error", "s3-access-denied", "interstitial-title", "unexpected-html"]
)

_WALL_FAMILIES: Final = frozenset({"akamai", "cloudflare", "cloudfront", "datadome", "generic"})

#: Only a body's head is read for walls: the measured block pages are under 6 KiB.
_WALL_SCAN_BYTES: Final = 64 * 1024

#: Block-page chrome: strings a block page carries and a publisher's own text
#: does not, so they mark a wall on any answer. Each family names the longer,
#: more specific wording first. Seeded from the per-host captures of the proxy
#: client smoke harness (``tools/analysis/proxy_client_smoke.py``, 2026-09-24).
#: ``bazadebezolkohpepadr`` (Akamai Bot Manager's script tag) is deliberately
#: NOT a marker: measured 2026-09-24, the real 1,374-byte FCC ECFS React shell
#: carries it while being the publisher's page, not a wall (receipt
#: firecrawl-client-smoke-2026-09-24); on Akamai hosts the script is injected
#: into legitimate HTML too.
_BLOCK_PAGE_MARKERS: Final[tuple[tuple[WallFamily, tuple[bytes, ...]], ...]] = (
    ("akamai", (b"You don't have permission to access", b"errors.edgesuite.net", b"AkamaiGHost")),
    ("cloudflare", (b"Attention Required! | Cloudflare", b"Sorry, you have been blocked", b"Cloudflare Ray ID")),
    # DataDome's challenge loads from its own host; cbo.gov's 767-byte refusal
    # (tests/fixtures/cbo/cbo-datadome-challenge.html) carries it twice. Genuine
    # cbo.gov pages archived by Common Crawl (publications 62589 and 62720,
    # CC-MAIN-2026-43) carry an ``x-datadome: protected`` header and a
    # ``ddjskey`` tag but never this host, so the header is not a marker.
    ("datadome", (b"captcha-delivery.com",)),
)
#: Generic words a block page also carries but a publisher's own text can
#: quote, so they mark a wall only on a refusal (401/403/429). Measured
#: 2026-09-25 over the pinned 23,889,661-row regulations.gov comments Parquet
#: and 1,000 real PDFs (receipt supply-2026-09-02/receipts/
#: wall-marker-prevalence-2026-09-25/result.json): 53 comment bodies (63 rows
#: counting extracted attachment text) contain one, while no row contains a
#: block-page marker and no PDF contains either vocabulary; Arrow re-derived
#: the comment counts (crosscheck.json). The CloudFront words are
#: regulations.gov's 919-byte 403 block page (moved here from its attachment
#: route; receipt supply-2026-09-02/receipts/publisher-questions-2026-09-14/
#: q2-regulations-gov-403): CloudFront's own 5xx pages carry the first line
#: too, so it is refusal-only like the other generic words.
_REFUSAL_MARKERS: Final[tuple[tuple[WallFamily, tuple[bytes, ...]], ...]] = (
    ("akamai", (b"Access Denied",)),
    ("cloudflare", (b"You are unable to access", b"Attention Required", b"Just a moment", b"cf-ray")),
    ("cloudfront", (b"The request could not be satisfied", b"Request blocked")),
    ("generic", (b"captcha",)),
)

#: ``<div id="root">`` and the JavaScript notice are the telltales the
#: measured 2026-09-24 FCC ECFS viewer shell carries; a wall-marked body is a
#: wall, never a shell, so the shell check consults the wall vocabulary first.
_SPA_SHELL_MARKERS: Final = (b'<div id="root">', b"You need to enable JavaScript")

#: GovInfo sends a request for an object it does not have (a missing package,
#: an unoffered rendition) to this page, which answers HTTP 200 -- the
#: publisher's soft-404. Two independent witnesses: the URL a response came
#: from, and the page's own link to that address in its bytes. Its measured
#: length (44,165 bytes in 2026-09, 44,172 on 2026-11-08) is that page's size,
#: not an identity rule. The witnesses stay separable because callers
#: interleave them with their locator check differently (docs/decisions.md,
#: "GovInfo package bodies are fetched by package id, never crawled").
GOVINFO_ERROR_PAGE_URL: Final = "https://www.govinfo.gov/error"
_GOVINFO_ERROR_PAGE: Final = ("https", "www.govinfo.gov", "/error")
_GOVINFO_ERROR_MARKER: Final = re.compile(rb"govinfo\.gov/error", re.IGNORECASE)

#: S3's error document for a key the bucket policy refuses (regulations.gov's
#: 111-byte 403, stable digest across the 2026-09-14 captures). It states a
#: permission decision, not absence, and is never a wall: the bucket answers
#: every client alike.
_S3_ACCESS_DENIED_MARKER: Final = b"<Code>AccessDenied</Code>"

#: Whole page titles that name an error or interstitial page rather than a
#: document: the four SpicyRegs' FEC context pages counted as failed pages, and
#: the interstitials FEC's collection reader refused (Cloudflare's exact
#: "Just a moment..." among them). Only the whole title counts: a document can
#: be titled "Access Denied: Barriers to Veterans Care", and a bill can be the
#: "Just a Moment Act". FEC's collection reader keeps its own phrase search.
_ERROR_TITLES: Final = frozenset(
    {
        "server error",
        "403 forbidden",
        "404 not found",
        "access denied",
        "request rejected",
        "just a moment",
        "just a moment...",
        "verify you are human",
    }
)
#: ``<title>`` itself, never ``<titleInfo>`` or another element whose name starts with it.
_TITLE: Final = re.compile(rb"<title(?:\s[^>]*)?>(.*?)</title\s*>", re.IGNORECASE | re.DOTALL)

#: Leading bytes read to tell HTML from the data a capture was requested as.
SNIFF_BYTES: Final = 4096
_PROLOG: Final = re.compile(rb"\s*(?:<\?.*?\?>|<!--.*?-->|<!doctype\s+([A-Za-z]+)[^>]*>)", re.IGNORECASE | re.DOTALL)
_ELEMENT: Final = re.compile(rb"\s*<(?:[A-Za-z_][\w.-]*:)?([A-Za-z_][\w.-]*)")
#: HTML elements an error or warning page can open with (a PHP warning opens with ``<br />``); no XML payload
#: SpicyRegs or the walled routes read has one of these as its document element.
_HTML_ROOTS: Final = frozenset(
    b"""a b body br center div em font form h1 h2 h3 h4 h5 h6 head hr html i iframe img li link meta
    noscript ol p pre script span strong style title u ul""".split()
)
#: Compression a response body can carry that SpicyRegs' ``Scan`` does not decode; each is reported as a limit.
UNDECODED_COMPRESSION: Final = ((b"BZh", "bzip2"), (b"\xfd7zXZ\x00", "xz"), (b"\x28\xb5\x2f\xfd", "zstd"))
_HTML_MEDIA_TYPES: Final = frozenset({"text/html", "application/xhtml+xml"})


class ErrorPageMarker(str):
    """The marker a body matched -- its text, the only evidence ever quoted -- and its ``family``."""

    family: ErrorPageFamily

    def __new__(cls, marker: str, family: ErrorPageFamily) -> Self:
        match = super().__new__(cls, marker)
        match.family = family
        return match

    @property
    def wall(self) -> bool:
        """Whether an edge refused this client (a proxy may get through), not a publisher's own page."""
        return self.family in _WALL_FAMILIES


def detect_wall(body: bytes, *, refusal: bool | None = None) -> ErrorPageMarker | None:
    """The wall marker this body matches, or ``None`` when it matches none.

    Substring checks on the first 64 KiB of the exact bytes, no regex; a body
    that starts ``%PDF-`` is never a wall. Block-page chrome counts on any
    answer. The generic words count only when ``refusal`` is true (the answer
    was a 401/403/429) or unstated (``None``, the whole vocabulary a caller
    that does not pass the status has always had); ``refusal=False`` is any
    other answer, such as a 2xx.
    """
    if body.startswith(PDF_MAGIC):
        return None
    head = body[:_WALL_SCAN_BYTES]
    vocabulary = _BLOCK_PAGE_MARKERS if refusal is False else _BLOCK_PAGE_MARKERS + _REFUSAL_MARKERS
    for family, markers in vocabulary:
        for marker in markers:
            if marker in head:
                return ErrorPageMarker(marker.decode("utf-8", "backslashreplace"), family)
    return None


def detect_spa_shell(body: bytes) -> bool:
    """Whether this body is a SPA viewer shell: a client-rendered app page, never a wall.

    The body carries the React mount point ``<div id="root">`` and/or the
    JavaScript notice, and no wall marker. A shell is the publisher's own
    answer, so it is not an error page; a caller that must name it (the FCC
    ECFS route) uses this check.
    """
    if detect_wall(body) is not None:
        return False
    return any(marker in body for marker in _SPA_SHELL_MARKERS)


def is_govinfo_error_url(final_url: str) -> bool:
    """The response came from GovInfo's error page, whatever query it carries."""
    parsed = urlsplit(final_url)
    return (parsed.scheme, parsed.netloc, parsed.path) == _GOVINFO_ERROR_PAGE


def has_govinfo_error_marker(body: bytes) -> bool:
    """The bytes carry GovInfo's error page's link to itself."""
    return _GOVINFO_ERROR_MARKER.search(body) is not None


def check_not_govinfo_error_page(body: bytes, final_url: str, *, error_type: type[ValueError], message: str) -> None:
    """Refuse on either GovInfo witness; the caller supplies its own wording."""
    if is_govinfo_error_url(final_url) or has_govinfo_error_marker(body):
        raise error_type(message)


def error_page_title(title: str) -> str | None:
    """The title, when the whole of it names an error or interstitial page; ``None`` otherwise.

    Read from an already parsed title; case and runs of whitespace are ignored.
    """
    text = " ".join(title.split())
    return text if text.casefold() in _ERROR_TITLES else None


def _title_of(body: bytes) -> str | None:
    match = _TITLE.search(body[:_WALL_SCAN_BYTES])
    return html.unescape(match.group(1).decode("utf-8", "replace")) if match else None


def sniff(head: bytes) -> str:
    """Classify leading bytes: html, xml, json, pdf, zip, gzip, text, binary or empty.

    Looks past a BOM, an XML declaration, comments and a DOCTYPE, so an XHTML
    error page behind an XML prolog is HTML. ``transport.download.
    validate_body_prefix`` reads only the first tag, which that page passes.
    """
    text = head.removeprefix(b"\xef\xbb\xbf").lstrip()
    if not text:
        return "empty"
    for magic, kind in ((b"%PDF", "pdf"), (b"PK\x03\x04", "zip"), (b"\x1f\x8b", "gzip"), *UNDECODED_COMPRESSION):
        if text.startswith(magic):
            return kind
    if text[:1] in (b"{", b"["):
        return "json"
    if not text.startswith(b"<"):
        return "binary" if b"\x00" in text else "text"
    position, doctype = 0, b""
    while match := _PROLOG.match(text, position):
        doctype, position = doctype or (match.group(1) or b""), match.end()
    element = _ELEMENT.match(text, position)
    root = element.group(1).lower() if element else b""
    return "html" if doctype.lower() == b"html" or root in _HTML_ROOTS else "xml"


def detect_error_page(
    body: bytes,
    *,
    status_code: int | None = None,
    url: str | None = None,
    media_types: tuple[str, ...] | None = None,
) -> ErrorPageMarker | None:
    """Whether an answer is a wall, an error or an interstitial page rather than the requested object.

    In order: S3's AccessDenied document, a wall (:func:`detect_wall`; the
    generic words only on a 401/403/429 or an unstated status), GovInfo's
    soft-404 (its URL, or its marker on a GovInfo URL), and, on any answer
    other than a refusal, on an HTML body only: a whole error or interstitial
    title, then HTML where
    ``media_types`` asked for no HTML. A PDF and an empty body are never an
    error page. The caller decides what a match means; ``marker.wall`` tells
    an edge refusal from a publisher's own page.
    """
    if not body or body.startswith(PDF_MAGIC):
        return None
    refusal = None if status_code is None else status_code in (401, 403, 429)
    # S3's document first: its <Message>Access Denied</Message> would
    # otherwise read as Akamai's refusal words on the 403 it comes with.
    if _S3_ACCESS_DENIED_MARKER in body[:_WALL_SCAN_BYTES]:
        return ErrorPageMarker(_S3_ACCESS_DENIED_MARKER.decode(), "s3-access-denied")
    if (wall := detect_wall(body, refusal=refusal)) is not None:
        return wall
    if url is not None and (
        is_govinfo_error_url(url) or (urlsplit(url).netloc == _GOVINFO_ERROR_PAGE[1] and has_govinfo_error_marker(body))
    ):
        return ErrorPageMarker("govinfo.gov/error", "govinfo-error")
    if refusal:
        return None
    if sniff(body[:SNIFF_BYTES]) != "html":
        return None
    title = _title_of(body)
    if title is not None and (phrase := error_page_title(title)) is not None:
        return ErrorPageMarker(phrase, "interstitial-title")
    expected = {media_type.split(";", 1)[0].strip().lower() for media_type in media_types or ()}
    if expected and not expected & _HTML_MEDIA_TYPES:
        return ErrorPageMarker("html", "unexpected-html")
    return None


__all__ = [
    "GOVINFO_ERROR_PAGE_URL",
    "SNIFF_BYTES",
    "UNDECODED_COMPRESSION",
    "ErrorPageFamily",
    "ErrorPageMarker",
    "WallFamily",
    "check_not_govinfo_error_page",
    "detect_error_page",
    "detect_spa_shell",
    "detect_wall",
    "error_page_title",
    "has_govinfo_error_marker",
    "is_govinfo_error_url",
    "sniff",
]
