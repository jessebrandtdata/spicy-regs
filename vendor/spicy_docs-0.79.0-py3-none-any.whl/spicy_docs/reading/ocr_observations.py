"""Bind unplaced OCR text to an exact, measured source-image region.

Source readers decide which rows a region contains and how to associate them.
These shared objects retain input identity without assigning model geometry.
"""

from __future__ import annotations

import base64
import gzip
import hashlib
import io
import json
import re
from copy import deepcopy
from dataclasses import dataclass

from spicy_docs.extraction import Box, Raster
from spicy_docs.extraction.model import Observation, Recognition
from spicy_docs.extraction.pages import crop


def evidence_sha256(data):
    return "sha256:" + hashlib.sha256(data).hexdigest()


def pixels_sha256(data):
    """Identify an image by its decoded mode, size and pixels, not its encoded bytes.

    One crop re-encodes to different PNG bytes per platform (Pillow's macOS
    wheels compress with zlib-ng, its Linux wheels with zlib), so a replay can
    reproduce the pixels a model saw but not always its exact input bytes.
    """
    from PIL import Image

    with Image.open(io.BytesIO(data)) as image:
        return evidence_sha256(f"{image.mode} {image.width}x{image.height}\n".encode() + image.tobytes())


def box_coordinates(box):
    return [box.x0, box.y0, box.x1, box.y1]


@dataclass(frozen=True)
class OcrRegion:
    id: str
    raster: Raster
    row_ids: tuple[str, ...]
    field_block_index: int | None = None


@dataclass(frozen=True)
class OcrView:
    region: OcrRegion
    reading: Recognition | Observation

    @property
    def text(self):
        """Keep Docling's original VLM lines before Markdown conversion."""
        raw = self.reading.raw
        if isinstance(raw, dict) and "pages" in raw:
            pages = raw["pages"]
            if len(pages) != 1:
                raise ValueError("An OCR view must contain exactly one model page")
            response = pages[0].get("predictions", {}).get("vlm_response")
            if response is not None:
                return response["text"]
        if self.reading.text_format != "plain":
            raise ValueError("OCR association requires original plain model lines")
        return self.reading.text

    @property
    def evidence(self):
        return {
            "id": self.region.id,
            "input_sha256": evidence_sha256(self.region.raster.data),
            "response_text_sha256": evidence_sha256(self.text.encode()),
            "configuration_sha256": evidence_sha256(
                json.dumps(self.reading.configuration, sort_keys=True, separators=(",", ":")).encode()
            ),
            "region": box_coordinates(self.region.raster.box),
            "model_geometry": None,
        }


def _same_pixels(expected, actual):
    try:
        return pixels_sha256(expected) == pixels_sha256(actual)
    except OSError:  # Undecodable bytes are not the claimed crop.
        return False


def validate_view_image(image, view):
    """Refuse claimed regions whose actual pixels differ from the source crop."""
    raster = view.region.raster
    expected = image if raster.box == Box() else crop(image, raster.box)
    if (expected.width, expected.height) != (raster.width, raster.height) or (
        expected.data != raster.data and not _same_pixels(expected.data, raster.data)
    ):
        raise ValueError("OCR view bytes do not match its claimed original-image crop")


def retained_structured_observation(result, image):
    """Read one pinned full-page Gemini observation, keeping geometry absent.

    Checks the actual encoded model input and response, not merely the echoed
    outcome. No source accuracy or review decision follows from this check.
    """
    from spicy_docs.extraction.gemini import read_structured_response

    observations = result.get("observations", [])
    if len(observations) != 1 or image.box != Box():
        raise ValueError("Structured replay requires one complete page observation")
    observation = observations[0]
    config = observation["configuration"]
    if config.get("backend") != "gemini" or config.get("mode") != "structured":
        raise ValueError("Structured replay requires the retained Gemini structured configuration")
    calls = observation["raw"]["calls"]
    if len(calls) != 1 or calls[0]["stage"] != "structured-page":
        raise ValueError("Structured replay requires one retained structured-page call")
    call = calls[0]
    schema = config["outcome_schema"]
    if (
        call["request"]["generationConfig"] != config["generation"]
        or config["generation"].get("responseJsonSchema") != schema
    ):
        raise ValueError("Structured replay configuration differs from its actual request")
    expected = [
        {
            "role": "user",
            "parts": [
                {"inlineData": {"mimeType": image.media_type, "data": base64.b64encode(image.data).decode()}},
                {"text": config["prompts"]["structured"]},
            ],
        }
    ]
    if call["request"]["contents"] != expected:
        raise ValueError("Structured replay image or prompt differs from the actual model input")
    text, outcome = read_structured_response(call["response"], schema)
    if text != observation["text"] or outcome != observation["raw"]["outcome"]:
        raise ValueError("Retained structured outcome differs from its model response")
    images = observation["images"]
    if len(images) != 1 or any(
        images[0].get(key) != value
        for key, value in {
            "sha256": hashlib.sha256(image.data).hexdigest(),
            "bytes": len(image.data),
            "width": image.width,
            "height": image.height,
            "box": {"x0": 0, "y0": 0, "x1": 1, "y1": 1},
        }.items()
    ):
        raise ValueError("Retained structured image declaration differs from its exact input")
    if observation.get("issues") or outcome.get("uncertainties"):
        raise ValueError("Structured observation has unresolved recognition issues")
    return outcome, config


def _capture_digest(value):
    if not isinstance(value, str) or not re.fullmatch(r"(?:sha256:)?[0-9a-f]{64}", value):
        raise ValueError("Retained capture requires exact SHA-256 identities")
    return value.removeprefix("sha256:")


def _capture_bytes(data, pin, label):
    if (
        not isinstance(data, bytes)
        or not isinstance(pin, dict)
        or type(pin.get("bytes")) is not int
        or pin["bytes"] != len(data)
        or _capture_digest(pin.get("sha256")) != hashlib.sha256(data).hexdigest()
    ):
        raise ValueError(f"Retained capture {label} differs from its selected bytes")


def retained_capture_observation(
    observation_bytes,
    image,
    *,
    page_bytes,
    request_gzip,
    response_bytes,
    plan_bytes,
    binding,
    max_request_bytes=32 * 1024**2,
):
    """Replay separated OpenAI capture evidence offline, without qualifying it.

    ``binding`` selects source_id, source_sha256, source_byte_size, page, and
    exact ``plan`` and ``observation`` pins (sha256/bytes). Receipt paths are
    locators only: a restored local copy must have the same bytes. The caller
    retains the original, plan, request, response and observation, and separately
    establishes source accuracy. This function neither fetches nor submits.
    """
    from PIL import Image

    from spicy_docs.extraction._structured import _strict_json
    from spicy_docs.extraction.openai import OpenAI

    _capture_bytes(plan_bytes, binding["plan"], "plan")
    _capture_bytes(observation_bytes, binding["observation"], "observation")
    plan, observation = _strict_json(plan_bytes), _strict_json(observation_bytes)
    if plan.get("purpose") != "capture" or plan.get("version") != 1:
        raise ValueError("Retained capture requires its versioned capture plan")
    config = plan["configuration"]
    if set(config) != {"provider", "model", "mode", "prompt", "schema", "generation", "service_tier", "detail"} or (
        config["provider"] != "openai" or config["mode"] != "structured"
    ):
        raise ValueError("Retained capture requires the selected OpenAI structured configuration")
    sources = [source for source in plan["sources"] if source["id"] == binding["source_id"]]
    if len(sources) != 1:
        raise ValueError("Retained capture source identity is missing or ambiguous")
    source = sources[0]
    number = binding["page"]
    if (
        type(number) is not int
        or type(source["physical_pages"]) is not int
        or not 1 <= number <= source["physical_pages"]
        or any(type(selected) is not int for selected in source["pages"])
        or source["pages"].count(number) != 1
        or type(binding["source_byte_size"]) is not int
        or binding["source_byte_size"] < 1
        or source["original"]["bytes"] != binding["source_byte_size"]
        or _capture_digest(source["original"]["sha256"]) != _capture_digest(binding["source_sha256"])
    ):
        raise ValueError("Retained capture source/page differs from the selected original")
    _capture_bytes(page_bytes, observation["page"], "page")
    _capture_bytes(response_bytes, observation["response"], "response")
    page, answer = _strict_json(page_bytes), _strict_json(response_bytes)
    identity = {
        "key": f"{binding['source_id']}-p{number}",
        "plan_sha256": hashlib.sha256(plan_bytes).hexdigest(),
        "request_sha256": page["request_sha256"],
    }
    if (
        any(page.get(key) != value for key, value in identity.items())
        or page.get("source_id") != binding["source_id"]
        or page.get("source_sha256") != _capture_digest(binding["source_sha256"])
        or type(page.get("page")) is not int
        or page["page"] != number
        or answer.get("request") != identity
    ):
        raise ValueError("Retained capture page/response belongs to another request")
    _capture_bytes(request_gzip, page["request"], "compressed request")
    limit = plan["limits"]["max_request_bytes"]
    if type(limit) is not int or type(max_request_bytes) is not int or min(limit, max_request_bytes) < 1:
        raise ValueError("Retained capture requires positive request bounds")
    limit = min(limit, max_request_bytes)
    if len(request_gzip) > limit + 1024:
        raise ValueError("Retained compressed request exceeds its byte bound")
    with gzip.GzipFile(fileobj=io.BytesIO(request_gzip)) as stream:
        payload = stream.read(limit + 1)
    if len(payload) > limit or hashlib.sha256(payload).hexdigest() != _capture_digest(page["request_sha256"]):
        raise ValueError("Retained decoded request exceeds its bound or differs from its digest")
    body = _strict_json(payload)
    _capture_bytes(image.data, page["image"], "image")
    if image.box != Box() or image.media_type != "image/png":
        raise ValueError("Retained capture requires the complete PNG model input")
    with Image.open(io.BytesIO(image.data)) as pixels:
        if (
            pixels.format != "PNG"
            or pixels.size != (image.width, image.height)
            or pixels.size
            != (
                page["image"]["width"],
                page["image"]["height"],
            )
        ):
            raise ValueError("Retained capture image dimensions differ from the actual PNG")
        pixels.verify()
    if "response" not in answer or "error" in answer:
        raise ValueError("Retained capture has no successful provider response")
    status = answer.get("transport", {}).get("status_code")
    if status is not None and (type(status) is not int or not 200 <= status < 300):
        raise ValueError("Retained capture transport did not succeed")

    class Replay:
        def generate(self, model, request):
            # JSON equality must distinguish booleans from numbers (True == 1
            # in Python), while permitting irrelevant object key ordering.
            if model != config["model"] or json.dumps(request, sort_keys=True) != json.dumps(body, sort_keys=True):
                raise ValueError("Retained capture configuration/image differs from its actual request")
            return deepcopy(answer["response"])

    recognizer = OpenAI(
        Replay(),
        model=config["model"],
        mode=config["mode"],
        prompt=config["prompt"],
        outcome_schema=config["schema"],
        generation=config["generation"],
        service_tier=config["service_tier"],
        detail=config["detail"],
    )
    reading = recognizer.recognize(image)
    expected = {
        "status": "observed_unqualified",
        "model_geometry": None,
        "configuration": reading.configuration,
        "text": reading.text,
        "outcome": reading.raw["outcome"],
        "issues": list(reading.issues),
    }
    if not expected.keys() <= observation.keys() or json.dumps(
        {key: observation[key] for key in expected}, sort_keys=True
    ) != json.dumps(expected, sort_keys=True):
        raise ValueError("Retained capture observation differs from its response replay")
    # Unreadable cells and explicit uncertainties remain evidence, not an empty
    # success or an implied source-review decision.
    return reading.raw["outcome"], reading.configuration


def observation_sha256(outcome):
    """Identify an observed JSON value independently of object key order."""
    return evidence_sha256(json.dumps(outcome, sort_keys=True, separators=(",", ":")).encode())


def reviewed_observation(outcome, *, binding, qualification, schema, status):
    """Check a source review and apply its exact retained field corrections."""
    if (
        qualification.get("schema") != schema
        or qualification.get("status") != status
        or not qualification.get("review_evidence")
        or qualification.get("binding") != binding
        or any(qualification.get(key) != binding.get(key) for key in ("source_sha256", "source_byte_size", "page"))
        or qualification.get("raw_outcome_sha256") != observation_sha256(outcome)
        or type(binding.get("page")) is not int
        or not 1 <= binding["page"] <= qualification["physical_pages"]
    ):
        raise ValueError("Observation differs from its reviewed identity or scope")
    normalized, audit = apply_reviewed_observation_fields(
        outcome, binding=binding, corrections=qualification.get("corrections", [])
    )
    if qualification["normalized_outcome_sha256"] != observation_sha256(normalized):
        raise ValueError("Observation differs from its reviewed corrected outcome")
    return normalized, audit


def apply_reviewed_observation_fields(outcome, *, binding, corrections):
    """Apply exactly reviewed existing fields to a copy; retain raw observations.

    This is the unpositioned equivalent of the manual OCR transcription guard:
    source/image/model identities and exact before values must all match. It
    supplies no geometry, review decision, or automatic recognition credit.
    """
    normalized, audit, paths = deepcopy(outcome), [], []
    for rule in corrections:
        if rule.get("method") != "manual_review" or any(rule.get(key) != value for key, value in binding.items()):
            raise ValueError("Reviewed observation correction differs from its source/image/model binding")
        if not rule.get("reason") or not rule.get("review_evidence") or not rule.get("edits"):
            raise ValueError("Reviewed observation correction lacks its reason, review or edits")
        for review in rule["review_evidence"]:
            if not re.fullmatch(r"sha256:[0-9a-f]{64}", review.get("sha256", "")):
                raise ValueError("Reviewed observation correction requires exact independent review pins")
        for edit in rule["edits"]:
            path = edit["path"]
            if not isinstance(path, list) or not path or any(type(key) not in {int, str} for key in path):
                raise ValueError("Reviewed observation correction requires an explicit field path")
            if any(path[: len(prior)] == prior or prior[: len(path)] == path for prior in paths):
                raise ValueError("Reviewed observation correction repeats or overlaps an edited field")
            target = normalized
            try:
                for key in path[:-1]:
                    if isinstance(key, int) and key < 0:
                        raise KeyError(key)
                    target = target[key]
                key = path[-1]
                if isinstance(key, int) and key < 0:
                    raise KeyError(key)
                if target[key] != edit["before"] or type(edit["after"]) is not type(edit["before"]):
                    raise ValueError("Reviewed observation correction differs from its exact before value")
                target[key] = deepcopy(edit["after"])
            except (KeyError, IndexError, TypeError):
                raise ValueError("Reviewed observation correction names a missing field") from None
            paths.append(path)
        audit.append(deepcopy(rule))
    return normalized, audit
