"""Printed committee rosters from a GovInfo Congressional Directory (``CDIR``) package.

The directory is the publisher's per-Congress record (GPO for the Joint Committee on Printing). Its committee
granules print each committee and subcommittee list as fixed-width text in the ``htm`` rendition: an optional
chair line (and vice chair or ranking line), then the majority in the left column and the minority in the right.
The package MODS states each member's ``bioGuideId``, chamber, party, state and Congress.

This module reads those two inputs and nothing else. It returns what is *printed*: one :class:`PrintedSeat` per
roster entry, with its granule line, printed name, state, printed role and printed side, and one
:class:`PrintedDisposition` per line it read but could not turn into a seat (a vacancy, or text it could not
interpret). It never maps a committee name to a code or a printed name to a member; that is the consumer's
interpretation (spicy-regs ``build_committee_rosters``). Nothing printed is dropped silently.

Limits, measured on CDIR-2014-02-18 and CDIR-2022-10-26 (2026-11-08):

- One package is one dated snapshot; changes during a Congress are invisible.
- Order is print order within a list. The side is the printed column, not the member's party.
- A "Ranking Member" label is rarely printed; :func:`printed_sides` says which entry heads the minority column.
- Ex officio members appear only where printed.
"""

from __future__ import annotations

import html
import re
import unicodedata
from collections import Counter
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field

from spicy_docs.reading.xml_tree import XmlTreeElement, read_xml_tree
from spicy_docs.sources.govinfo.mods import MODS_NAMESPACE, RETAINED_MODS_MAX_ELEMENTS

#: The collection, and the granule titles that hold committee rosters. The publisher numbers its granules per
#: edition (``-2``, ``-4``), so a granule is chosen by the title it states, never by its suffix.
DIRECTORY_COLLECTION = "CDIR"
ROSTER_GRANULE_TITLES: Mapping[str, str] = {
    "STANDING COMMITTEES OF THE SENATE": "senate",
    "SELECT AND SPECIAL COMMITTEES OF THE SENATE": "senate",
    "STANDING COMMITTEES OF THE HOUSE": "house",
    "SELECT AND SPECIAL COMMITTEES OF THE HOUSE": "house",
    "JOINT COMMITTEES": "joint",
}
#: Bump when the reading of a granule or the MODS changes.
DIRECTORY_ROSTER_RULE_VERSION = "1"
MAX_MODS_BYTES = 8 * 1024 * 1024

STATES: Mapping[str, str] = {
    "Alabama": "AL", "Alaska": "AK", "Arizona": "AZ", "Arkansas": "AR", "California": "CA", "Colorado": "CO",
    "Connecticut": "CT", "Delaware": "DE", "Florida": "FL", "Georgia": "GA", "Hawaii": "HI", "Idaho": "ID",
    "Illinois": "IL", "Indiana": "IN", "Iowa": "IA", "Kansas": "KS", "Kentucky": "KY", "Louisiana": "LA",
    "Maine": "ME", "Maryland": "MD", "Massachusetts": "MA", "Michigan": "MI", "Minnesota": "MN",
    "Mississippi": "MS", "Missouri": "MO", "Montana": "MT", "Nebraska": "NE", "Nevada": "NV",
    "New Hampshire": "NH", "New Jersey": "NJ", "New Mexico": "NM", "New York": "NY", "North Carolina": "NC",
    "North Dakota": "ND", "Ohio": "OH", "Oklahoma": "OK", "Oregon": "OR", "Pennsylvania": "PA",
    "Rhode Island": "RI", "South Carolina": "SC", "South Dakota": "SD", "Tennessee": "TN", "Texas": "TX",
    "Utah": "UT", "Vermont": "VT", "Virginia": "VA", "Washington": "WA", "West Virginia": "WV",
    "Wisconsin": "WI", "Wyoming": "WY", "District of Columbia": "DC", "Puerto Rico": "PR", "Guam": "GU",
    "American Samoa": "AS", "Virgin Islands": "VI", "Northern Mariana Islands": "MP",
}  # fmt: skip
_STATE = "|".join(sorted((re.escape(s) for s in STATES), key=len, reverse=True))
_FROM = r"(?:of|(?P<office>Representative|Senator|Delegate|Resident Commissioner)(?: from|,))"
_ROLE = (
    r"(?:Acting |Vice[ -]|Co-)?(?:Chair\w*|Ranking(?: (?:Minority )?Member)?|Ex Officio)"
    r"|[A-Z][A-Za-z ]*Leader|Speaker of the House|Secretary"
)
#: "Name, of State[, Role]." The "of" is sometimes omitted ("Frank A. LoBiondo, New Jersey, Chair", CDIR-2016-02-12).
ENTRY = re.compile(rf"^(?P<name>.+?)(?:,? {_FROM}|,) (?P<state>{_STATE})(?:[,.] (?P<role>{_ROLE}))?\.?$")
#: Lines that are an office address, contact or note rather than a title or roster entry.
ADDRESS = re.compile(
    r"Building\b|phone|https?://|fax|TTY|[Rr]oom |Suite |\bThe Capitol\b|^\[|Created pursuant|20510|20515"
    r"|^[\d\s(),.-]+$|^(?:Majority|Minority) \(|\((?:Majority|Minority)\)|[Mm]eets |\bDC \d{5}"
    # The tail of a wrapped address or URL on its own line ("4784,", "armed_services").
    r"|^[a-z_./-]+$",
    re.MULTILINE,
)
#: Printed role labels and the one spelling each normalizes to; the printed label is kept beside it.
ROLES: Mapping[str, str] = {
    "chair": "Chair", "chairman": "Chair", "chairwoman": "Chair", "chairperson": "Chair",
    "co-chair": "Co-Chair", "co-chairman": "Co-Chair", "co-chairwoman": "Co-Chair",
    "vice chair": "Vice Chair", "vice chairman": "Vice Chair", "vice chairwoman": "Vice Chair",
    "vice-chair": "Vice Chair", "vice-chairman": "Vice Chair", "vice-chairwoman": "Vice Chair",
    "ranking member": "Ranking Member", "ranking minority member": "Ranking Member", "ranking": "Ranking Member",
    "ex officio": "Ex Officio",
}  # fmt: skip
#: The column window GPO's two-column lists split in, measured on both sample editions: 36-46.
_COLUMN_WINDOW = (28, 48)
#: How far a line's own gap may sit from the list's column and still be that column's split.
_COLUMN_SLACK = 6


class DirectoryRosterError(ValueError):
    """The input is not a Congressional Directory roster this reader can establish."""


def normalize_role(printed: str | None) -> str | None:
    """The normalized role for a printed label (Chairman → Chair), or the label itself when unknown."""
    if not printed:
        return None
    label = printed.strip().rstrip(".")
    return ROLES.get(label.lower(), label)


def normalize_name(text: str) -> str:
    """Lower-case ASCII words: the form printed names and MODS names are compared in."""
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    text = text.replace("``", "").replace("''", "")
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]", " ", text.lower())).strip()


# ---------------------------------------------------------------- package MODS


@dataclass(frozen=True, slots=True)
class DirectoryMember:
    """One ``congMember`` the package MODS states."""

    bioguide_id: str
    chamber: str  # H or S, as the MODS states it
    state: str
    party: str
    congress: str
    names: tuple[str, ...]  # every stated name form, normalized
    last_name: str  # normalized, from the authority-lnf form


@dataclass(frozen=True, slots=True)
class DirectoryEdition:
    """What the package MODS states about the edition: its Congress, issue date and members."""

    package_id: str
    congress: str
    date_issued: str
    members: tuple[DirectoryMember, ...]


def _walk(element: XmlTreeElement) -> Iterable[XmlTreeElement]:
    pending = [element]
    while pending:
        node = pending.pop()
        yield node
        pending.extend(reversed(node.children))


def read_directory_mods(body: bytes) -> DirectoryEdition:
    """The edition's package id, Congress, ``dateIssued`` and members from its package MODS.

    The Congress is the package's own ``extension/congress``. A member stating another Congress is refused rather
    than guessed. A package may state no members at all (CDIR-2024-04-25 and CDIR-2026-02-20 serve no granules and
    no ``congMember``, measured 2026-11-08); that is an empty ``members``, for the caller to judge.
    """
    tree = read_xml_tree(
        body,
        expected_root=f"{{{MODS_NAMESPACE}}}mods",
        error_type=DirectoryRosterError,
        label="CDIR package MODS",
        max_bytes=MAX_MODS_BYTES,
        max_elements=RETAINED_MODS_MAX_ELEMENTS,
    ).element
    ns = f"{{{MODS_NAMESPACE}}}"
    package_id = date_issued = None
    congress = next((c.text.strip() for e in tree.findall(f"{ns}extension") for c in e.findall(f"{ns}congress")), None)
    members: dict[str, DirectoryMember] = {}
    congresses: Counter[str] = Counter()
    for node in _walk(tree):
        if node.name == f"{ns}recordIdentifier" and package_id is None:
            package_id = node.text.strip()
        elif node.name == f"{ns}dateIssued" and date_issued is None:
            date_issued = node.text.strip()
        elif node.name == f"{ns}congMember":
            bioguide = (node.attribute("bioGuideId") or "").strip()
            if not bioguide:
                continue
            congresses[(node.attribute("congress") or "").strip()] += 1
            forms = {(n.attribute("type") or ""): n.text for n in node.findall(f"{ns}name")}
            last = normalize_name(forms.get("authority-lnf", "").split(",")[0])
            names = tuple(sorted({normalize_name(v) for k, v in forms.items() if k != "authority-lnf" and v.strip()}))
            members[bioguide] = DirectoryMember(
                bioguide,
                (node.attribute("chamber") or "").strip(),
                (node.attribute("state") or "").strip(),
                (node.attribute("party") or "").strip(),
                (node.attribute("congress") or "").strip(),
                names,
                last,
            )
    if not package_id or not package_id.startswith(f"{DIRECTORY_COLLECTION}-") or not date_issued:
        raise DirectoryRosterError("CDIR package MODS states no CDIR package id or dateIssued")
    if not congress or not congress.isdigit():
        raise DirectoryRosterError(f"{package_id}: the package MODS states no Congress")
    if set(congresses) - {congress}:
        raise DirectoryRosterError(f"{package_id}: members state Congresses {dict(congresses)}, not {congress}")
    return DirectoryEdition(package_id, congress, date_issued, tuple(members.values()))


def roster_granules(granules: Iterable[Mapping[str, object]]) -> dict[str, str]:
    """``{granuleId: chamber}`` for the granules of a package listing that print committee rosters.

    ``chamber`` is ``house``, ``senate`` or ``joint``. A listing that names none of the expected titles returns an
    empty mapping; the caller decides whether that is a refusal.
    """
    chosen: dict[str, str] = {}
    for granule in granules:
        title = str(granule.get("title") or "").strip().upper()
        if title in ROSTER_GRANULE_TITLES:
            chosen[str(granule.get("granuleId"))] = ROSTER_GRANULE_TITLES[title]
    return chosen


# ---------------------------------------------------------------- committee text


@dataclass(frozen=True, slots=True)
class PrintedSeat:
    """One printed roster entry."""

    granule_id: str
    line: int  # 1-based line in the granule's text
    committee: str  # the full committee's printed title
    subcommittee: str | None  # the subcommittee's printed title, if the list is one
    name: str  # printed member name
    state: str  # two-letter state code
    printed_role: str | None  # the label as printed ("Chairman", "Vice Chair"), or "Ex Officio" from a heading
    role: str | None  # normalize_role(printed_role)
    side: str  # chair (a line above the columns), majority (left), minority (right), single (one column)
    order: int  # print order within the list, 1-based, chair lines first
    member_chamber: str | None  # H or S where the text says so (a joint list's HOUSE/SENATE heading or office)


@dataclass(frozen=True, slots=True)
class PrintedDisposition:
    """A printed line that is not a seat: ``vacancy`` or ``unread_text``."""

    granule_id: str
    line: int
    context: str
    kind: str
    text: str


@dataclass
class PrintedGranule:
    granule_id: str
    chamber: str
    seats: list[PrintedSeat] = field(default_factory=list)
    dispositions: list[PrintedDisposition] = field(default_factory=list)


def text_lines(body: bytes) -> list[str]:
    """The granule's ``<pre>`` text, tags removed and entities decoded, as lines."""
    text = body.decode("utf-8", "replace")
    text = text.split("<pre>", 1)[-1].split("</pre>", 1)[0]
    return html.unescape(re.sub(r"<[^>]+>", "", text)).splitlines()


def _indent(line: str) -> int:
    return len(line) - len(line.lstrip(" "))


def _column(block: list[str]) -> int | None:
    """The most common right-column start across a block, from gaps of two or more spaces inside a line."""
    starts: Counter[int] = Counter()
    for line in block:
        for match in re.finditer(r"\S\s{2,}(?=\S)", line):
            if _COLUMN_WINDOW[0] <= match.end() <= _COLUMN_WINDOW[1]:
                starts[match.end()] += 1
    return starts.most_common(1)[0][0] if starts else None


def _split(line: str, column: int) -> tuple[str, str]:
    """One line's left and right fragments.

    GPO aligns the right column only approximately: a wrapped right-hand continuation can start a few places left
    of the column (CDIR-2014-02-18, Joint Committee on Printing: "Georgia." at 41 under a column at 45). A line's
    own gap near the column is its split; a line holding one fragment that starts near the column is right-hand.
    """
    gaps = [m.end() for m in re.finditer(r"\S\s{2,}(?=\S)", line) if abs(m.end() - column) <= _COLUMN_SLACK]
    if gaps:
        cut = min(gaps, key=lambda p: abs(p - column))
        return line[:cut], line[cut:]
    if line.strip() and _indent(line) >= column - _COLUMN_SLACK:
        return "", line
    return line, ""


def _entries(fragments: list[tuple[int, str]]) -> tuple[list[tuple[int, str]], list[tuple[int, str]]]:
    """Join wrapped column fragments into entries; returns (entries, leftovers)."""
    out: list[tuple[int, str]] = []
    buf, start = "", None
    for line_no, fragment in fragments:
        fragment = " ".join(fragment.split())
        if not fragment:
            continue
        # A fragment that is itself a whole entry closes the previous one rather than gluing onto it, while a role
        # label wrapped without its period ("..., Ranking" / "Member") still joins its entry.
        if buf and ENTRY.match(fragment) and ENTRY.match(buf.rstrip(".,")):
            out.append((start, buf.rstrip(".,") + "."))
            buf, start = "", None
        if start is None:
            start = line_no
        buf = f"{buf} {fragment}".strip()
        if buf.endswith(".") and (ENTRY.match(buf) or buf == "Vacant."):
            out.append((start, buf))
            buf, start = "", None
    if buf and ENTRY.match(buf):  # a final entry printed without its period
        out.append((start, buf + "."))
        buf = ""
    return out, ([(start, buf)] if buf else [])


#: Notes printed where a subcommittee list would be; they carry no roster.
_NO_SUBCOMMITTEES = {"(NO SUBCOMMITTEES)", "NO SUBCOMMITTEES"}
#: Endings that say a title continues on the next printed line, past a blank line
#: (CDIR-2018-10-01, Senate Appropriations: "Transportation, Housing and Urban Development," / "and Related Agencies").
_CONTINUES = re.compile(r"(?:,|\band|\bof|\bthe|\bon|\bfor|\bto)$")
#: A title's printed acronym on its own line ("(EMDC)", CDIR-2014-02-18) also continues it.
_ACRONYM = re.compile(r"^\([A-Z]{2,}\)$")
#: A chair printed as not yet named.
_VACANT_CHAIR = re.compile(r"^(?:Vacant|TBD), (?:Chair\w*|Ranking)")


def _roster_margin(line: str) -> bool:
    """A line at a roster list's left margin: indent six or less, or up to eight for an entry (joint lists)."""
    indent = _indent(line)
    return indent <= 6 or (indent <= 8 and ", of " in line)


def _heads_list(line: str) -> bool:
    """A chair line, a vacant chair, or a first roster entry: what follows a (sub)committee title."""
    stripped = line.strip().rstrip(".")
    return bool(ENTRY.match(stripped)) or stripped.startswith("Vacant") or bool(_VACANT_CHAIR.match(stripped))


def _title_at(lines: list[str], i: int) -> tuple[list[str], int, str]:
    """The title starting at line ``i`` (wrapped over centered lines, or past a blank line after a trailing comma or
    "and"), the index after it, and the next non-blank line's text."""
    n = len(lines)
    title = [lines[i].strip()]
    j = i + 1
    while True:
        k = j
        while k < n and not lines[k].strip():
            k += 1
        if k > j and k < n and (_CONTINUES.search(title[-1]) or _ACRONYM.match(lines[k].strip())):
            j = k  # a title wrapped past a blank line
        if not (
            j < n
            and lines[j].strip()
            and _indent(lines[j]) > 2
            and not ADDRESS.search(lines[j])
            and not ENTRY.match(lines[j].strip().rstrip("."))
        ):
            break
        title.append(lines[j].strip())
        j += 1
    following = j
    while following < n and not lines[following].strip():
        following += 1
    return title, j, lines[following].strip() if following < n else ""


def parse_directory_granule(body: bytes, granule_id: str, chamber: str) -> PrintedGranule:
    """Every roster entry one committee granule prints, and every line it could not read as one.

    Staff lists, offices and notes are skipped by layout: a roster list sits at the left margin (indent six or
    less) under a title, and a ``STAFF`` heading ends lists until the next title.
    """
    lines = text_lines(body)
    result = PrintedGranule(granule_id, chamber)
    committee: str | None = None
    sub: str | None = None
    mode = "top"  # top | members | sub | staff
    hint: str | None = None
    order = 0
    ex_officio = False
    list_column: int | None = None  # the column a list's earlier block split at, for a block continued past a page
    pending_title: list[str] = []

    def context() -> str:
        return f"{committee}/{sub}" if sub else str(committee)

    def dispose(line_no: int, kind: str, text: str) -> None:
        result.dispositions.append(PrintedDisposition(granule_id, line_no, context(), kind, text[:200]))

    def start_list(title_committee: str | None, title_sub: str | None) -> None:
        nonlocal committee, sub, order, hint, ex_officio, list_column
        if title_committee is not None:
            committee, sub, hint = title_committee, None, None
        if title_sub is not None:
            sub = title_sub
        order = 0
        ex_officio = False
        list_column = None

    def seat(line_no: int, match: re.Match[str], side: str, printed_role: str | None) -> None:
        nonlocal order
        order += 1
        office_chamber = {"Senator": "S"}.get(match["office"], "H") if match["office"] else None
        result.seats.append(
            PrintedSeat(
                granule_id, line_no, str(committee), sub, match["name"].strip(), STATES[match["state"]],
                printed_role, normalize_role(printed_role), side, order, hint or office_chamber,
            )
        )  # fmt: skip

    i, n = 0, len(lines)
    while i < n:
        line = lines[i]
        stripped = line.strip()
        if not stripped or stripped.startswith("[[Page") or line.startswith("Congressional Directory"):
            i += 1
            continue
        if stripped.startswith("["):  # a bracketed note, possibly wrapped
            while i < n and "]" not in lines[i]:
                i += 1
            i += 1
            continue
        if stripped.upper() in _NO_SUBCOMMITTEES:
            i += 1
            continue
        if _roster_margin(line) and mode != "staff" and committee is not None:
            block_start, block = i, []
            while i < n and lines[i].strip() and not lines[i].strip().startswith("[[Page"):
                block.append(lines[i])
                i += 1
            if ADDRESS.search(block[0]) and not any(ENTRY.match(" ".join(b.split()).rstrip(".,")) for b in block):
                # An office line or meeting note printed at the margin, possibly wrapped; like any address it marks a
                # pending title as a committee (CDIR-2014-02-18, Joint Committee on Printing: office indented six).
                if pending_title:
                    start_list(" ".join(pending_title), None)
                    mode = "members"
                    pending_title = []
                continue
            is_title = mode in ("sub", "members") and not any(
                ENTRY.match(b.strip().rstrip(".,")) or ", of" in b for b in block
            )
            title = [b.strip() for b in block]
            following = i
            while following < n and not lines[following].strip():
                following += 1
            while (
                is_title
                and following < n
                and not _heads_list(lines[following])
                and (_CONTINUES.search(title[-1]) or _ACRONYM.match(lines[following].strip()))
            ):
                title.append(lines[following].strip())  # a long title wrapped past a blank line
                i = following + 1
                following = i
                while following < n and not lines[following].strip():
                    following += 1
            if is_title and following < n and _heads_list(lines[following]):
                start_list(None, " ".join(title))  # a long title printed at the margin
                mode = "sub"
                continue
            i = block_start + len(block)
            column = _column(block) or list_column
            list_column = column
            left: list[tuple[int, str]] = []
            right: list[tuple[int, str]] = []
            for k, text in enumerate(block):
                line_no = block_start + k + 1
                head, tail = (text, "") if column is None else _split(text, column)
                left.append((line_no, head))
                right.append((line_no, tail))
            for side, fragments in (("majority" if column else "single", left), ("minority", right)):
                entries, leftovers = _entries(fragments)
                for line_no, text in entries:
                    if text == "Vacant.":
                        dispose(line_no, "vacancy", "Vacant")
                        continue
                    match = ENTRY.match(text)
                    assert match is not None
                    seat(line_no, match, side, match["role"] or ("Ex Officio" if ex_officio else None))
                for line_no, text in leftovers:
                    dispose(line_no, "unread_text", text)
            continue
        upper = stripped.upper()
        if mode == "staff" and _indent(line) <= 12 and not ADDRESS.search(stripped):
            # Staff detail lines are indented 2-12, but so is the occasional next committee's title (CDIR-2022-10-26:
            # "Select Committee on the Modernization of Congress" at 12): a title is followed by an office line or
            # its chair line.
            title, _, after = _title_at(lines, i)
            # Staff headers carry a room, a phone or a closing period ("Committee on Appropriations (S-128), 224-7257.");
            # titles carry none.
            if re.search(r"[().:;]|\d{3}", " ".join(title)) or not (ADDRESS.search(after) or _heads_list(after)):
                i += 1
                continue
        if upper in ("SUBCOMMITTEES", "SUBCOMMITTEE"):
            mode = "sub"
            i += 1
            continue
        if upper.startswith("STAFF") or upper == "NON-DESIGNATED STAFF":
            mode = "staff"
            i += 1
            continue
        if upper in ("HOUSE", "SENATE"):
            hint = upper[0]
            i += 1
            continue
        if stripped.lower().startswith("ex officio"):
            ex_officio = True
            i += 1
            continue
        if re.match(r"^Vacant, [A-Z][a-z]", stripped) or _VACANT_CHAIR.match(stripped):
            dispose(i + 1, "vacancy", stripped)
            i += 1
            continue
        chair = ENTRY.match(" ".join(stripped.split()).rstrip("."))
        if chair and chair["role"]:
            if committee is not None and mode != "staff":
                seat(i + 1, chair, "chair", chair["role"])
            elif committee is not None:
                dispose(i + 1, "unread_text", stripped)  # a chair line with no committee title read above it
            i += 1
            continue
        if ADDRESS.search(stripped):
            # An address line marks the preceding title as a full committee.
            if pending_title:
                start_list(" ".join(pending_title), None)
                mode = "members"
                pending_title = []
            i += 1
            continue
        title, j, after = _title_at(lines, i)
        if ".--" in " ".join(title):
            pass  # a staff line ("Assistant to the Staff Director.--..."), never a title
        elif ADDRESS.search(after):
            pending_title = title
        elif mode in ("staff", "top") and _heads_list(after):
            # A committee printed with no office line (CDIR-2022-10-26, the January 6th select committee).
            start_list(" ".join(title), None)
            mode = "members"
        elif mode in ("sub", "members") and committee is not None and _heads_list(after):
            start_list(None, " ".join(title))  # a subcommittee (or a named list) headed by its chair line
            mode = "sub"
        elif mode != "staff" and committee is not None:
            dispose(i + 1, "unread_text", "title? " + " ".join(title))
        i = j
    return result


__all__ = [
    "DIRECTORY_COLLECTION",
    "DIRECTORY_ROSTER_RULE_VERSION",
    "ROSTER_GRANULE_TITLES",
    "DirectoryEdition",
    "DirectoryMember",
    "DirectoryRosterError",
    "PrintedDisposition",
    "PrintedGranule",
    "PrintedSeat",
    "normalize_name",
    "normalize_role",
    "parse_directory_granule",
    "read_directory_mods",
    "roster_granules",
]
