"""Read annual House allowance tables, keeping their section and printed-year evidence."""

from __future__ import annotations

import json
import re
from copy import deepcopy
from dataclasses import asdict
from importlib.resources import files
from itertools import pairwise

from spicy_docs.reading.summary_tables import native_summary_pages, summary_blocks, summary_number
from spicy_docs.sources.disbursements_index import read_report_period

RULE = "house-native-allowance-summaries/2"
SOURCE_RESOURCES = ("house_allowance_summaries_corrections.json",)
_YEAR_REPAIRS = json.loads(files("spicy_docs.reading").joinpath(SOURCE_RESOURCES[0]).read_text())
_TITLE = re.compile(
    r"^(\d{4}) Members[’'] Representational Allowance(?: \(Continued\)| [–—-] Amended)?$", re.IGNORECASE
)
_FORMULA = re.compile(
    r"^Members[’'] Representational Allowance(?: [–—-] Amended| Legislative(?: Year \d{4})?)?$",
    re.IGNORECASE,
)
_AMOUNT_HEADER = re.compile(r"(?:(\d{4}) )?MRA$", re.IGNORECASE)
_FIELDS = ("name_literal", "state_literal", "district_literal", "allowance_amount")


def _apply_reviewed_year_repairs(page, source_byte_size):
    """Reconcile a reviewed header only within its complete original and observed table."""
    for rule in _YEAR_REPAIRS:
        if page["source_sha256"] != rule["source_sha256"] or page["source_page"] not in rule["source_pages"]:
            continue
        if source_byte_size != rule["source_byte_size"] or page["page"] != page["source_page"]:
            raise ValueError("House allowance year repair differs from its reviewed original")
        for row in page["records"]:
            # An isolated continuation keeps its missing-header issue. Do not
            # pretend a header was observed across an unselected page gap.
            if row["column_origin"] is None:
                continue
            if (
                row["column_origin"] != rule["column_origin"]
                or row["title"] != rule["titles"][str(page["source_page"])]
                or row["printed_title_year"] != rule["printed_title_year"]
                or row["printed_column_year"] != rule["printed_column_year"]
                or row["allowance_year"] is not None
                or "printed_title_column_year_conflict" not in row["issues"]
            ):
                raise ValueError("House allowance year repair differs from its reviewed title and header")
            row["allowance_year"] = rule["normalized_after"]
            row["issues"].remove("printed_title_column_year_conflict")
            row["repairs"] = [deepcopy(rule)]


def _literal(block):
    return " ".join(block.text.split())


def _witness(result, blocks):
    return {
        "source_sha256": result["source_sha256"],
        "source_page": result["source_page"],
        "blocks": [{"text": block.text, "box": asdict(block.box)} for block in blocks],
    }


def _section(result, blocks):
    for index, block in enumerate(blocks):
        if not _FORMULA.fullmatch(_literal(block)):
            continue
        selected = [block]
        if _literal(block).casefold().endswith(" legislative"):
            if index + 1 == len(blocks) or not re.fullmatch(r"Year \d{4}", _literal(blocks[index + 1]), re.IGNORECASE):
                continue
            selected.append(blocks[index + 1])
        if index + 1 < len(blocks) and re.search(r"\bAmended\b", blocks[index + 1].text, re.IGNORECASE):
            selected.append(blocks[index + 1])
        heading = " ".join(_literal(block) for block in selected)
        amended = bool(re.search(r"\bAmended\b", heading, re.IGNORECASE))
        # A heading can state one trailing year for the whole printed interval.
        # Expand only that syntax for the maintained date reader; preserve the
        # literal heading, and never infer a different start year across December.
        expanded = re.sub(
            r"\b([A-Za-z]+ \d{1,2})\s*[–—-]\s*([A-Za-z]+ \d{1,2}),\s*(\d{4})\b",
            r"\1, \3 – \2, \3",
            heading,
        )
        period = read_report_period(expanded, chamber="house") if amended and re.search(r"\d", heading) else None
        return {
            **_witness(result, selected),
            "heading": heading,
            "amended": amended,
            "period_start": period.period_start if period else None,
            "period_end": period.period_end if period else None,
            "period_reading_text": expanded if period else None,
            "issues": list(period.period_issues) if period else [],
        }
    return None


def _inside(inner, outer):
    return all(inner[key] >= outer[key] - 1e-9 for key in ("x0", "y0")) and all(
        inner[key] <= outer[key] + 1e-9 for key in ("x1", "y1")
    )


def _merged_amount_readings(table, blocks, ordinal):
    """Associate actual single-amount native lines inside a physically merged cell.

    The other three ruled cells supply each row's vertical interval. The amount
    column's original merged cell is never split or replaced with an invented
    border. Every native line in it must match exactly one complete row.
    """
    readings = {}
    for cell_row, boxes in enumerate(table["cell_boxes"]):
        merged = boxes[3]
        literal = table["cells"][cell_row][3]
        if merged is None or not literal or "\n" not in literal:
            continue
        parts = [part for part in literal.splitlines() if part.strip()]
        try:
            if len(parts) < 2 or any(summary_number(part, 2) is None for part in parts):
                continue
        except ValueError:
            continue
        rows = []
        for row_number, row_boxes in enumerate(table["cell_boxes"]):
            identity = row_boxes[:3]
            if any(box is None for box in identity):
                continue
            if any((box["y0"], box["y1"]) != (identity[0]["y0"], identity[0]["y1"]) for box in identity):
                continue
            band = {**merged, "y0": identity[0]["y0"], "y1": identity[0]["y1"]}
            if _inside(band, merged) and (row_number == cell_row or row_boxes[3] is None):
                rows.append((row_number, band))
        if (
            len(rows) < 2
            or [row for row, _ in rows] != list(range(cell_row, cell_row + len(rows)))
            or rows[0][1]["y0"] != merged["y0"]
            or rows[-1][1]["y1"] != merged["y1"]
            or any(left[1]["y1"] != right[1]["y0"] for left, right in pairwise(rows))
        ):
            raise ValueError("Merged allowance amount cell lacks complete identity-row geometry")
        observed = [
            (index, block)
            for index, block in enumerate(blocks)
            if block["box"] is not None and block["text"].strip() and _inside(block["box"], merged)
        ]
        observed.sort(key=lambda item: (item[1]["box"]["y0"], item[1]["box"]["x0"]))
        if len(observed) != len(rows) or " ".join(literal.split()) != " ".join(
            " ".join(block["text"].split()) for _, block in observed
        ):
            raise ValueError("Merged allowance amount cell differs from its complete native text")
        matched = {}
        for row_number, band in rows:
            candidates = [(index, block) for index, block in observed if _inside(block["box"], band)]
            if len(candidates) != 1:
                break
            index, block = candidates[0]
            try:
                summary_number(block["text"], 2)
            except ValueError:
                break
            matched[row_number] = {
                "literal": block["text"].strip(),
                "origin": {
                    "method": "native_line_in_merged_amount_cell",
                    "table": ordinal,
                    "cell_row": cell_row,
                    "column": 3,
                    "alignment_row": row_number,
                    "native_block": index,
                },
            }
        if len(matched) == len(rows):
            readings.update(matched)
        else:
            raise ValueError("Merged allowance amount cell lacks unique native row readings")
    return readings


def validate_allowance_record(page, record):
    """Check a row against its retained table and any explicit native-cell witness."""
    table = page["tables"][record["table"]]
    cells = table["cells"][record["row"]]
    if len(cells) != len(_FIELDS) or set(record["values"]) != set(_FIELDS):
        raise ValueError("Allowance row differs from its retained source cells")
    expected = dict(zip(_FIELDS, cells, strict=True))
    origins = record.get("cell_origins")
    if origins is not None:
        reading = _merged_amount_readings(table, page.get("native_blocks", []), record["table"]).get(record["row"])
        if reading is None or origins != {"allowance_amount": reading["origin"]}:
            raise ValueError("Allowance merged-cell reading differs from its native source witness")
        expected["allowance_amount"] = reading["literal"]
        if record["values"]["allowance_amount"] != summary_number(reading["literal"], 2):
            raise ValueError("Allowance amount differs from its native source witness")
    if record["raw_fields"] != expected:
        raise ValueError("Allowance row differs from its retained source cells")


def _header(table, result, ordinal):
    cells = table.cells[0]
    labels = [" ".join((cell or "").split()) for cell in cells]
    if len(labels) != 4 or [label.casefold() for label in labels[:3]] != ["name", "state", "district"]:
        return None
    amount = _AMOUNT_HEADER.fullmatch(labels[3])
    if amount is None:
        return None
    return {
        "source_sha256": result["source_sha256"],
        "source_page": result["source_page"],
        "table": ordinal,
        "row": 0,
        "raw_fields": dict(zip(_FIELDS, cells, strict=True)),
        "cell_boxes": [asdict(box) if box else None for box in table.cell_boxes[0]],
        "column_year": int(amount[1]) if amount[1] else None,
    }


def _read_allowance_page(page, result, state):
    """Read one observed page; state contains only contiguous source-page witnesses."""
    source_page = result["source_page"]
    if state.get("previous_source_page") != source_page - 1:
        state.clear()
    state["previous_source_page"] = source_page
    blocks = summary_blocks(page)
    titles = [(block, _TITLE.fullmatch(_literal(block))) for block in blocks if _TITLE.fullmatch(_literal(block))]
    section = _section(result, blocks)
    if section is not None:
        state.update(section=section, column_origin=None)
        result.update(
            section_origin=section,
            unread=[
                {
                    "reason": "formula_units_and_conditions_not_normalized",
                    "scope": "native_text_above_allowance_table" if titles else "complete_native_page",
                }
            ],
        )
        if not titles:
            result["status"] = "allowance_formula_unparsed"
            return result
    if len(titles) != 1:
        state.clear()
        result["status"] = "no_recognized_allowance_summary"
        if titles:
            result["issues"].append("allowance_title_not_unique")
        return result
    title, title_match = titles[0]
    title_year = int(title_match[1])
    title_origin = _witness(result, [title])
    section = state.get("section")
    unrecognized = []
    for ordinal, table in enumerate(page.tables):
        if table.column_count != 4 or table.bbox is None or table.bbox.y0 <= title.box.y0:
            unrecognized.append(ordinal)
            continue
        local_header = _header(table, result, ordinal)
        if local_header:
            state["column_origin"] = local_header
        origin = state.get("column_origin")
        context_issues = []
        if origin is None:
            context_issues.append("allowance_column_header_not_read")
        if section is None:
            context_issues.append("allowance_section_not_read")
        elif section["issues"]:
            context_issues.extend(section["issues"])
        column_year = origin["column_year"] if origin else None
        if column_year is not None and column_year != title_year:
            year = None
            context_issues.append("printed_title_column_year_conflict")
        else:
            year = title_year
        cell_readings = {}
        if any(cells[3] and "\n" in cells[3] for cells in table.cells):
            native_blocks = [asdict(block) for observation in page.content.observations for block in observation.blocks]
            cell_readings = _merged_amount_readings(result["tables"][ordinal], native_blocks, ordinal)
            if cell_readings:
                result["native_blocks"] = native_blocks
        start = 1 if local_header else 0
        for row_number in range(start, table.row_count):
            cells = table.cells[row_number]
            if all(cell is None or not cell.strip() for cell in cells):
                continue
            raw = dict(zip(_FIELDS, cells, strict=True))
            if row_number in cell_readings:
                raw["allowance_amount"] = cell_readings[row_number]["literal"]
            values = {field: " ".join(raw[field].split()) if raw[field] is not None else None for field in _FIELDS[:-1]}
            issues = list(context_issues)
            try:
                values["allowance_amount"] = summary_number(raw["allowance_amount"], 2)
            except ValueError:
                values["allowance_amount"] = None
                issues.append("invalid_allowance_amount")
            result["records"].append(
                {
                    "table": ordinal,
                    "row": row_number,
                    "row_kind": "annual_allowance",
                    "table_kind": "members_representational_allowance",
                    "title": _literal(title),
                    "title_origin": title_origin,
                    "printed_title_year": title_year,
                    "printed_column_year": column_year,
                    "allowance_year": year,
                    "column_origin": origin,
                    "section_origin": section,
                    "period_start": section["period_start"] if section else None,
                    "period_end": section["period_end"] if section else None,
                    "amended": section["amended"] if section else None,
                    "raw_fields": raw,
                    "values": values,
                    "issues": issues,
                }
            )
            if row_number in cell_readings:
                result["records"][-1]["cell_origins"] = {"allowance_amount": cell_readings[row_number]["origin"]}
            validate_allowance_record(result, result["records"][-1])
    if unrecognized:
        result["unrecognized_tables"] = unrecognized
    result["status"] = "allowance_summary_read" if result["records"] else "allowance_table_not_read"
    if not result["records"]:
        result["issues"].append("allowance_table_not_read")
    return result


def iter_house_allowance_summary_pages(body: bytes, *, pages=None, source_page_numbers=None):
    """Yield selected original tables; include formula pages to witness amendment scope.

    State is cleared across source-page gaps. A selected continuation retains its
    cells while naming any missing header or section evidence. Annual allowance
    years are separate from the containing report's quarter and a section's
    explicit amendment period. Narrative formula quantities remain unnormalized.
    """
    state = {}
    for page, result in native_summary_pages(body, rule=RULE, pages=pages, source_page_numbers=source_page_numbers):
        result = _read_allowance_page(page, result, state)
        _apply_reviewed_year_repairs(result, page.metadata["source_size_bytes"])
        yield result
