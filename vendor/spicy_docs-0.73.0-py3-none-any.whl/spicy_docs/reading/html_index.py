"""Bounded, source-located HTML trees for publisher file indexes.

The shared event reader owns decoding and byte coordinates. This adapter
requires explicit, balanced grouping and preserves literal mixed text;
publisher-specific identities, groups and allowed URLs stay with each source.
"""

from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass, replace
from urllib.parse import unquote, urljoin, urlsplit

from spicy_docs.reading.markup import HTML_VOID_TAGS, MarkupReadError, joined_text, read_html_events
from spicy_docs.reading.markup_structure import Elem, element_tree
from spicy_docs.transport.source_acquirer import check_byte_bound


def descendants(node: Elem, name: str | None = None) -> Iterator[Elem]:
    for part in node.parts:
        if isinstance(part, Elem):
            if name is None or part.name == name:
                yield part
            yield from descendants(part, name)


def children(node: Elem, name: str) -> list[Elem]:
    return [part for part in node.parts if isinstance(part, Elem) and part.name == name]


def literal_text(node: Elem, *, omit_lists: bool = False) -> str:
    parts: list[str] = []
    for part in node.parts:
        if isinstance(part, Elem):
            if not (omit_lists and part.name in {"ul", "ol"}):
                parts.append(literal_text(part, omit_lists=omit_lists))
        elif part.kind == "text" and part.text is not None:
            parts.append(part.text)
    return "".join(parts)


@dataclass(frozen=True, slots=True)
class HtmlIndexReader:
    """Common syntax checks, parameterized by one source's bounds and errors."""

    label: str
    error_type: type[Exception]
    max_bytes: int = 1024 * 1024
    max_events: int = 50_000
    max_field_characters: int = 16_384

    def normal(self, value: str) -> str:
        return joined_text(value, label=self.label, bound=self.max_bytes, error_type=self.error_type)

    def field(self, node: Elem, *, omit_lists: bool = False) -> str:
        value = literal_text(node, omit_lists=omit_lists)
        if not value.strip() or len(value) > self.max_field_characters:
            raise self.error_type(f"{self.label} has an empty or oversized listing field")
        return value

    def only(self, nodes: list[Elem], description: str) -> Elem:
        if len(nodes) != 1:
            raise self.error_type(f"{self.label} must state one {description}")
        return nodes[0]

    def resolve(self, anchor: Elem, index_url: str) -> str:
        href = anchor.attributes.get("href")
        if not href or any(character.isspace() or ord(character) < 32 for character in href):
            raise self.error_type(f"{self.label} has an empty or unencoded file link")
        try:
            return urljoin(index_url, href)
        except ValueError as error:
            raise self.error_type(f"{self.label} has a malformed file link") from error

    def file_suffix(self, anchor: Elem, suffix: str) -> bool:
        """Recognize file-like paths even when a query or encoded suffix needs refusal."""
        try:
            return unquote(urlsplit(anchor.attributes.get("href") or "").path).lower().endswith(suffix)
        except ValueError as error:
            raise self.error_type(f"{self.label} has a malformed link") from error

    def tree(self, body: bytes, max_bytes: int, *, scopes: frozenset[str] | None = None) -> Elem:
        """Read the page or selected explicit elements without reserializing bytes.

        Selected scopes let a source ignore broken navigation/footer markup
        outside its identity and content elements. Their paths are rooted at
        those selected elements; byte coordinates still address the full input.
        Grouping inside each selected element remains strict.
        """
        check_byte_bound(max_bytes, "max_bytes", self.max_bytes)
        try:
            read = read_html_events(body, max_bytes=max_bytes, max_events=self.max_events, max_depth=64)
        except MarkupReadError as error:
            raise self.error_type(f"{self.label}: {error}") from error
        stack: list[str | None] = []
        events = []
        for event in read.events:
            if event.kind in {"start", "empty"} and event.name == "base":
                raise self.error_type(f"{self.label} unexpectedly changes its link base")
            if scopes is not None and not stack and not (event.kind == "start" and event.name in scopes):
                continue
            if event.kind in {"start", "empty"} and len(dict(event.attributes)) != len(event.attributes):
                raise self.error_type(f"{self.label} repeats an HTML attribute")
            if event.kind == "start":
                if event.name in HTML_VOID_TAGS:
                    event = replace(event, kind="empty")
                else:
                    stack.append(event.name)
            elif event.kind == "end" and (not stack or stack.pop() != event.name):
                raise self.error_type(f"{self.label} has malformed HTML grouping")
            events.append(event)
        if stack or read.root_name != "html":
            raise self.error_type(f"{self.label} has incomplete HTML")
        return element_tree(replace(read, events=tuple(events)), body)
