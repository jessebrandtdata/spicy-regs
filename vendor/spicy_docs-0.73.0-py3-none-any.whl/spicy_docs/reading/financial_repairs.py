"""Apply reviewed financial cells only to their exact original page and row."""

from copy import deepcopy


def apply_reviewed_cells(page, source_byte_size, rules, *, chamber, page_fields=()):
    """Preserve literals and attach the full source rule to each normalized cell."""
    for rule in rules:
        if (rule["source_sha256"], rule["source_page"]) != (page["source_sha256"], page["source_page"]):
            continue
        matches = [
            row
            for row in page["records"]
            if row["line"] == rule["line"] and all(row.get(key) == value for key, value in rule["row_context"].items())
        ]
        if (
            source_byte_size != rule["source_byte_size"]
            or page["page"] != rule["source_page"]
            or any(page.get(key) != rule[key] for key in page_fields)
            or len(matches) != 1
        ):
            raise ValueError(chamber + " summary amount repair differs from its reviewed original page")
        row = matches[0]
        if (
            row["raw_fields"] != rule["raw_fields"]
            or row["values"] != rule["values_before"]
            or row["word_indices"] != rule["word_indices"]
            or row["money_word_indices"] != rule["money_word_indices"]
            or not 0 <= rule["source_word"]["index"] < len(page["words"])
            or page["words"][rule["source_word"]["index"]] != rule["source_word"]
        ):
            raise ValueError(chamber + " summary amount repair differs from its reviewed literal row")
        row["values"][rule["field"]] = rule["normalized_after"]
        row.setdefault("repairs", []).append(deepcopy(rule))
