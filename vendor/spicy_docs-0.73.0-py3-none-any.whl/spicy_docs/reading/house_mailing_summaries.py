"""Read House mailing tables with their own dates, amendments and units."""

from __future__ import annotations

import re

from spicy_docs.reading.summary_tables import native_summary_pages, summary_blocks, summary_number
from spicy_docs.sources.disbursements_index import read_report_period

RULE = "house-native-mailing-summaries/2"
_COLUMNS = {
    "representative_literal": ("U.S. REPRESENTATIVE",),
    "total_distributed": ("TOTAL NO. DISTRIBUTED", "TOTAL NO. DISTIBUTED"),
    "average_distributed_per_household": ("AVERAGE NO. DISTRIBUTED PER HOUSEHOLD ADDRESS",),
    "total_cost": ("TOTAL COST",),
    "average_cost_per_household": ("AVERAGE COST PER HOUSEHOLD ADDRESS",),
}
_SCALES = {
    "total_distributed": 0,
    "average_distributed_per_household": 4,
    "total_cost": 2,
    "average_cost_per_household": 4,
}
_TITLE = re.compile(r"Summary Tabulation of Mass (Mailings and Communications|Mailings|Communications)", re.IGNORECASE)


_number = summary_number


def iter_house_mailing_summary_pages(body: bytes, *, pages=None, source_page_numbers=None):
    """Yield selected original pages; unknown tables and numeric cells stay explicit."""
    for page, result in native_summary_pages(body, rule=RULE, pages=pages, source_page_numbers=source_page_numbers):
        empty_tables = []
        for ordinal, table in enumerate(page.tables):
            headers = {" ".join(cell.upper().split()): n for n, cell in enumerate(table.cells[0]) if cell}
            columns = {
                field: next((headers[label] for label in labels if label in headers), None)
                for field, labels in _COLUMNS.items()
            }
            if any(column is None for column in columns.values()) or len(set(columns.values())) != len(columns):
                continue
            heading = " ".join(block.text for block in summary_blocks(page, above=table.bbox.y0))
            heading = re.split(r"\bIn accordance\b", heading, maxsplit=1, flags=re.IGNORECASE)[0]
            title = _TITLE.search(heading)
            period = read_report_period(heading, chamber="house")
            # Mailing appendices use their own reporting interval, including
            # the legislative year's January 2 end. Preserve that literal
            # interval without treating the ledger's quarter rule as a defect.
            context_issues = [issue for issue in period.period_issues if issue != "non_quarter_period"]
            if title is None:
                context_issues.append("mailing_kind_unresolved")
            kind = title[1].lower().replace(" ", "_") if title else None
            before = len(result["records"])
            for row_number, cells in enumerate(table.cells[1:], 1):
                raw = {field: cells[column] for field, column in columns.items()}
                if all(value is None or not value.strip() for value in raw.values()):
                    continue
                values = {"representative_literal": raw["representative_literal"]}
                issues = list(context_issues)
                for field, scale in _SCALES.items():
                    try:
                        values[field] = _number(raw[field], scale)
                    except ValueError:
                        values[field] = None
                        issues.append("invalid_" + field)
                result["records"].append(
                    {
                        "table": ordinal,
                        "row": row_number,
                        "table_kind": kind,
                        "period_start": period.period_start,
                        "period_end": period.period_end,
                        "period_shape_notes": [
                            issue for issue in period.period_issues if issue == "non_quarter_period"
                        ],
                        "amended": bool(re.search(r"\bAmended\b", heading, re.IGNORECASE)),
                        "heading": heading,
                        "raw_fields": raw,
                        "values": values,
                        "issues": issues,
                    }
                )
            if len(result["records"]) == before:
                empty_tables.append(
                    {
                        "table": ordinal,
                        "table_kind": kind,
                        "period_start": period.period_start,
                        "period_end": period.period_end,
                        "amended": bool(re.search(r"\bAmended\b", heading, re.IGNORECASE)),
                        "heading": heading,
                        "issues": context_issues,
                        "status": "recognized_empty_mailing_table",
                    }
                )
        if empty_tables:
            result["empty_tables"] = empty_tables
        result["status"] = (
            "mailing_summary_read"
            if result["records"]
            else "recognized_empty_mailing_summary"
            if empty_tables
            else "no_recognized_mailing_summary"
        )
        yield result
