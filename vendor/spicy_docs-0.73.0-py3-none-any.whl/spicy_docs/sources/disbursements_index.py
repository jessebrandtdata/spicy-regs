"""Shared source facts for House and Senate disbursement report indexes."""

from __future__ import annotations

import re
from calendar import monthrange
from dataclasses import dataclass
from datetime import date
from typing import Literal

type Chamber = Literal["house", "senate"]
_MONTHS = (
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
)
_DATE = re.compile(r"\b(" + "|".join(_MONTHS) + r")\s+(\d{1,2}),\s*(\d{4})(?!\d)", re.IGNORECASE)


@dataclass(frozen=True, slots=True)
class ReportPeriod:
    """ISO dates literally stated by the listing, with unresolved source issues."""

    period_start: str | None
    period_end: str | None
    period_issues: tuple[str, ...]


def read_report_period(text: str, *, chamber: Chamber) -> ReportPeriod:
    """Read explicit full dates; never fill a missing day/year from a filename.

    Literal but nonstandard periods remain available with an issue. House
    quarters and the Senate's April/October semiannual boundaries are checked
    separately. The source label remains the evidence for every typed value.
    """
    if chamber not in {"house", "senate"}:
        raise ValueError("report chamber must be house or senate")
    matches = list(_DATE.finditer(text))
    if len(matches) > 2:
        return ReportPeriod(None, None, ("ambiguous_period",))
    dates: list[date | None] = []
    issues: list[str] = []
    for match in matches:
        try:
            dates.append(date(int(match[3]), _MONTHS.index(match[1].title()) + 1, int(match[2])))
        except ValueError:
            dates.append(None)
            issues.append("invalid_calendar_date")
    if len(dates) != 2:
        # One full date is the start only when the range separator follows it.
        # This avoids promoting a lone end date when the start is incomplete.
        start = dates[0] if dates and re.match(r"\s*,?\s*(?:to|through)\b", text[matches[0].end() :]) else None
        return ReportPeriod(start.isoformat() if start else None, None, tuple(issues + ["incomplete_period"]))
    start, end = dates
    if start is not None and end is not None:
        if start > end:
            issues.append("reversed_period")
        if chamber == "house":
            valid = (
                start.day == 1
                and start.month in {1, 4, 7, 10}
                and end == date(start.year, start.month + 2, monthrange(start.year, start.month + 2)[1])
            )
            if not valid:
                issues.append("non_quarter_period")
        elif not (
            (start.month, start.day, end.month, end.day, end.year - start.year) in {(4, 1, 9, 30, 0), (10, 1, 3, 31, 1)}
        ):
            issues.append("non_semiannual_period")
    return ReportPeriod(start.isoformat() if start else None, end.isoformat() if end else None, tuple(issues))


@dataclass(frozen=True, slots=True)
class DisbursementsReportLink:
    """One actual PDF anchor; duplicate URLs remain distinct source observations."""

    link_number: int
    group_number: int
    kind: Literal["full", "part"]
    url: str
    href: str
    label: str
    report_label: str
    report_context: str
    report_url: str | None
    listing_text: str
    source_path: str
    byte_start: int
    byte_end: int | None
    period_start: str | None
    period_end: str | None
    period_issues: tuple[str, ...]
    part_number: int | None = None
    package_id: str | None = None
    duplicate_of: int | None = None
