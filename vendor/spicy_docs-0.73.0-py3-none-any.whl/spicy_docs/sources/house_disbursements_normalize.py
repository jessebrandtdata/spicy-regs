"""Traceable House CSV normalization: named fields, exact decimals and explicit dates.

Corrections to publisher mistakes belong to the evidence-qualified reader rules.
This layer trims outer whitespace, maps blanks to null, formats amounts without
floating-point arithmetic, and converts supported dates under a stated century
policy. It keeps repeated observations and flags unresolved date contradictions.
"""

from __future__ import annotations

import calendar
import csv
import json
import re
from collections import Counter
from collections.abc import Iterator
from dataclasses import asdict, dataclass
from datetime import date
from decimal import Decimal
from typing import TextIO

from spicy_docs.sources.house_disbursements import (
    DETAIL_IDENTIFIER_COLUMNS,
    SUMMARY_COLUMNS,
    HouseDisbursementsCsv,
)
from spicy_docs.sources.house_disbursements_repairs import (
    HouseDisbursementsDateReview,
    HouseDisbursementsRepair,
    reviewed_house_disbursements_dates,
)

# v2 adds correction confidence and source-qualified review/proposal records.
NORMALIZATION_VERSION = "house-disbursements-normalization/2"
_FIELDS = {
    "ORGANIZATION": "organization",
    "FISCAL YEAR OR LEGISLATIVE YEAR": "fiscal_or_legislative_year",
    "ORGANIZATION CODE": "organization_code",
    "PROGRAM": "program",
    "PROGRAM CODE": "program_code",
    "SORT SUBTOTAL DESCRIPTION": "cost_category",
    "BUDGET OBJECT CLASS": "budget_object_class",
    "SORT SEQUENCE": "sort_sequence",
    "TRANSACTION DATE": "transaction_date",
    "DATA SOURCE": "data_source",
    "DOCUMENT": "document",
    "VENDOR NAME": "vendor_name",
    "VENDOR ID": "vendor_id",
    "PERFORM START DT": "service_start_date",
    "PERFORM END DT": "service_end_date",
    "DESCRIPTION": "description",
    "BUDGET OBJECT CODE": "budget_object_code",
    "AMOUNT": "amount",
    "YTD AMOUNT": "ytd_amount",
    "QTD AMOUNT": "qtd_amount",
}
_AMOUNTS = frozenset({"AMOUNT", "YTD AMOUNT", "QTD AMOUNT"})
_DATES = frozenset({"TRANSACTION DATE", "PERFORM START DT", "PERFORM END DT"})
_DECIMAL = re.compile(r"-?[0-9]+(?:\.[0-9]{1,2})?\Z")
_DATE = re.compile(r"([0-9]{1,2})-([A-Za-z]{3})-([0-9]{2}|[0-9]{4})\Z")
_MONTHS = {
    name: number
    for number, name in enumerate(
        ("JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"), 1
    )
}
_KINDS = {"DETAIL": "transaction", "SUBTOTAL": "subtotal", "GRAND TOTAL FOR ORGANIZATION": "organization_total"}


@dataclass(frozen=True, slots=True)
class FieldNormalization:
    field: str
    input_value: str
    value: str | None
    rule: str


@dataclass(frozen=True, slots=True)
class HouseDisbursementsIssue:
    code: str
    field: str
    input_value: str | None
    reason: str


@dataclass(frozen=True, slots=True)
class NormalizedHouseDisbursement:
    source_sha256: str
    record_number: int
    line_start: int
    line_end: int
    row_kind: str
    values: dict[str, str | None]
    normalizations: tuple[FieldNormalization, ...]
    issues: tuple[HouseDisbursementsIssue, ...]
    repairs: tuple[HouseDisbursementsRepair, ...]
    reviews: tuple[HouseDisbursementsDateReview, ...]


def _period(year: int, quarter: int, century: int) -> tuple[date, date]:
    if type(year) is not int or not 1900 <= year <= 9999 or type(quarter) is not int or not 1 <= quarter <= 4:
        raise ValueError("report_year must be 1900..9999 and report_quarter must be 1..4")
    if type(century) is not int or not 1900 <= century <= 9900 or century % 100:
        raise ValueError("two_digit_year_century must be a whole century from 1900 to 9900")
    month = quarter * 3
    return date(year, month - 2, 1), date(year, month, calendar.monthrange(year, month)[1])


def _normalized_field(name: str, raw: str, century: int) -> tuple[str | None, str, HouseDisbursementsIssue | None]:
    field = _FIELDS[name]
    value = raw.strip()
    if not value:
        return None, "blank-to-null", None
    if name in _AMOUNTS:
        if _DECIMAL.fullmatch(value) is None:
            return (
                None,
                "unresolved-amount",
                HouseDisbursementsIssue(
                    "invalid_amount",
                    field,
                    raw,
                    "Expected a signed decimal with at most two fractional digits; no rounding.",
                ),
            )
        return format(Decimal(value), ".2f"), "exact-decimal-two-places", None
    if name in _DATES:
        match = _DATE.fullmatch(value)
        if match is not None:
            day, month, year_text = match.groups()
            year = int(year_text) + (century if len(year_text) == 2 else 0)
            try:
                parsed = date(year, _MONTHS[month.upper()], int(day))
            except (KeyError, ValueError):
                parsed = None
            if parsed is not None and year >= 1900:
                rule = f"date-century-{century}" if len(year_text) == 2 else "date-four-digit-year"
                return parsed.isoformat(), rule, None
        return (
            None,
            "unresolved-date",
            HouseDisbursementsIssue(
                "invalid_date",
                field,
                raw,
                "Date is malformed or predates the supported modern reporting range; original value remains in evidence.",
            ),
        )
    return value, "trim-outer-whitespace", None


def normalize_house_disbursements(
    table: HouseDisbursementsCsv,
    *,
    report_year: int,
    report_quarter: int,
    two_digit_year_century: int = 2000,
) -> Iterator[NormalizedHouseDisbursement]:
    """Yield normalized rows without deduplication, aggregation or inferred identities.

    Reporting period is supplied explicitly from the chosen listing. Two-digit
    years use the caller's stated century, never Python's implicit year pivot.
    The modern samples use 2000; another selection must choose its policy.
    Dates outside the reporting period remain values with review issues, since
    service periods and late adjustments can legitimately cross its boundaries.
    """
    start, end = _period(report_year, report_quarter, two_digit_year_century)
    period_start, period_end = start.isoformat(), end.isoformat()
    source_columns = DETAIL_IDENTIFIER_COLUMNS if table.kind == "detail" else SUMMARY_COLUMNS
    fixes: dict[int, list[HouseDisbursementsRepair]] = {}
    date_reviews = reviewed_house_disbursements_dates(table.source_sha256)
    for repair in table.repairs:
        fixes.setdefault(repair.record_number, []).append(repair)
    for row in table.rows:
        values: dict[str, str | None] = {_FIELDS[name]: None for name in source_columns}
        changes = []
        issues = []
        for name, raw in zip(table.columns, row.cells[: len(table.columns)], strict=True):
            value, rule, issue = _normalized_field(name, raw, two_digit_year_century)
            field = _FIELDS[name]
            values[field] = value
            if value != raw:
                changes.append(FieldNormalization(field, raw, value, rule))
            if issue is not None:
                issues.append(issue)

        if table.kind == "detail":
            row_kind = _KINDS.get(values["sort_sequence"] or "", "unknown")
            if row_kind == "unknown":
                issues.append(
                    HouseDisbursementsIssue(
                        "unknown_row_kind", "sort_sequence", values["sort_sequence"], "Unrecognized publisher row type."
                    )
                )
            transaction = values["transaction_date"]
            if transaction is not None and not period_start <= transaction <= period_end:
                issues.append(
                    HouseDisbursementsIssue(
                        "transaction_outside_reporting_period",
                        "transaction_date",
                        transaction,
                        "Transaction date falls outside the explicitly selected report period; no date or scope was changed.",
                    )
                )
            for field in ("service_start_date", "service_end_date"):
                service_date = values[field]
                if service_date is not None and service_date > period_end:
                    issues.append(
                        HouseDisbursementsIssue(
                            "service_after_reporting_period",
                            field,
                            values[field],
                            "Service date follows the report period; this may be advance service, not a source error.",
                        )
                    )
            service_start, service_end = values["service_start_date"], values["service_end_date"]
            if service_start is not None and service_end is not None and service_start > service_end:
                issues.append(
                    HouseDisbursementsIssue(
                        "reversed_service_dates",
                        "service_start_date/service_end_date",
                        service_start + "/" + service_end,
                        "Service starts after it ends; no unverified date repair was applied.",
                    )
                )
            elif (
                service_start is not None
                and service_end is not None
                and (date.fromisoformat(service_end) - date.fromisoformat(service_start)).days > 5 * 366
            ):
                # The raw review found a ten-year parking interval entirely
                # before the report period. Future-date checks cannot flag it.
                issues.append(
                    HouseDisbursementsIssue(
                        "long_service_interval",
                        "service_start_date/service_end_date",
                        service_start + "/" + service_end,
                        "Service interval exceeds 1,830 days; a long contract can be valid, so this is a review flag only.",
                    )
                )
        else:
            description = values["description"] or ""
            row_kind = (
                "organization_total"
                if description == "OFFICE TOTALS:"
                else "subtotal"
                if description.endswith(" TOTALS:")
                else "summary"
            )
        review = date_reviews.get(row.record_number)
        if review is not None:
            issues.append(
                HouseDisbursementsIssue(
                    "reviewed_unresolved_dates",
                    "service_start_date/service_end_date",
                    (values.get("service_start_date") or "") + "/" + (values.get("service_end_date") or ""),
                    review.reason,
                )
            )
        yield NormalizedHouseDisbursement(
            table.source_sha256,
            row.record_number,
            row.line_start,
            row.line_end,
            row_kind,
            values,
            tuple(changes),
            tuple(issues),
            tuple(fixes.get(row.record_number, ())),
            (review,) if review is not None else (),
        )


def write_normalized_house_disbursements(
    table: HouseDisbursementsCsv,
    output: TextIO,
    *,
    audit: TextIO,
    report_year: int,
    report_quarter: int,
    two_digit_year_century: int = 2000,
) -> dict[str, object]:
    """Write normalized CSV and issue/correction JSONL; return the file's normalization receipt.

    Routine field changes are reproducible from original bytes, row coordinates
    and the named rules; the receipt counts them by field/rule. Audit rows retain
    every unresolved issue and evidence-qualified correction, including their before and
    after values. Open both streams with UTF-8 and CSV output with newline=''.
    The caller retains originals, the returned receipt and partial-run failures.
    """
    start, end = _period(report_year, report_quarter, two_digit_year_century)
    source_columns = DETAIL_IDENTIFIER_COLUMNS if table.kind == "detail" else SUMMARY_COLUMNS
    metadata = (
        "source_sha256",
        "source_record_number",
        "source_line_start",
        "source_line_end",
        "report_year",
        "report_quarter",
        "row_kind",
        "issue_codes",
        "correction_rules",
        "correction_confidence",
    )
    writer = csv.DictWriter(
        output, fieldnames=[*metadata, *(_FIELDS[name] for name in source_columns)], lineterminator="\n"
    )
    writer.writeheader()
    counts: Counter[str] = Counter()
    issue_counts: Counter[str] = Counter()
    row_kinds: Counter[str] = Counter()
    rows = 0
    for row in normalize_house_disbursements(
        table, report_year=report_year, report_quarter=report_quarter, two_digit_year_century=two_digit_year_century
    ):
        writer.writerow(
            {
                "source_sha256": row.source_sha256,
                "source_record_number": row.record_number,
                "source_line_start": row.line_start,
                "source_line_end": row.line_end,
                "report_year": report_year,
                "report_quarter": report_quarter,
                "row_kind": row.row_kind,
                "issue_codes": ";".join(dict.fromkeys(issue.code for issue in row.issues)),
                "correction_rules": ";".join(repair.rule for repair in row.repairs),
                "correction_confidence": ";".join(dict.fromkeys(repair.confidence for repair in row.repairs)),
                **row.values,
            }
        )
        counts.update(change.field + ":" + change.rule for change in row.normalizations)
        issue_counts.update(issue.code for issue in row.issues)
        row_kinds[row.row_kind] += 1
        rows += 1
        if row.issues or row.repairs:
            audit.write(json.dumps(asdict(row), ensure_ascii=False, separators=(",", ":")) + "\n")
    return {
        "normalization_version": NORMALIZATION_VERSION,
        "source_sha256": table.source_sha256,
        "source_byte_size": table.byte_size,
        "parsed_sha256": table.parsed_sha256,
        "source_layout": table.layout,
        "source_encoding": table.encoding,
        "kind": table.kind,
        "report_period_start": start.isoformat(),
        "report_period_end": end.isoformat(),
        "two_digit_year_century": two_digit_year_century,
        "rows": rows,
        "row_kinds": dict(row_kinds),
        "fields_absent_in_source": [_FIELDS[name] for name in source_columns if name not in table.columns],
        "normalizations": dict(counts),
        "issues": dict(issue_counts),
        "repairs": [asdict(repair) for repair in table.repairs],
        "date_reviews": [asdict(review) for review in reviewed_house_disbursements_dates(table.source_sha256).values()],
    }
