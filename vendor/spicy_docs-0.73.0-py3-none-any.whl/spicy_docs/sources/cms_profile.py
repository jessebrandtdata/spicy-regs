"""Original CMS catalog, dictionary, count and data pages in one admitted source release."""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, replace
from datetime import datetime
from functools import cache

from rulespec_artifacts import canonical_json_bytes, schema_bundle_digest

from spicy_docs.reading.paged_json import normalize_url
from spicy_docs.releases.profile import SourceNativeBlobPage, SourceNativeProfile
from spicy_docs.sources.cms import (
    CATALOG_URL,
    MAX_CATALOG_BYTES,
    MAX_PAGE_BYTES,
    MAX_PAGES,
    CmsError,
    capture_descriptor,
    read_capture,
    read_control,
    selected_page,
    validate_selection,
)
from spicy_docs.transport.captured import CapturedBodyResponse

SCOPE_ID = "cms-dataset-release-v1"
SCHEMA_NAME = "cms-drug-spending-observation"
SCHEMA_KEY = f"schemas/{SCHEMA_NAME}-1.0.json"
_SCHEMA = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": f"urn:spicy-docs:schema:{SCHEMA_NAME}:1.0",
    "type": "object",
    "additionalProperties": False,
    "required": ["raw", "selection", "source_locator"],
    "properties": {
        "raw": {"type": "object", "additionalProperties": {"type": ["string", "null"]}},
        "selection": {"type": "object"},
        "source_locator": {"type": "object"},
    },
}


def cms_scope(selection, controls, pages):
    """Pin original controls followed by one complete ordered versioned API walk."""
    return _scope(
        {
            "selection": selection,
            "captures": [
                *[
                    capture_descriptor(capture, role)
                    for capture, role in zip(controls, ("catalog", "dictionary", "stats"), strict=True)
                ],
                *[capture_descriptor(capture, "data") for capture in pages],
            ],
        }
    )


def _scope(value):
    if not isinstance(value, dict) or set(value) != {"selection", "captures"}:
        raise CmsError("CMS source scope differs")
    selection = validate_selection(value["selection"])
    captures = value["captures"]
    if not isinstance(captures, list) or not 4 <= len(captures) <= MAX_PAGES + 3:
        raise CmsError("CMS scope requires its controls and bounded data pages")
    urls = []
    for index, item in enumerate(captures):
        role = ("catalog", "dictionary", "stats")[index] if index < 3 else "data"
        if (
            not isinstance(item, dict)
            or set(item) != {"request_url", "response_sha256", "observed_at", "byte_size", "role"}
            or item["role"] != role
            or not isinstance(item["response_sha256"], str)
            or re.fullmatch(r"sha256:[0-9a-f]{64}", item["response_sha256"]) is None
            or type(item["byte_size"]) is not int
            or not 0 < item["byte_size"] <= (MAX_CATALOG_BYTES if role == "catalog" else MAX_PAGE_BYTES)
        ):
            raise CmsError("CMS retained capture inventory differs")
        if datetime.fromisoformat(item["observed_at"]).utcoffset() is None:
            raise CmsError("CMS observation timestamp needs a timezone")
        urls.append(item["request_url"])
    if urls[:3] != [CATALOG_URL, selection["dictionary_url"], selection["api_url"] + "/stats"]:
        raise CmsError("CMS control URLs differ")
    if [c["response_sha256"] for c in captures[:2]] != [selection["catalog_sha256"], selection["dictionary_sha256"]]:
        raise CmsError("CMS control pins differ")
    size, _ = selected_page(urls[3], selection)
    if len(captures) - 3 != max(1, (selection["total_rows"] + size - 1) // size):
        raise CmsError("CMS selected data pages are incomplete")
    for index, url in enumerate(urls[3:]):
        if selected_page(url, selection) != (size, index * size):
            raise CmsError("CMS pages repeat, skip or change size")
    return value


def iter_retained_pages(scope, *, blob_source):
    for index, capture in enumerate(_scope(scope)["captures"]):
        request = normalize_url(capture["request_url"])
        yield SourceNativeBlobPage(
            page_index=index,
            window_index=0,
            window_page_index=index,
            request_key=request,
            source_cursor=request if index else None,
            blob_ref=capture["response_sha256"],
            byte_size=capture["byte_size"],
            blob_source=blob_source,
            evidence_media_type="application/json",
        )


def _parse_stream(stream, *, query_scope, request_key, evidence_ref, byte_size, media_type):
    captures = query_scope["captures"]
    matches = [(i, c) for i, c in enumerate(captures) if normalize_url(c["request_url"]) == request_key]
    if len(matches) != 1:
        raise CmsError("CMS evidence request is outside its selection")
    index, capture = matches[0]
    if (evidence_ref, byte_size, media_type) != (capture["response_sha256"], capture["byte_size"], "application/json"):
        raise CmsError("CMS evidence binding differs")
    raw = stream.read(byte_size + 1)
    if len(raw) != byte_size or "sha256:" + hashlib.sha256(raw).hexdigest() != evidence_ref:
        raise CmsError("CMS retained bytes differ")
    selection = query_scope["selection"]
    records = []
    if capture["role"] == "data":
        page = read_capture(
            CapturedBodyResponse(
                capture["request_url"],
                capture["request_url"],
                200,
                "application/json",
                capture["observed_at"],
                raw,
            ),
            selection,
        )
        _, offset = selected_page(capture["request_url"], selection)
        records = [
            {
                "raw": dict(row),
                "selection": dict(selection),
                "source_locator": {
                    "request_url": capture["request_url"],
                    "response_sha256": evidence_ref,
                    "observed_at": capture["observed_at"],
                    "json_pointer": f"/{position}",
                    "ordinal": offset + position,
                },
            }
            for position, row in enumerate(page.records)
        ]
    else:
        read_control(raw, capture["role"], selection)
    return {
        "index": index,
        "results": records,
        "count": selection["total_rows"],
        "next_url": normalize_url(captures[index + 1]["request_url"]) if index + 1 < len(captures) else None,
    }


@dataclass
class _Traversal:
    pages: int = 0
    observed: int = 0
    count: int | None = None

    def add(self, response, *, page_index):
        if response["index"] != page_index or page_index != self.pages:
            raise CmsError("CMS evidence order differs")
        self.count = response["count"]
        self.observed += len(response["results"])
        self.pages += 1

    def finish(self):
        if self.count is None or self.observed != self.count or self.pages < 4:
            raise CmsError("CMS release omitted controls or declared rows")


@dataclass
class _Acquisition:
    windows: int = 0

    def add_window(self, response, *, page_window, records_included, response_bytes):
        if response["index"] != 0 or page_window != CATALOG_URL or not records_included:
            raise CmsError("CMS release requires one catalog-bound traversal")
        self.windows += 1

    def finish(self, *, query_scope):
        if self.windows != 1:
            raise CmsError("CMS release omitted or repeated its selection")


def _record_scope(record, *, query_scope, page_window):
    if record["selection"] != query_scope["selection"] or page_window != CATALOG_URL:
        raise CmsError("CMS record selection differs")


def _byte_parser(_raw):
    raise CmsError("CMS release requires captured stream metadata")


@cache
def _schema_digest():
    return schema_bundle_digest({SCHEMA_KEY: _SCHEMA})


CMS_PROFILE = SourceNativeProfile(
    name="Retained CMS drug spending release",
    source_system_id="https://data.cms.gov",
    source_system_version="dcat-us-3-api-v1",
    acquisition_policy_id="urn:spicy-docs:acquisition:cms-drug-spending",
    acquisition_policy_version="1.1",
    scope_id=SCOPE_ID,
    source_schema_key=SCHEMA_KEY,
    source_schema=_SCHEMA,
    record_stem="cms-drug-spending",
    max_traversals=1,
    source_state_scope="observed-crawl",
    traversal_acceptance="single-observed-traversal",
    acquisition_policy=lambda scope: {
        "initialQueryScope": _scope(scope),
        "strategy": "retained-versioned-api-count-walk",
        "coverageLimits": [
            "One declared release and complete count-matching API walk; not a frozen publisher snapshot.",
            "Ordinal identifies a source occurrence, not a unique drug or manufacturer.",
            "All literal fields remain; dictionary omissions, suppression and aggregate rows are not inferred away.",
        ],
    },
    validate_query_scope=_scope,
    parse_page_response=_byte_parser,
    parse_page_stream=_parse_stream,
    max_evidence_bytes=MAX_CATALOG_BYTES,
    next_page=lambda response, *, seen_urls: response["next_url"],
    traversal_check=_Traversal,
    classify_record=dict,
    wrap_record=lambda record, *, schema_digest: {
        "fieldDiagnostics": [],
        "record": dict(record),
        "schemaDigest": schema_digest,
        "schemaName": SCHEMA_NAME,
        "schemaVersion": "1.0",
        "scopeId": SCOPE_ID,
        "sourceRecordId": f"cms:{record['selection']['api_url'].split('/')[-2]}:{record['source_locator']['ordinal']}",
    },
    record_digest=lambda record: "sha256:" + hashlib.sha256(canonical_json_bytes(dict(record))).hexdigest(),
    rendition_rows=lambda record: (),
    source_schema_declaration=lambda: {
        "schemaDigest": _schema_digest(),
        "schemaName": SCHEMA_NAME,
        "schemaVersion": "1.0",
    },
    source_schema_digest=_schema_digest,
    validate_record_scope=_record_scope,
    records_included=lambda response, *, query_scope, page_window: True,
    acquisition_check=_Acquisition,
    page_window=lambda url: url,
)


def _historical_scope(scope):
    scope = _scope(scope)
    if scope["selection"]["series_title"] not in {"Medicare Part D Spending by Drug", "Medicaid Spending by Drug"}:
        raise CmsError("CMS policy 1.0 does not include Part B")
    return scope


# Policy 1.0 predates Part B. Keep the original policy content and version so
# an already admitted release is checked against its own immutable identity.
CMS_PROFILE_1_0 = replace(
    CMS_PROFILE,
    acquisition_policy_version="1.0",
    validate_query_scope=_historical_scope,
    acquisition_policy=lambda scope: CMS_PROFILE.acquisition_policy(_historical_scope(scope)),
)


def cms_profile_for_policy(version):
    """Select an explicitly declared CMS policy; never infer or relabel it."""
    if version == "1.0":
        return CMS_PROFILE_1_0
    if version == "1.1":
        return CMS_PROFILE
    raise CmsError("Unsupported CMS acquisition policy version")
