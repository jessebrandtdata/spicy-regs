"""Official House CSVs with source locations and evidence-qualified corrections.

The detail export mixes transactions, subtotals and organization totals. The
summary export keeps year-to-date and quarter-to-date amounts side by side.
Neither is a flat list of payments to sum indiscriminately. Header shape, not
the report year, selects the layout: the currently served 2022 Q4 detail CSV
already includes the identifiers announced in March 2023. See the source guide
and retained fixture provenance for the measured originals.

Acquisition selects one explicit official URL. It neither discovers quarters
nor publishes a release. Exact captures and recovery belong to the caller.
"""

from __future__ import annotations

import csv
import io
from collections.abc import Callable, Iterator
from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING, Literal
from urllib.parse import unquote, urlsplit

from spicy_docs.sources.house_disbursements_repairs import HouseDisbursementsRepair, prepare_house_disbursements_csv
from spicy_docs.transport.captured import CapturedBodyResponse
from spicy_docs.transport.source_acquirer import (
    SourceAcquirer,
    check_byte_bound,
    check_final_url,
    check_payload,
    check_request_count,
    check_timing,
    utc_now,
)

if TYPE_CHECKING:
    import httpx

type CsvKind = Literal["detail", "summary"]
type CsvEncoding = Literal["utf-8-sig", "cp1252"]

SOURCE_URL = "https://www.house.gov/the-house-explained/open-government/statement-of-disbursements"
ARCHIVE_URL = SOURCE_URL + "/archive"
DEFAULT_MAX_BYTES = 64 * 1024 * 1024
DEFAULT_MAX_ROWS = 500_000
_LABEL = "House Statement of Disbursements CSV"

DETAIL_COLUMNS = (
    "ORGANIZATION",
    "PROGRAM",
    "SORT SUBTOTAL DESCRIPTION",
    "SORT SEQUENCE",
    "TRANSACTION DATE",
    "DATA SOURCE",
    "DOCUMENT",
    "VENDOR NAME",
    "PERFORM START DT",
    "PERFORM END DT",
    "DESCRIPTION",
    "AMOUNT",
)
DETAIL_IDENTIFIER_COLUMNS = (
    "ORGANIZATION",
    "FISCAL YEAR OR LEGISLATIVE YEAR",
    "ORGANIZATION CODE",
    "PROGRAM",
    "PROGRAM CODE",
    "SORT SUBTOTAL DESCRIPTION",
    "BUDGET OBJECT CLASS",
    "SORT SEQUENCE",
    "TRANSACTION DATE",
    "DATA SOURCE",
    "DOCUMENT",
    "VENDOR NAME",
    "VENDOR ID",
    "PERFORM START DT",
    "PERFORM END DT",
    "DESCRIPTION",
    "BUDGET OBJECT CODE",
    "AMOUNT",
)
SUMMARY_COLUMNS = ("ORGANIZATION", "PROGRAM", "DESCRIPTION", "YTD AMOUNT", "QTD AMOUNT")
_LAYOUTS = {
    "detail": {
        DETAIL_COLUMNS: "detail-original",
        DETAIL_COLUMNS + ("",): "detail-original-trailing-empty",
        DETAIL_IDENTIFIER_COLUMNS: "detail-identifiers",
        DETAIL_IDENTIFIER_COLUMNS + ("",): "detail-identifiers-trailing-empty",
    },
    "summary": {SUMMARY_COLUMNS: "summary"},
}


class HouseDisbursementsSourceError(ValueError):
    """The selected response is not a supported, bounded House CSV."""


class HouseDisbursementsUnavailableError(HouseDisbursementsSourceError):
    def __init__(self, capture: CapturedBodyResponse) -> None:
        super().__init__(f"{_LABEL} answered HTTP {capture.status_code}")
        self.capture = capture


@dataclass(frozen=True, slots=True)
class HouseDisbursementsRow:
    """One CSV record, without whitespace normalization or dropping repeated records.

    ``record_number`` counts the header as record 1; physical line numbers are
    one-based and inclusive, including line breaks inside quoted cells.
    A qualified correction puts the prior cells in ``original_cells``.
    """

    record_number: int
    line_start: int
    line_end: int
    cells: tuple[str, ...]
    original_cells: tuple[str, ...] | None = None


@dataclass(frozen=True, slots=True)
class HouseDisbursementsCsv:
    """One completely parsed file; its hash and record number identify each observation.

    ``header`` retains publisher padding and an optional unnamed trailing
    column. ``columns`` names the fields, without trailing ASCII spaces.
    Data cells remain strings, with qualified corrections recorded separately.
    ``source_sha256`` always identifies the original, before any correction;
    ``parsed_sha256`` identifies the readable in-memory copy.
    """

    kind: CsvKind
    layout: str
    encoding: CsvEncoding
    source_sha256: str
    byte_size: int
    header: tuple[str, ...]
    columns: tuple[str, ...]
    rows: tuple[HouseDisbursementsRow, ...]
    parsed_sha256: str
    repairs: tuple[HouseDisbursementsRepair, ...]

    def iter_records(self) -> Iterator[dict[str, object]]:
        """Expose source-named fields and original cells beside file and row coordinates."""
        for row in self.rows:
            yield {
                "source_sha256": self.source_sha256,
                "kind": self.kind,
                "layout": self.layout,
                "record_number": row.record_number,
                "line_start": row.line_start,
                "line_end": row.line_end,
                "values": dict(zip(self.columns, row.cells[: len(self.columns)], strict=True)),
                "unnamed_fields": row.cells[len(self.columns) :],
                "original_cells": row.original_cells,
            }


def _options(kind: str, encoding: str, max_rows: int) -> None:
    if kind not in _LAYOUTS:
        raise HouseDisbursementsSourceError("kind must be detail or summary")
    if encoding not in ("utf-8-sig", "cp1252"):
        raise HouseDisbursementsSourceError("encoding must be utf-8-sig or cp1252")
    if type(max_rows) is not int or not 1 <= max_rows <= DEFAULT_MAX_ROWS:
        raise HouseDisbursementsSourceError(f"max_rows must be between 1 and {DEFAULT_MAX_ROWS}")


def parse_house_disbursements_csv(
    body: bytes,
    *,
    kind: CsvKind,
    encoding: CsvEncoding = "utf-8-sig",
    max_bytes: int = DEFAULT_MAX_BYTES,
    max_rows: int = DEFAULT_MAX_ROWS,
) -> HouseDisbursementsCsv:
    """Read a supported header and every record, or refuse without returning partial rows.

    Encoding is explicit: the retained 2016 Q1 detail file requires cp1252.
    There is no lossy decoding or automatic fallback that could hide damaged
    UTF-8. Exact-input-qualified corrections run before decoding and return
    receipts with both original and readable pins. CSV syntax/width checks
    cannot detect truncation exactly between complete records; a successful
    parse does not prove quarter-wide coverage.
    """
    _options(kind, encoding, max_rows)
    check_byte_bound(max_bytes, "max_bytes", DEFAULT_MAX_BYTES)
    payload = check_payload(body, max_bytes, label=_LABEL, error_type=HouseDisbursementsSourceError, allow_empty=False)
    try:
        readable, source_sha256, parsed_sha256, repairs = prepare_house_disbursements_csv(payload, encoding=encoding)
    except UnicodeDecodeError as error:
        raise HouseDisbursementsSourceError(f"{_LABEL} is not valid {encoding}") from error
    original_cells = {
        repair.record_number: tuple(next(csv.reader(io.StringIO(repair.original_record, newline=""), strict=True)))
        for repair in repairs
    }
    try:
        decoded = readable.decode(encoding)
    except UnicodeDecodeError as error:
        raise HouseDisbursementsSourceError(f"{_LABEL} is not valid {encoding}") from error
    if "\x00" in decoded:
        raise HouseDisbursementsSourceError(f"{_LABEL} contains a NUL character")

    reader = csv.reader(io.StringIO(decoded, newline=""), strict=True)
    rows: list[HouseDisbursementsRow] = []
    try:
        header = tuple(next(reader))
        # House pads the final amount label with spaces in both measured
        # layouts. Keep that label verbatim too; never strip data values.
        columns = tuple(label.rstrip(" ") for label in header)
        layout = _LAYOUTS[kind].get(columns)
        if layout is None:
            raise HouseDisbursementsSourceError(f"{_LABEL} has an unsupported {kind} header")
        trailing_empty = columns[-1] == ""
        if trailing_empty:
            columns = columns[:-1]
        line_end = reader.line_num
        for record_number, cells in enumerate(reader, 2):
            if len(rows) >= max_rows:
                raise HouseDisbursementsSourceError(f"{_LABEL} exceeds max_rows={max_rows}")
            if len(cells) != len(header):
                raise HouseDisbursementsSourceError(
                    f"{_LABEL} record {record_number} has {len(cells)} cells; expected {len(header)}"
                )
            # Only full-input-qualified corrections may fix shifted records
            # before this check. Other populated unnamed fields stay
            # unresolved; never discard them or guess a vendor join.
            if trailing_empty and cells[-1] != "":
                raise HouseDisbursementsSourceError(
                    f"{_LABEL} record {record_number} (physical lines {line_end + 1}-{reader.line_num}) "
                    "has a nonempty unnamed trailing field; column alignment is unresolved"
                )
            rows.append(
                HouseDisbursementsRow(
                    record_number, line_end + 1, reader.line_num, tuple(cells), original_cells.get(record_number)
                )
            )
            line_end = reader.line_num
    except (csv.Error, StopIteration) as error:
        raise HouseDisbursementsSourceError(f"{_LABEL} is malformed at physical line {reader.line_num}") from error
    if not rows:
        raise HouseDisbursementsSourceError(f"{_LABEL} holds no records; empty input does not establish no spending")
    return HouseDisbursementsCsv(
        kind,
        layout,
        encoding,
        source_sha256,
        len(payload),
        header,
        columns,
        tuple(rows),
        parsed_sha256,
        repairs,
    )


def house_disbursements_csv_url(url: str) -> str:
    """Accept an explicit House file URL; do not guess paths from a quarter."""
    if not isinstance(url, str) or any(character.isspace() for character in url):
        raise HouseDisbursementsSourceError("CSV URL must be an encoded official House URL")
    parts = urlsplit(url)
    path = unquote(parts.path)
    if (
        parts.scheme != "https"
        or parts.netloc != "www.house.gov"
        or not path.startswith("/sites/default/files/")
        or not path.lower().endswith(".csv")
        or parts.query
        or parts.fragment
        or any(part in (".", "..") for part in path.split("/"))
        or "\\" in path
        or any(ord(character) < 32 for character in path)
    ):
        raise HouseDisbursementsSourceError("CSV URL must name an official House CSV file without query or fragment")
    return url


@dataclass(frozen=True, slots=True)
class HouseDisbursementsBudget:
    """Bounds for one selected file, including all transport retry attempts."""

    max_bytes: int = DEFAULT_MAX_BYTES
    max_rows: int = DEFAULT_MAX_ROWS
    max_requests: int = 3
    timeout_seconds: float = 90.0
    min_request_interval_seconds: float = 0.5

    def __post_init__(self) -> None:
        check_byte_bound(self.max_bytes, "max_bytes", DEFAULT_MAX_BYTES)
        _options("detail", "utf-8-sig", self.max_rows)
        check_request_count(self.max_requests)
        check_timing(self.timeout_seconds, self.min_request_interval_seconds)


class HouseDisbursementsAcquirer(SourceAcquirer):
    """Capture one caller-selected CSV with the shared bounded HTTP transport."""

    def __init__(
        self,
        *,
        budget: HouseDisbursementsBudget | None = None,
        transport: httpx.BaseTransport | None = None,
        clock: Callable[[], datetime] = utc_now,
    ) -> None:
        budget = budget if budget is not None else HouseDisbursementsBudget()
        self.budget = budget
        super().__init__(
            max_requests=budget.max_requests,
            timeout_seconds=budget.timeout_seconds,
            min_request_interval_seconds=budget.min_request_interval_seconds,
            user_agent="spicy-docs-house-disbursements/1.0",
            label=_LABEL,
            error_type=HouseDisbursementsSourceError,
            context_key="house_disbursements_acquisition",
            keyless=True,
            transport=transport,
            clock=clock,
        )

    def acquire_csv(
        self, url: str, *, kind: CsvKind, encoding: CsvEncoding = "utf-8-sig"
    ) -> tuple[HouseDisbursementsCsv, CapturedBodyResponse]:
        """Return parsed records and exact capture; refusals carry captured evidence.

        Take the URL from SOURCE_URL or ARCHIVE_URL. Reporting period belongs
        to that listing, not to an organization's fiscal year or service dates.
        This call makes no request for PDFs, other quarters or other CSVs.
        """
        house_disbursements_csv_url(url)
        _options(kind, encoding, self.budget.max_rows)

        def parse(capture: CapturedBodyResponse, limit: int) -> HouseDisbursementsCsv:
            if capture.status_code != 200:
                raise HouseDisbursementsSourceError(f"{_LABEL} answered HTTP {capture.status_code}")
            check_final_url(
                capture.resolved_url,
                url,
                error_type=HouseDisbursementsSourceError,
                message="House CSV final URL differs from the selected file",
            )
            return parse_house_disbursements_csv(
                capture.body, kind=kind, encoding=encoding, max_bytes=limit, max_rows=self.budget.max_rows
            )

        return self.capture_validated(
            url,
            media_types=("text/csv",),
            parse=parse,
            max_bytes=self.budget.max_bytes,
            unavailable=HouseDisbursementsUnavailableError,
            context={"operation": "csv", "url": url, "kind": kind, "encoding": encoding},
        )
