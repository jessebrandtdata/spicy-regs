"""Publish exact Treasury JSON captures with the existing source-release stream reader."""

from __future__ import annotations

import hashlib
import re
from dataclasses import asdict, dataclass
from datetime import datetime
from functools import cache

from rulespec_artifacts import canonical_json_bytes, schema_bundle_digest

from spicy_docs.reading.paged_json import normalize_url
from spicy_docs.releases.profile import SourceNativeBlobPage, SourceNativeProfile
from spicy_docs.sources.treasury_fiscal import (
    API,
    ENDPOINTS,
    MAX_BYTES,
    MAX_PAGES,
    FiscalDataError,
    FiscalDataSelection,
    capture_descriptor,
    read_capture,
    selected_request,
)
from spicy_docs.transport.captured import CapturedBodyResponse

SCOPE_ID = "treasury-fiscal-data-v1"
SCHEMA_NAME = "treasury-fiscal-observation"
SCHEMA_KEY = f"schemas/{SCHEMA_NAME}-1.0.json"
_SCHEMA = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": f"urn:spicy-docs:schema:{SCHEMA_NAME}:1.0",
    "type": "object",
    "additionalProperties": False,
    "required": ["dataset", "selection", "raw", "field_metadata", "source_locator"],
    "properties": {
        "dataset": {"enum": list(ENDPOINTS)},
        "selection": {"type": "object"},
        "raw": {
            "type": "object",
            "required": ["record_date"],
            "additionalProperties": {"type": ["string", "null"]},
        },
        "field_metadata": {"type": "object"},
        "source_locator": {"type": "object"},
    },
    "x-spicy-record-order": [
        {
            "fieldPath": "/raw/record_date",
            "nullOrder": "forbidden",
            "tupleComparison": "utf16-code-unit",
            "valueType": "string",
        }
    ],
}


def fiscal_scope(selection: FiscalDataSelection, captures):
    """Pin one explicit endpoint/date and its ordered successful page captures."""
    return _scope({"selection": asdict(selection), "captures": [capture_descriptor(capture) for capture in captures]})


def _scope(value):
    if not isinstance(value, dict) or set(value) != {"selection", "captures"}:
        raise FiscalDataError("Treasury release scope differs")
    selected = value["selection"]
    if not isinstance(selected, dict) or set(selected) != {"dataset", "record_date", "page_size"}:
        raise FiscalDataError("Treasury release selection differs")
    selection = FiscalDataSelection(**selected)
    captures = value["captures"]
    if not isinstance(captures, list) or not 1 <= len(captures) <= MAX_PAGES:
        raise FiscalDataError("Treasury release requires bounded retained pages")
    for index, capture in enumerate(captures):
        if (
            not isinstance(capture, dict)
            or set(capture) != {"request_url", "response_sha256", "observed_at", "byte_size"}
            or selected_request(capture["request_url"]) != (selection, index + 1)
            or not isinstance(capture["response_sha256"], str)
            or re.fullmatch(r"sha256:[0-9a-f]{64}", capture["response_sha256"]) is None
            or type(capture["byte_size"]) is not int
            or not 0 < capture["byte_size"] <= MAX_BYTES
        ):
            raise FiscalDataError("Treasury capture inventory differs")
        try:
            instant = datetime.fromisoformat(capture["observed_at"])
        except (TypeError, ValueError) as error:
            raise FiscalDataError("Treasury capture timestamp is invalid") from error
        if instant.utcoffset() is None:
            raise FiscalDataError("Treasury capture timestamp needs a timezone")
    return value


def iter_retained_pages(scope, *, blob_source):
    """Hand original JSON blobs to the normal publisher; no repackaging or requests."""
    for index, capture in enumerate(_scope(scope)["captures"]):
        request = normalize_url(capture["request_url"])
        yield SourceNativeBlobPage(
            page_index=index,
            window_index=0,
            window_page_index=index,
            request_key=request,
            source_cursor=request if index else None,
            blob_ref=capture["response_sha256"],
            byte_size=capture["byte_size"],
            blob_source=blob_source,
            evidence_media_type="application/json",
        )


def _parse_stream(stream, *, query_scope, request_key, evidence_ref, byte_size, media_type):
    _, number = selected_request(request_key)
    captures = query_scope["captures"]
    if not 1 <= number <= len(captures):
        raise FiscalDataError("Treasury evidence page is outside the captured query")
    capture = captures[number - 1]
    if (request_key, evidence_ref, byte_size, media_type) != (
        normalize_url(capture["request_url"]),
        capture["response_sha256"],
        capture["byte_size"],
        "application/json",
    ):
        raise FiscalDataError("Treasury evidence binding differs")
    raw = stream.read(MAX_BYTES + 1)
    if len(raw) != byte_size or "sha256:" + hashlib.sha256(raw).hexdigest() != evidence_ref:
        raise FiscalDataError("Treasury retained bytes differ")
    return read_capture(
        CapturedBodyResponse(
            capture["request_url"], capture["request_url"], 200, "application/json", capture["observed_at"], raw
        )
    )


def _included(response, *, query_scope, page_window):
    captures = query_scope["captures"]
    index = response["page"] - 1
    expected_next = normalize_url(captures[index + 1]["request_url"]) if index + 1 < len(captures) else None
    if (
        response["capture"] != captures[index]
        or page_window != normalize_url(captures[0]["request_url"])
        or response["next_url"] != expected_next
    ):
        raise FiscalDataError("Treasury page chain differs from the selected captures")
    return True


@dataclass
class _Traversal:
    count: int | None = None
    observed: int = 0
    pages: int = 0
    last_line: int = 0

    def add(self, response, *, page_index):
        if response["page"] != page_index + 1 or page_index != self.pages:
            raise FiscalDataError("Treasury pages are not contiguous")
        if self.count is None:
            self.count = response["count"]
        if response["count"] != self.count:
            raise FiscalDataError("Treasury count changed during traversal")
        for record in response["results"]:
            # Native lines prove order, not classification-ID uniqueness.
            # The publisher separately refuses duplicate sourceRecordIds.
            # A daily debt selection has only one source-issued date identity.
            line = 1 if record["dataset"] == "debt_to_penny" else int(record["raw"]["src_line_nbr"])
            if line <= self.last_line:
                raise FiscalDataError("Treasury native ordering repeats or reverses")
            self.last_line = line
            self.observed += 1
        self.pages += 1

    def finish(self):
        if self.count is None or self.observed != self.count:
            raise FiscalDataError("Treasury observed membership differs from its count")


@dataclass
class _Acquisition:
    windows: int = 0

    def add_window(self, response, *, page_window, records_included, response_bytes):
        if response["page"] != 1 or not records_included:
            raise FiscalDataError("Treasury release needs one complete query")
        self.windows += 1

    def finish(self, *, query_scope):
        if self.windows != 1:
            raise FiscalDataError("Treasury release omitted or repeated its query")


def _record_scope(record, *, query_scope, page_window):
    if record["selection"] != query_scope["selection"]:
        raise FiscalDataError("Treasury record differs from its selected query")


def _byte_parser(_raw):
    raise FiscalDataError("Treasury release requires its captured stream metadata")


def _identity(record):
    raw = record["raw"]
    return f"{record['dataset']}:{raw['record_date']}" + (
        f":{raw['classification_id']}" if record["dataset"] != "debt_to_penny" else ""
    )


@cache
def _schema_digest():
    return schema_bundle_digest({SCHEMA_KEY: _SCHEMA})


TREASURY_FISCAL_PROFILE = SourceNativeProfile(
    name="Retained Treasury Fiscal Data query",
    source_system_id=API,
    source_system_version="debt-v2-mts-v1",
    acquisition_policy_id="urn:spicy-docs:acquisition:treasury-fiscal-data",
    acquisition_policy_version="1.0",
    scope_id=SCOPE_ID,
    source_schema_key=SCHEMA_KEY,
    source_schema=_SCHEMA,
    record_stem="treasury-fiscal",
    max_traversals=1,
    source_state_scope="observed-crawl",
    traversal_acceptance="single-observed-traversal",
    acquisition_policy=lambda scope: {
        "initialQueryScope": _scope(scope),
        "strategy": "retained-exact-count-query",
        "coverageLimits": [
            "One explicit endpoint and record date; empty means requested-empty, not source absence.",
            "Amounts, hierarchy, report dates and null markers remain literal; units and economic periods are not inferred.",
            "No full historical coverage or frozen publisher snapshot; revisions remain separate releases.",
        ],
    },
    validate_query_scope=_scope,
    parse_page_response=_byte_parser,
    parse_page_stream=_parse_stream,
    max_evidence_bytes=MAX_BYTES,
    next_page=lambda response, *, seen_urls: response["next_url"],
    traversal_check=_Traversal,
    classify_record=dict,
    wrap_record=lambda record, *, schema_digest: {
        "fieldDiagnostics": [],
        "record": dict(record),
        "schemaDigest": schema_digest,
        "schemaName": SCHEMA_NAME,
        "schemaVersion": "1.0",
        "scopeId": SCOPE_ID,
        "sourceRecordId": _identity(record),
    },
    record_digest=lambda record: "sha256:" + hashlib.sha256(canonical_json_bytes(dict(record))).hexdigest(),
    rendition_rows=lambda record: (),
    source_schema_declaration=lambda: {
        "schemaDigest": _schema_digest(),
        "schemaName": SCHEMA_NAME,
        "schemaVersion": "1.0",
    },
    source_schema_digest=_schema_digest,
    validate_record_scope=_record_scope,
    records_included=_included,
    acquisition_check=_Acquisition,
    page_window=lambda url: url,
)
