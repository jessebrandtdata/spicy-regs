#!/usr/bin/env python3
"""Fetch complete CRS details from Congress.gov v3 for selected Parquet revisions.

Append one success or failure row per attempt to JSONL; PDFs are fetched separately.

Fetcher rules:
1. Validate JSON, a CRSReport object, and the requested id. Error-string checks
   alone can accept a challenge page as success.
2. Abort on 401/403; a credential refusal must stop the run.
3. Resume skips status=ok only for the selected update date and version.
   ID-only inputs cannot establish unchanged completion and are requested again.
4. Preserve sourceParquet on every row so the input remains traceable.
5. Scrub errors before truncating or writing them. The api_key query parameter
   appears in httpx exception URLs and can otherwise leak into rows or receipts.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import httpx

from spicy_docs.transport.captured import CapturedBodyResponse
from spicy_docs.transport.credentials import (
    ACCESS_REFUSED_STATUSES,
    CredentialRefusedError,
    failure_reason,
    read_api_key,
    refusal_message,
)
from spicy_docs.transport.retry import retry_http

API = "https://api.congress.gov/v3/crsreport/{report_id}"
USER_AGENT = "spicy-docs-crs-summaries/1.0"
#: 1,000 requests/hour is the published api.data.gov budget: 3.6 s exactly.
DEFAULT_DELAY_SECONDS = 3.7
MAX_DETAIL_BYTES = 2 * 1024 * 1024


class _RetryableStatus(httpx.HTTPStatusError):
    """429 or 5xx, worth retrying, as distinct from a 404 that is an answer."""


class CrsRevisionMismatchError(ValueError):
    """The answer belongs to another metadata revision; retain it without attaching it."""


class CrsCaptureError(RuntimeError):
    """Original retention failed; continuing would leave source facts unproved."""


def report_version(report: dict[str, Any]) -> Any:
    """Item JSON uses currentVersion; list JSON uses version. Keep both literal fields."""
    if "version" in report and "currentVersion" in report and str(report["version"]) != str(report["currentVersion"]):
        raise CrsRevisionMismatchError("CRS detail states conflicting version and currentVersion")
    return report.get("currentVersion", report.get("version"))


def match_revision(report: dict[str, Any], update_date: str, version: Any) -> None:
    """Require the same source update instant and stated publication version."""
    try:
        actual = datetime.fromisoformat(report["updateDate"])
        expected = datetime.fromisoformat(update_date)
        dates_match = actual.utcoffset() is not None and expected.utcoffset() is not None and actual == expected
    except (KeyError, TypeError, ValueError):
        dates_match = False
    actual_version = report_version(report)
    if version in (None, "") or actual_version in (None, ""):
        raise CrsRevisionMismatchError("CRS detail pairing requires a stated publication version on both records")
    if not dates_match or str(actual_version) != str(version):
        raise CrsRevisionMismatchError("CRS detail does not match selected updateDate/version")


def read_report(body: bytes, report_id: str, *, update_date: str | None = None, version: Any = None) -> dict[str, Any]:
    """Read a complete retained or newly acquired original through the same native checks."""
    payload = json.loads(body)
    report = payload.get("CRSReport") if isinstance(payload, dict) else None
    if not isinstance(report, dict):
        raise TypeError(f"{report_id}: no CRSReport object in the response")
    if report.get("id") != report_id:
        raise CrsRevisionMismatchError(f"{report_id}: response carries id {report.get('id')!r}")
    if update_date is not None:
        match_revision(report, update_date, version)
    return report


def report_ids(parquet: Path) -> list[str]:
    import pyarrow.parquet as pq

    table = pq.read_table(parquet, columns=["report_id"])
    return [r for r in table.column("report_id").to_pylist() if r]


def fetch_one(
    client: httpx.Client,
    report_id: str,
    api_key: str,
    *,
    update_date: str | None = None,
    version: Any = None,
    capture: Callable[[CapturedBodyResponse], None] | None = None,
) -> dict[str, Any]:
    """Return the CRSReport object, or raise. Success is asserted positively."""

    def _attempt() -> dict[str, Any]:
        with client.stream(
            "GET", API.format(report_id=report_id), params={"api_key": api_key, "format": "json"}
        ) as response:
            if response.status_code in ACCESS_REFUSED_STATUSES:
                raise CredentialRefusedError(refusal_message("congress.gov", response.status_code, report_id))
            if response.headers.get("content-encoding", "identity").lower() != "identity":
                raise ValueError("CRS detail answered an unsupported content encoding")
            body = bytearray()
            for chunk in response.iter_bytes():
                if len(body) + len(chunk) > MAX_DETAIL_BYTES:
                    raise ValueError("CRS detail exceeds 2 MiB byte bound")
                body.extend(chunk)
            original = bytes(body)
            if capture is not None:
                # Retention precedes parsing and native identity checks. Never retain a key in a locator.
                locator = API.format(report_id=report_id) + "?format=json"
                capture(
                    CapturedBodyResponse(
                        requested_url=locator,
                        resolved_url=str(response.url.copy_remove_param("api_key")),
                        status_code=response.status_code,
                        content_type=response.headers.get("content-type"),
                        observed_at=datetime.now(UTC).isoformat(),
                        body=original,
                    )
                )
            if response.status_code == 429 or response.status_code >= 500:
                raise _RetryableStatus("retryable congress.gov response", request=response.request, response=response)
            response.raise_for_status()
            if "json" not in (response.headers.get("content-type") or ""):
                raise ValueError(f"{report_id}: not JSON ({response.headers.get('content-type')})")
            return read_report(original, report_id, update_date=update_date, version=version)

    return retry_http(_attempt, retryable=(httpx.RequestError, _RetryableStatus), api_key=api_key)


def run(
    parquet: Path,
    output: Path,
    *,
    api_key: str,
    delay_seconds: float,
    limit: int | None = None,
    transport: httpx.BaseTransport | None = None,
    capture: Callable[[CapturedBodyResponse], None] | None = None,
) -> int:
    import pyarrow.parquet as pq

    held_columns = pq.read_schema(parquet).names
    selected = pq.read_table(
        parquet, columns=[name for name in ("report_id", "update_date", "version") if name in held_columns]
    ).to_pylist()
    revision_aware = "update_date" in held_columns
    # Historical rows are not current requests. Pick the latest selected revision per id.
    latest = {}
    for row in selected:
        if row.get("report_id") and (
            row["report_id"] not in latest
            or str(row.get("update_date")) > str(latest[row["report_id"]].get("update_date"))
        ):
            latest[row["report_id"]] = row
    ids = list(latest)

    def key(row):
        return (row["reportId"], str(row.get("selectedUpdateDate")), str(row.get("selectedVersion")))

    done = {}
    if output.exists():
        for line in output.read_text().splitlines():
            if line.strip():
                row = json.loads(line)
                done[key(row) if revision_aware else row["reportId"]] = row.get("status", "")
    # A recorded failure is retried; only a recorded success is skipped.
    keys = {
        rid: (rid, str(latest[rid].get("update_date")), str(latest[rid].get("version"))) if revision_aware else rid
        for rid in ids
    }
    todo = [r for r in ids if not revision_aware or done.get(keys[r]) != "ok"]
    retrying = sum(1 for r in todo if keys[r] in done)
    already_ok = len(ids) - len(todo)
    if limit is not None:
        todo = todo[:limit]
    # Count successes before applying the run limit; an unfetched row is not done.
    print(
        f"{len(ids):,} reports; {already_ok:,} already ok; {len(todo):,} to fetch this run "
        f"({retrying:,} of them retries of recorded failures)",
        file=sys.stderr,
    )

    ok = failed = 0
    with (
        httpx.Client(
            timeout=httpx.Timeout(60.0, connect=30.0),
            follow_redirects=True,
            headers={"Accept": "application/json", "Accept-Encoding": "identity", "User-Agent": USER_AGENT},
            transport=transport,
        ) as client,
        output.open("a") as sink,
    ):
        last = 0.0
        for index, report_id in enumerate(todo, start=1):
            wait = delay_seconds - (time.monotonic() - last)
            if wait > 0:
                time.sleep(wait)
            last = time.monotonic()
            responses = []

            def retain_response(response, responses=responses):
                if capture is not None:
                    try:
                        capture(response)
                    except CredentialRefusedError:
                        raise
                    except Exception as error:
                        raise CrsCaptureError("Cannot retain CRS detail original") from error
                responses.append(
                    {
                        "sha256": response.sha256,
                        "bytes": response.byte_size,
                        "url": response.requested_url,
                        "status": response.status_code,
                    }
                )

            try:
                report = fetch_one(
                    client,
                    report_id,
                    api_key,
                    update_date=str(latest[report_id]["update_date"]) if revision_aware else None,
                    version=latest[report_id].get("version"),
                    capture=retain_response,
                )
            except (CredentialRefusedError, CrsCaptureError):
                raise
            except Exception as error:  # noqa: BLE001 - recorded, then retried on resume
                row = {
                    "reportId": report_id,
                    "status": "failed",
                    "error": failure_reason(error, api_key),
                    "sourceParquet": str(parquet),
                }
                failed += 1
            else:
                summary = report.get("summary")
                row = {
                    "reportId": report_id,
                    "status": "ok",
                    "summaryChars": len(summary) if isinstance(summary, str) else None,
                    "summary": summary,
                    "title": report.get("title"),
                    "publishDate": report.get("publishDate"),
                    "updateDate": report.get("updateDate"),
                    "status_": report.get("status"),
                    "contentType": report.get("contentType"),
                    "formats": report.get("formats"),
                    "topics": report.get("topics"),
                    "authors": report.get("authors"),
                    "relatedMaterials": report.get("relatedMaterials"),
                    "fieldStates": {
                        field: "missing"
                        if field not in report
                        else "null"
                        if report[field] is None
                        else "empty"
                        if report[field] in ("", [])
                        else "value"
                        for field in ("summary", "authors", "topics", "formats", "relatedMaterials")
                    },
                    "sourceParquet": str(parquet),
                }
                if "version" in report:
                    row["version"] = report["version"]
                if "currentVersion" in report:
                    row["currentVersion"] = report["currentVersion"]
                if capture is None:
                    row["report"] = report  # Without an archive callback, retain every literal member here.
                ok += 1
            row["sourceResponses"] = responses
            if revision_aware:
                row.update(
                    selectedUpdateDate=str(latest[report_id]["update_date"]),
                    selectedVersion=latest[report_id].get("version"),
                )
            sink.write(json.dumps(row, sort_keys=True) + "\n")
            sink.flush()
            if index % 100 == 0 or index == len(todo):
                print(f"  {index:,}/{len(todo):,}  ok={ok:,} failed={failed:,}", file=sys.stderr)
    print(f"done: ok={ok:,} failed={failed:,}", file=sys.stderr)
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report-parquet", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True, help="JSONL, appended, resumable")
    parser.add_argument("--env-file", type=Path, required=True)
    parser.add_argument("--env-var", default="API_GOV")
    parser.add_argument("--delay-seconds", type=float, default=DEFAULT_DELAY_SECONDS)
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--raw-root", type=Path, help="Central raw archive; defaults to SPICYGOV_RAW_ROOT")
    args = parser.parse_args(argv)
    from spicy_docs.storage.raw_archive import CentralRawArchiveStore

    store = CentralRawArchiveStore(args.raw_root)
    api_key = read_api_key(args.env_file, args.env_var)

    def retain(captured):
        if api_key.encode() in captured.body:
            raise CredentialRefusedError("CRS detail response contains credential-bearing bytes")
        digest = captured.sha256
        store.put_blob(digest, len(captured.body), (captured.body,))
        store.record_receipt(
            files=[{"sha256": digest, "bytes": len(captured.body), "source_url": captured.requested_url}],
            receipt={
                "family": "crs-reports",
                "stage": "crs-detail",
                "observed_at": captured.observed_at,
                "status_code": captured.status_code,
            },
        )

    return run(
        args.report_parquet,
        args.output,
        api_key=api_key,
        delay_seconds=args.delay_seconds,
        limit=args.limit,
        capture=retain,
    )


if __name__ == "__main__":
    raise SystemExit(main())
