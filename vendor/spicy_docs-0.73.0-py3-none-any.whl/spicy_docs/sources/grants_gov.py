"""Literal Grants.gov daily XML records using the maintained ZIP and XML readers."""

from __future__ import annotations

import re
from datetime import date, datetime
from zipfile import ZipFile

from spicy_docs.reading.xml import iter_xml_stream
from spicy_docs.reading.xml_observations import XmlObservationScan
from spicy_docs.reading.zip_archive import inspect_archive_stream, seekable_stream

NAMESPACE = "http://apply.grants.gov/system/OpportunityDetail-V1.0"
EXPORT_BASE = "https://prod-grants-gov-chatbot.s3.amazonaws.com/extracts/"
SCHEMA_URL = "https://apply07.grants.gov/apply/system/schemas/OpportunityDetail-V1.0.xsd"
MAX_ZIP_BYTES = 128 * 1024**2
MAX_XML_BYTES = 512 * 1024**2
MAX_RECORDS = 200_000
MAX_RECORD_TEXT = 1024**2
MAX_FIELDS = 512
_KINDS = {
    f"{{{NAMESPACE}}}OpportunitySynopsisDetail_1_0": "synopsis",
    f"{{{NAMESPACE}}}OpportunityForecastDetail_1_0": "forecast",
}


class GrantsGovError(ValueError):
    """The selected export cannot establish complete source observations."""


def _stem(snapshot_date):
    if not isinstance(snapshot_date, str) or re.fullmatch(r"\d{4}-\d{2}-\d{2}", snapshot_date) is None:
        raise GrantsGovError("Grants.gov snapshot requires YYYY-MM-DD")
    try:
        date.fromisoformat(snapshot_date)
    except ValueError as error:
        raise GrantsGovError("Grants.gov snapshot date is invalid") from error
    return "GrantsDBExtract" + snapshot_date.replace("-", "") + "v2"


def grants_scope(capture, snapshot_date, member_name=None):
    """Bind one dated original; acquisition time and publisher snapshot stay separate."""
    stem = _stem(snapshot_date)
    member_name = member_name if member_name is not None else stem + ".xml"
    if member_name != stem + ".xml":
        raise GrantsGovError("Grants.gov member differs from its dated export")
    if (
        not isinstance(capture, dict)
        or set(capture) != {"request_url", "response_sha256", "observed_at", "byte_size"}
        or capture["request_url"] != EXPORT_BASE + stem + ".zip"
        or not isinstance(capture["response_sha256"], str)
        or re.fullmatch(r"sha256:[0-9a-f]{64}", capture["response_sha256"]) is None
        or type(capture["byte_size"]) is not int
        or not 0 < capture["byte_size"] <= MAX_ZIP_BYTES
    ):
        raise GrantsGovError("Grants.gov capture identity differs")
    try:
        instant = datetime.fromisoformat(capture["observed_at"])
        if instant.utcoffset() is None:
            raise ValueError
    except (TypeError, ValueError) as error:
        raise GrantsGovError("Grants.gov capture needs an observed timestamp with timezone") from error
    return {"snapshot_date": snapshot_date, "capture": dict(capture), "member_name": member_name}


def validate_scope(value):
    if not isinstance(value, dict) or set(value) != {"snapshot_date", "capture", "member_name"}:
        raise GrantsGovError("Grants.gov scope fields differ")
    return grants_scope(**value)


def acquire_snapshot(acquirer, snapshot_date, *, store, expected_size, etag, expected_sha256=None):
    """Use the shared bounded downloader once; no archive extraction or requests on import.

    Size and ETag are the mandatory minimum pins; ``expected_sha256`` is optional
    because the retained-scope digest path verifies content identity later.
    """
    stem = _stem(snapshot_date)
    if (
        type(expected_size) is not int
        or not 0 < expected_size <= MAX_ZIP_BYTES
        or not isinstance(etag, str)
        or not etag
    ):
        raise GrantsGovError("Grants.gov acquisition requires bounded size and a selected ETag")
    return acquirer.download(
        EXPORT_BASE + stem + ".zip",
        store=store,
        max_bytes=MAX_ZIP_BYTES,
        expected_size=expected_size,
        expected_sha256=expected_sha256,
        etag=etag,
    )


class _RecordScan(XmlObservationScan):
    def __init__(self, scope, member_digest):
        super().__init__(error_type=GrantsGovError, label="Grants.gov XML", max_depth=4)
        self.scope, self.member_digest = scope, member_digest
        self.pending = []
        self.ordinal = 0
        self.fields = []
        self.text = []
        self.record_text = 0
        self.notice_type = None
        self.record_xpath = None

    def observe_start(self, tag, attributes):
        depth = len(self.stack)
        if depth == 1:
            if tag != f"{{{NAMESPACE}}}Grants":
                raise GrantsGovError("Grants.gov XML root or namespace differs")
        elif depth == 2:
            if tag not in _KINDS:
                raise GrantsGovError("Grants.gov export has an unsupported record element")
            if self.ordinal >= MAX_RECORDS:
                raise GrantsGovError("Grants.gov export exceeds max_records")
            self.notice_type = _KINDS[tag]
            self.record_xpath = self.current_element().source_xpath
            self.fields, self.record_text = [], 0
        elif depth == 3:
            if len(self.fields) >= MAX_FIELDS:
                raise GrantsGovError("Grants.gov record exceeds max_fields")
            self.text = []
        else:
            raise GrantsGovError("Grants.gov field contains unsupported nested XML")

    def observe_text(self, text):
        if len(self.stack) == 3:
            self.record_text += len(text)
            if self.record_text > MAX_RECORD_TEXT:
                raise GrantsGovError("Grants.gov record exceeds its text bound")
            self.text.append(text)
        elif text.strip():
            raise GrantsGovError("Grants.gov has text outside a field")

    def observe_end(self, tag):
        depth = len(self.stack)
        if depth == 3:
            element = self.current_element()
            self.fields.append(
                {
                    "tag": element.tag,
                    "text": "".join(self.text),
                    "attributes": element.attributes,
                    "source_xpath": element.source_xpath,
                }
            )
        elif depth == 2:
            ids = [field["text"] for field in self.fields if field["tag"] == f"{{{NAMESPACE}}}OpportunityID"]
            versions = [field["text"] for field in self.fields if field["tag"] == f"{{{NAMESPACE}}}Version"]
            if len(ids) != 1 or re.fullmatch(r"[0-9]{1,20}", ids[0]) is None or len(versions) > 1:
                raise GrantsGovError("Grants.gov record identity or version is ambiguous")
            capture = self.scope["capture"]
            self.pending.append(
                {
                    "snapshot_date": self.scope["snapshot_date"],
                    "notice_type": self.notice_type,
                    "opportunity_id": ids[0],
                    "version": versions[0] if versions else None,
                    "ordinal": self.ordinal,
                    "fields": self.fields,
                    "source_locator": {
                        **{key: capture[key] for key in ("request_url", "response_sha256", "observed_at")},
                        "member_name": self.scope["member_name"],
                        "member_sha256": self.member_digest,
                        "source_xpath": self.record_xpath,
                    },
                }
            )
            self.ordinal += 1
            self.fields = []


def snapshot_records(stream, *, scope):
    """Read all records from one verified ZIP member without a decoded file or whole XML tree."""
    scope = validate_scope(scope)
    with seekable_stream(stream, byte_size=scope["capture"]["byte_size"]) as original:
        inventory = inspect_archive_stream(
            original,
            byte_size=scope["capture"]["byte_size"],
            max_entries=8,
            max_decoded_bytes=MAX_XML_BYTES,
            max_metadata_bytes=128 * 1024,
        )
        selected = [member for member in inventory["members"] if member["name"] == scope["member_name"]]
        if len(selected) != 1 or selected[0]["isDirectory"]:
            raise GrantsGovError("Grants.gov selected XML member is missing or ambiguous")
        member = selected[0]
        with ZipFile(original) as archive, archive.open(archive.infolist()[member["ordinal"]]) as decoded:
            scan = _RecordScan(scope, member["sha256"])
            for _ in iter_xml_stream(
                decoded,
                start=scan.start,
                end=scan.end,
                data=scan.data,
                max_bytes=MAX_XML_BYTES,
                error_type=GrantsGovError,
                label="Grants.gov XML",
                max_depth=4,
            ):
                yield from scan.pending
                scan.pending.clear()
