"""Literal law USLM references through the maintained bounded XML scanner."""

from collections.abc import Callable

from spicy_docs.sources.uscode.references import UsCodeReference, UsCodeReferenceScan, scan_uscode_references


def scan_law_references(
    xml: bytes,
    *,
    on_reference: Callable[[UsCodeReference], object] | None = None,
    max_bytes: int = 16 * 1024 * 1024,
    max_observations: int = 10_000,
    max_depth: int = 256,
) -> UsCodeReferenceScan:
    """Keep law href/ref elements and ancestry without claiming Code identity.

    Reuses the literal USLM reader. Source credits are counted by that reader but
    not emitted here; law source identity requires the separate law validator.
    Callbacks remain provisional until a successful return.
    """
    return scan_uscode_references(
        xml,
        on_reference=on_reference,
        max_bytes=max_bytes,
        max_observations=max_observations,
        max_depth=max_depth,
    )
