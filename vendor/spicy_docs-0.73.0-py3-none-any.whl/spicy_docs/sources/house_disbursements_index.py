"""Exact CSV and PDF links advertised by the House's disbursement pages.

The shared markup reader and tree retain source text and link coordinates;
only the House's observed grouping rules live here. Dates are read from literal
report context, never inferred from filenames. Revised filenames and
notes survive unchanged. Identical repeated links remain observations, with
``duplicate_of`` pointing to the earlier link number; conflicting assignments
or different files of one kind in a group refuse rather than choose a winner.

A successful read describes one page capture, not all quarters ever published.
The acquirer downloads that page only. A caller separately selects file bodies.
"""

from __future__ import annotations

import hashlib
from collections.abc import Callable, Iterator
from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING, Literal

from spicy_docs.reading.html_index import HtmlIndexReader
from spicy_docs.reading.html_index import children as _children
from spicy_docs.reading.html_index import descendants as _nodes
from spicy_docs.reading.html_index import literal_text as _text
from spicy_docs.reading.markup_structure import Elem
from spicy_docs.sources.disbursements_index import DisbursementsReportLink, read_report_period
from spicy_docs.sources.disbursements_reports import DisbursementsReportSourceError, disbursements_report_locator
from spicy_docs.sources.house_disbursements import (
    ARCHIVE_URL,
    SOURCE_URL,
    CsvKind,
    HouseDisbursementsSourceError,
    HouseDisbursementsUnavailableError,
    house_disbursements_csv_url,
)
from spicy_docs.transport.captured import CapturedBodyResponse
from spicy_docs.transport.source_acquirer import (
    SourceAcquirer,
    check_byte_bound,
    check_final_url,
    check_request_count,
    check_timing,
    utc_now,
)

if TYPE_CHECKING:
    import httpx

type IndexSelection = Literal["current", "archive"]

# The retained 2026-11-06 pages are below 60 KB; these are runaway bounds,
# not claims about the publisher's maximum archive size.
MAX_INDEX_BYTES = 1024 * 1024
MAX_INDEX_EVENTS = 50_000
MAX_FIELD_CHARACTERS = 16_384
_LABEL = "House Statement of Disbursements index"
_URLS = {"current": SOURCE_URL, "archive": ARCHIVE_URL}
_HEADINGS = {"current": "Statement of Disbursements", "archive": "Archive"}
_KINDS: dict[str, CsvKind] = {
    "sod detail transactions": "detail",
    "sod summary data": "summary",
    "sod summary": "summary",
}
_HTML = HtmlIndexReader(_LABEL, HouseDisbursementsSourceError, MAX_INDEX_BYTES, MAX_INDEX_EVENTS, MAX_FIELD_CHARACTERS)
_normal, _field, _only, _tree, _resolve = _HTML.normal, _HTML.field, _HTML.only, _HTML.tree, _HTML.resolve


@dataclass(frozen=True, slots=True)
class HouseDisbursementsCsvLink:
    """One advertised link, with one-based positions and literal decoded text.

    ``report_label`` is the current heading or the archive's PDF anchor text.
    ``report_context`` also retains text outside that anchor, before its CSV
    list. Typed dates read that complete context and flag incomplete or
    non-quarter periods without repairing the label. ``listing_text``
    keeps the CSV row's size and revision note. Byte positions address this
    index capture; ``byte_end`` is absent for an unusually spelled closing tag.
    """

    link_number: int
    group_number: int
    kind: CsvKind
    url: str
    href: str
    label: str
    report_label: str
    report_context: str
    report_url: str | None
    listing_text: str
    source_path: str
    byte_start: int
    byte_end: int | None
    duplicate_of: int | None = None
    period_start: str | None = None
    period_end: str | None = None
    period_issues: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class HouseDisbursementsIndex:
    """Links from one selected page; its digest binds every source coordinate."""

    selection: IndexSelection
    index_url: str
    source_sha256: str
    byte_size: int
    links: tuple[HouseDisbursementsCsvLink, ...]
    reports: tuple[DisbursementsReportLink, ...] = ()


def _url(selection: IndexSelection) -> str:
    if not isinstance(selection, str) or selection not in _URLS:
        raise HouseDisbursementsSourceError("index selection must be current or archive")
    return _URLS[selection]


def _page_body(root: Elem, selection: IndexSelection) -> Elem:
    title = _only(list(_nodes(root, "title")), "page title")
    heading = _only(list(_nodes(root, "h1")), "page heading")
    if (
        _normal(_field(title)) != f"{_HEADINGS[selection]} | house.gov"
        or _normal(_field(heading)) != _HEADINGS[selection]
    ):
        raise HouseDisbursementsSourceError(f"{_LABEL} does not state the selected page identity")
    canonical = _only(
        [node for node in _nodes(root, "link") if node.attributes.get("rel") == "canonical"], "canonical URL"
    )
    # House's retained canonical tags use HTTP even though both captures are HTTPS.
    if canonical.attributes.get("href") not in {_url(selection), _url(selection).replace("https:", "http:", 1)}:
        raise HouseDisbursementsSourceError(f"{_LABEL} canonical URL differs from the selected page")
    article = _only(
        [
            node
            for node in _nodes(root, "article")
            if {"housegov-page", "full"}.issubset((node.attributes.get("class") or "").split())
        ],
        "main House article",
    )
    body = _only(
        [
            node
            for node in _nodes(article, "div")
            if "field--name-field-page-body" in (node.attributes.get("class") or "").split()
        ],
        "House page body",
    )
    if any(node.name in {"script", "iframe", "form"} for node in _nodes(body)):
        raise HouseDisbursementsSourceError(f"{_LABEL} contains an unexpected active page body")
    if "Chief Administrative Officer" not in _text(body) or "SOD" not in _text(body):
        raise HouseDisbursementsSourceError(f"{_LABEL} lacks its disbursements introduction")
    return body


def _kind(anchor: Elem) -> CsvKind | None:
    return _KINDS.get(_normal(_text(anchor)).casefold())


def _candidate(anchor: Elem) -> bool:
    return _kind(anchor) is not None or _HTML.file_suffix(anchor, ".csv")


def _current_report(body: Elem) -> tuple[Elem, Elem]:
    heading = _only(
        [
            node
            for node in _children(body, "h2")
            if _normal(_text(node)).startswith("Current Statement of Disbursements of the House")
            and _normal(_text(node))
            .removeprefix("Current Statement of Disbursements of the House")
            .strip()
            .startswith("(")
            and _normal(_text(node)).endswith(")")
        ],
        "current report heading",
    )
    section = _only(_children(body, "section"), "current report section")
    if heading.byte_start >= section.byte_start:
        raise HouseDisbursementsSourceError(f"{_LABEL} current report heading follows its files")
    return heading, section


def _groups(body: Elem, selection: IndexSelection) -> Iterator[tuple[int, Elem, str, str, str | None]]:
    if selection == "current":
        heading, section = _current_report(body)
        searchable = _only(
            [node for node in _nodes(section, "h2") if _normal(_text(node)) == "Searchable Format"],
            "Searchable Format heading",
        )
        parent = _only([node for node in _nodes(section) if any(p is searchable for p in node.parts)], "CSV section")
        listing = _only(_children(parent, "ul"), "current CSV list")
        if searchable.byte_start >= listing.byte_start:
            raise HouseDisbursementsSourceError(f"{_LABEL} searchable heading follows its files")
        yield 1, listing, _field(heading), _field(heading), None
        return

    for number, group, report, report_url in _archive_groups(body):
        lists = _children(group, "ul")
        if not lists:
            continue  # A PDF-only listing makes no claim about CSV availability elsewhere.
        listing = _only(lists, "CSV list per archive report")
        if report.byte_start >= listing.byte_start:
            raise HouseDisbursementsSourceError(f"{_LABEL} report label follows its files")
        yield number, listing, _field(report), _field(group, omit_lists=True), report_url


def _official_pdf_url(anchor: Elem, index_url: str) -> str:
    url = _resolve(anchor, index_url)
    try:
        locator = disbursements_report_locator(url)
    except DisbursementsReportSourceError as error:
        raise HouseDisbursementsSourceError(f"{_LABEL} report group lacks an official House PDF link") from error
    if locator.source_host != "www.house.gov":
        raise HouseDisbursementsSourceError(f"{_LABEL} report group lacks an official House PDF link")
    return url


def _archive_groups(body: Elem) -> Iterator[tuple[int, Elem, Elem, str]]:
    reports = _only(_children(body, "ul"), "archive report list")
    for number, group in enumerate(_children(reports, "li"), 1):
        # The archive's report anchor precedes its nested CSV list. Some older
        # report labels omit the SOD prefix, so identity comes from page and
        # list structure, not a guessed year or filename.
        direct = [part for part in group.parts if isinstance(part, Elem) and part.name not in {"ul", "ol"}]
        anchors = [node for part in direct for node in ([part] if part.name == "a" else list(_nodes(part, "a")))]
        report = _only(anchors, "archive report link per group")
        yield number, group, report, _official_pdf_url(report, ARCHIVE_URL)


def _reports(body: Elem, selection: IndexSelection) -> tuple[DisbursementsReportLink, ...]:
    groups = []
    if selection == "current":
        heading, section = _current_report(body)
        for anchor in _nodes(section, "a"):
            if _HTML.file_suffix(anchor, ".pdf"):
                label = _normal(_text(anchor))
                if label == "View all three volumes in a single file":
                    kind, part = "full", None
                elif label in {"Part 1 of 3", "Part 2 of 3", "Part 3 of 3"}:
                    kind, part = "part", int(label.split()[1])
                else:
                    raise HouseDisbursementsSourceError(f"{_LABEL} has an unsupported PDF link label")
                row = _only([node for node in _nodes(section) if any(p is anchor for p in node.parts)], "PDF row")
                groups.append((1, anchor, _field(heading), _field(heading), _field(row), kind, part))
        if {(item[-2], item[-1]) for item in groups} != {("full", None), ("part", 1), ("part", 2), ("part", 3)}:
            raise HouseDisbursementsSourceError(f"{_LABEL} lacks a full report or advertised part")
    else:
        groups = [
            (
                number,
                anchor,
                _field(anchor),
                _field(group, omit_lists=True),
                _field(group, omit_lists=True),
                "full",
                None,
            )
            for number, group, anchor, _ in _archive_groups(body)
        ]
    links: list[DisbursementsReportLink] = []
    seen: dict[str, DisbursementsReportLink] = {}
    for number, anchor, label, context, text, kind, part in groups:
        url = _official_pdf_url(anchor, _url(selection))
        prior = seen.get(url)
        if prior is not None and prior.report_context != context:
            raise HouseDisbursementsSourceError(f"{_LABEL} assigns one PDF to conflicting report contexts")
        period = read_report_period(context, chamber="house")
        link = DisbursementsReportLink(
            len(links) + 1,
            number,
            kind,
            url,
            anchor.attributes.get("href") or "",
            _field(anchor),
            label,
            context,
            url,
            text,
            anchor.path,
            anchor.byte_start,
            anchor.byte_end,
            period.period_start,
            period.period_end,
            period.period_issues,
            part_number=part,
            duplicate_of=prior.link_number if prior else None,
        )
        links.append(link)
        seen.setdefault(url, link)
    candidates = {node.path for node in _nodes(body, "a") if _HTML.file_suffix(node, ".pdf")}
    if not links or {link.source_path for link in links} != candidates:
        raise HouseDisbursementsSourceError(f"{_LABEL} has empty or ungrouped PDF links")
    return tuple(links)


def parse_house_disbursements_index(
    body: bytes, *, selection: IndexSelection, max_bytes: int = MAX_INDEX_BYTES
) -> HouseDisbursementsIndex:
    """Read one explicit current/archive page without network access or URL guesses.

    Every CSV-like link in the House page body must belong to one recognized
    detail/summary group. Navigation and PDF links never become CSV records.
    Empty, partial, ambiguous and changed-layout pages refuse as a whole.
    """
    index_url = _url(selection)
    page_body = _page_body(_tree(body, max_bytes), selection)
    links: list[HouseDisbursementsCsvLink] = []
    consumed: set[str] = set()
    seen: dict[str, HouseDisbursementsCsvLink] = {}
    for group_number, listing, report_label, report_context, report_url in _groups(page_body, selection):
        period = read_report_period(report_context, chamber="house")
        kinds: dict[CsvKind, set[str]] = {"detail": set(), "summary": set()}
        for row in _children(listing, "li"):
            anchor = _only(list(_nodes(row, "a")), "CSV anchor per list item")
            kind = _kind(anchor)
            if kind is None:
                raise HouseDisbursementsSourceError(f"{_LABEL} has an unsupported CSV link label")
            url = house_disbursements_csv_url(_resolve(anchor, index_url))
            kinds[kind].add(url)
            prior = seen.get(url)
            if prior is not None and (prior.kind, prior.report_label, prior.report_context) != (
                kind,
                report_label,
                report_context,
            ):
                raise HouseDisbursementsSourceError(f"{_LABEL} assigns one CSV to conflicting kinds or report contexts")
            link = HouseDisbursementsCsvLink(
                len(links) + 1,
                group_number,
                kind,
                url,
                anchor.attributes.get("href") or "",
                _field(anchor),
                report_label,
                report_context,
                report_url,
                _field(row),
                anchor.path,
                anchor.byte_start,
                anchor.byte_end,
                prior.link_number if prior is not None else None,
                period.period_start,
                period.period_end,
                period.period_issues,
            )
            links.append(link)
            seen.setdefault(url, link)
            consumed.add(anchor.path)
        if any(len(urls) != 1 for urls in kinds.values()):
            raise HouseDisbursementsSourceError(
                f"{_LABEL} report group must state one detail file and one summary file"
            )
    candidates = {anchor.path for anchor in _nodes(page_body, "a") if _candidate(anchor)}
    if not links or candidates != consumed:
        raise HouseDisbursementsSourceError(f"{_LABEL} has empty or ungrouped CSV links")
    return HouseDisbursementsIndex(
        selection,
        index_url,
        "sha256:" + hashlib.sha256(body).hexdigest(),
        len(body),
        tuple(links),
        _reports(page_body, selection),
    )


@dataclass(frozen=True, slots=True)
class HouseDisbursementsIndexBudget:
    """Bounds for one selected listing, including transport retries."""

    max_bytes: int = MAX_INDEX_BYTES
    max_requests: int = 3
    timeout_seconds: float = 30.0
    min_request_interval_seconds: float = 0.5

    def __post_init__(self) -> None:
        check_byte_bound(self.max_bytes, "max_bytes", MAX_INDEX_BYTES)
        check_request_count(self.max_requests)
        check_timing(self.timeout_seconds, self.min_request_interval_seconds)


_DEFAULT_BUDGET = HouseDisbursementsIndexBudget()


class HouseDisbursementsIndexAcquirer(SourceAcquirer):
    """Capture one selected House listing through the shared bounded HTTP client."""

    def __init__(
        self,
        *,
        budget: HouseDisbursementsIndexBudget = _DEFAULT_BUDGET,
        transport: httpx.BaseTransport | None = None,
        clock: Callable[[], datetime] = utc_now,
    ) -> None:
        self.budget = budget
        super().__init__(
            max_requests=budget.max_requests,
            timeout_seconds=budget.timeout_seconds,
            min_request_interval_seconds=budget.min_request_interval_seconds,
            user_agent="spicy-docs-house-disbursements/1.0",
            label=_LABEL,
            error_type=HouseDisbursementsSourceError,
            context_key="house_disbursements_acquisition",
            keyless=True,
            transport=transport,
            clock=clock,
        )

    def acquire_index(self, *, selection: IndexSelection) -> tuple[HouseDisbursementsIndex, CapturedBodyResponse]:
        """Return parsed listing and exact capture; do not follow any advertised file."""
        url = _url(selection)

        def parse(capture: CapturedBodyResponse, limit: int) -> HouseDisbursementsIndex:
            if capture.status_code != 200:
                raise HouseDisbursementsSourceError(f"{_LABEL} answered HTTP {capture.status_code}")
            check_final_url(
                capture.resolved_url,
                url,
                error_type=HouseDisbursementsSourceError,
                message="House disbursements index final URL differs from the selected page",
            )
            return parse_house_disbursements_index(capture.body, selection=selection, max_bytes=limit)

        return self.capture_validated(
            url,
            media_types=("text/html",),
            parse=parse,
            max_bytes=self.budget.max_bytes,
            unavailable=HouseDisbursementsUnavailableError,
            context={"operation": "index", "selection": selection, "url": url},
        )
