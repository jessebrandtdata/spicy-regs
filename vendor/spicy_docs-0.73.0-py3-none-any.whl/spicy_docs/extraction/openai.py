"""OpenAI Responses image recognition with literal text or validated page outcomes."""

from __future__ import annotations

import base64
import copy
import re

from spicy_docs.transport.credentials import CredentialRefusedError

from ._structured import _outcome_validator, _strict_json
from .model import ExtractionError, Recognition
from .prompts import TRANSCRIBE
from .remote import RemoteClient


def _identifier(value, pattern, label):
    if not isinstance(value, str) or not re.fullmatch(pattern, value):
        raise ValueError(f"invalid OpenAI {label}")
    return value


class OpenAIClient(RemoteClient):
    """Responses and Batch endpoints; no implicit retries or service-tier fallback."""

    provider = "OpenAI"
    base_url = "https://api.openai.com/v1/"

    def _headers(self):
        return {"Authorization": "Bearer " + self._key}

    def generate(self, model, body):
        if body.get("model") != model:
            raise ValueError("OpenAI request model differs from selected model")
        return self._request("POST", "responses", body)

    def upload_batch(self, data):
        return self._request(
            "POST",
            "files",
            data={"purpose": "batch"},
            files={"file": ("ocr-requests.jsonl", data, "application/jsonl")},
        )

    def submit_batch(self, file_id, metadata):
        _identifier(file_id, r"file-[A-Za-z0-9_-]+", "file id")
        return self._request(
            "POST",
            "batches",
            {"input_file_id": file_id, "endpoint": "/v1/responses", "completion_window": "24h", "metadata": metadata},
        )

    def get_batch(self, name):
        return self._request("GET", "batches/" + _identifier(name, r"batch_[A-Za-z0-9_-]+", "batch id"))

    def cancel_batch(self, name):
        return self._request(
            "POST", "batches/" + _identifier(name, r"batch_[A-Za-z0-9_-]+", "batch id") + "/cancel", {}
        )

    def file_content(self, name):
        return self._request(
            "GET", "files/" + _identifier(name, r"file-[A-Za-z0-9_-]+", "file id") + "/content", raw=True
        )


def _answer(raw):
    if (
        not isinstance(raw, dict)
        or raw.get("status") != "completed"
        or raw.get("error")
        or raw.get("incomplete_details")
    ):
        raise ExtractionError("OpenAI response was refused or incomplete", details=raw)
    output = raw.get("output")
    if not isinstance(output, list) or not all(isinstance(item, dict) for item in output):
        raise ExtractionError("OpenAI returned invalid output", details=raw)
    messages = [item for item in output if item.get("type") == "message"]
    if len(messages) != 1 or any(item.get("type") not in {"message", "reasoning"} for item in output):
        raise ExtractionError("OpenAI response has ambiguous or unexpected output", details=raw)
    message = messages[0]
    content = message.get("content")
    if (
        message.get("status") != "completed"
        or message.get("role") != "assistant"
        or not isinstance(content, list)
        or not content
        or any(
            not isinstance(item, dict) or item.get("type") != "output_text" or not isinstance(item.get("text"), str)
            for item in content
        )
    ):
        raise ExtractionError("OpenAI returned no complete transcription or a refusal", details=raw)
    return "".join(item["text"] for item in content)


class OpenAI:
    """An independent page request through Responses, including strict JSON Schema."""

    def __init__(
        self,
        client,
        *,
        model,
        mode="single",
        prompt=None,
        outcome_schema=None,
        generation=None,
        service_tier=None,
        detail="high",
    ):
        _identifier(model, r"[A-Za-z0-9._:-]+", "model")
        if mode not in {"single", "structured"} or service_tier not in {None, "default", "flex"}:
            raise ValueError("OpenAI requires single/structured mode and default/flex service_tier")
        if detail not in {"auto", "low", "high", "original"}:
            raise ValueError("invalid image detail")
        self.client, self.model, self.mode = client, model, mode
        self.service_tier, self.detail = service_tier, detail
        self.prompt = TRANSCRIBE if prompt is None else prompt
        if not isinstance(self.prompt, str) or not self.prompt.strip():
            raise ValueError("prompt must be nonempty text")
        if mode == "structured":
            if prompt is None or outcome_schema is None:
                raise ValueError("structured mode requires an explicit prompt and outcome_schema")
            self.outcome_schema, self._validator = _outcome_validator(outcome_schema)
        else:
            if outcome_schema is not None:
                raise ValueError("outcome_schema requires structured mode")
            self.outcome_schema, self._validator = None, None
        self.generation = {"max_output_tokens": 8192, **copy.deepcopy(generation or {})}
        if set(self.generation) - {"max_output_tokens", "reasoning", "temperature", "top_p"}:
            raise ValueError("unsupported OpenAI generation setting; prompt/schema/tier have explicit parameters")
        if (
            type(self.generation["max_output_tokens"]) is not int
            or not 1 <= self.generation["max_output_tokens"] <= 32768
        ):
            raise ValueError("require 1..32768 max_output_tokens")

    def prepare_request(self, image):
        body = {
            "model": self.model,
            "store": False,
            **copy.deepcopy(self.generation),
            "input": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "input_image",
                            "image_url": f"data:{image.media_type};base64," + base64.b64encode(image.data).decode(),
                            "detail": self.detail,
                        },
                        {"type": "input_text", "text": self.prompt},
                    ],
                }
            ],
        }
        if self.service_tier is not None:
            body["service_tier"] = self.service_tier
        if self.outcome_schema is not None:
            body["text"] = {
                "format": {
                    "type": "json_schema",
                    "name": "page_outcome",
                    "strict": True,
                    "schema": copy.deepcopy(self.outcome_schema),
                }
            }
        return body

    def recognize(self, image):
        from jsonschema import ValidationError
        from referencing.exceptions import Unresolvable

        settings = {
            "backend": "openai",
            "model": self.model,
            "mode": self.mode,
            "prompt": self.prompt,
            "generation": copy.deepcopy(self.generation),
            "service_tier": self.service_tier,
            "detail": self.detail,
        }
        if self.outcome_schema is not None:
            settings["outcome_schema"] = copy.deepcopy(self.outcome_schema)
        record = {
            "stage": "structured-page" if self.mode == "structured" else "full",
            "request": self.prepare_request(image),
        }
        calls = [record]
        try:
            raw = self.client.generate(self.model, copy.deepcopy(record["request"]))
            record["response"] = copy.deepcopy(raw)
            if getattr(self.client, "last_metadata", None):
                record["transport"] = copy.deepcopy(self.client.last_metadata)
            text = _answer(raw)
            evidence = {"calls": calls}
            if self._validator is not None:
                try:
                    outcome = _strict_json(text)
                    self._validator.validate(outcome)
                except (ValueError, ValidationError, Unresolvable, RecursionError):
                    raise ExtractionError("OpenAI page outcome does not match outcome_schema") from None
                evidence["outcome"] = outcome
            return Recognition(text, settings, evidence, images=(image,))
        except ExtractionError as exc:
            raise ExtractionError(
                str(exc), details={"configuration": settings, "calls": calls, "failure": exc.details}
            ) from None
        except CredentialRefusedError as exc:
            exc.details = {"configuration": settings, "calls": calls, "failure": getattr(exc, "details", None)}
            raise
