"""Bounded HTTP for remote recognition, sharing credential refusal and scrubbing."""

import json
import re

from spicy_docs.transport.credentials import CredentialRefusedError, scrub_credential, scrub_record

from ._structured import _strict_json
from .model import ExtractionError


def _safe_text(text, key):
    # Decode JSON string tokens before scrubbing as keys may be Unicode-escaped.
    # This also covers JSONL and malformed/duplicate-key objects retained as errors.
    def string_token(match):
        try:
            value = json.loads(match[0])
        except ValueError:
            return match[0]
        cleaned = scrub_record(value, key)
        return json.dumps(cleaned, ensure_ascii=False) if cleaned != value else match[0]

    text = re.sub(r'"(?:[^"\\]|\\.)*"', string_token, text)
    return scrub_credential(text, key)


class RemoteClient:
    """One attempt per call; callers retain and reconcile uncertain paid requests."""

    provider = "Remote"
    base_url = ""

    def __init__(self, *, api_key, http_client=None, timeout=120, max_response_bytes=16 * 1024**2):
        if len(api_key) < 8 or timeout <= 0 or max_response_bytes < 1:
            raise ValueError("supply a nonempty API key and positive request bounds")
        self._key, self._client = api_key, http_client
        self._owns_client = http_client is None
        self.timeout, self.max_response_bytes = timeout, max_response_bytes
        self.last_metadata = None

    def _headers(self):
        raise NotImplementedError

    def _refused(self, status, details):
        error = CredentialRefusedError(f"{self.provider} refused credentials ({status})")
        error.details = details
        raise error from None

    def _request(self, method, path, body=None, *, raw=False, **kwargs):
        import httpx

        if self._client is None:
            self._client = httpx.Client(follow_redirects=False)
        if body is not None:
            kwargs["json"] = body
        self.last_metadata = None
        refused_status = None
        try:
            with self._client.stream(
                method,
                self.base_url + path,
                headers=self._headers(),
                timeout=self.timeout,
                follow_redirects=False,
                **kwargs,
            ) as response:
                refused_status = response.status_code if response.status_code in {401, 403} else None
                self.last_metadata = {
                    "status_code": response.status_code,
                    "headers": {
                        key: scrub_credential(response.headers[key], self._key)
                        for key in ("x-request-id", "x-gemini-service-tier", "retry-after")
                        if key in response.headers
                    },
                }
                chunks, size = [], 0
                for chunk in response.iter_bytes(chunk_size=min(65536, self.max_response_bytes + 1)):
                    size += len(chunk)
                    if size > self.max_response_bytes:
                        if refused_status is not None:
                            self._refused(refused_status, "Credential refusal body exceeds max_response_bytes")
                        raise ExtractionError(f"{self.provider} response exceeds max_response_bytes")
                    chunks.append(chunk)
                text = _safe_text(b"".join(chunks).decode("utf-8", errors="replace"), self._key)
                if refused_status is not None:
                    self._refused(refused_status, text)
                if not 200 <= response.status_code < 300:
                    raise ExtractionError(f"{self.provider} HTTP {response.status_code}", details=text)
                if raw:
                    return text.encode()
                try:
                    parsed = _strict_json(text)
                except ValueError:
                    raise ExtractionError(f"{self.provider} returned invalid JSON", details=text) from None
                if not isinstance(parsed, dict):
                    raise ExtractionError(f"{self.provider} response must be an object", details=parsed)
                return scrub_record(parsed, self._key)
        except httpx.HTTPError as exc:
            if refused_status is not None:
                self._refused(refused_status, scrub_credential(str(exc), self._key)[:500])
            raise ExtractionError(scrub_credential(str(exc), self._key)[:500]) from None

    def close(self):
        if self._owns_client and self._client is not None:
            self._client.close()
            self._client = None

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
