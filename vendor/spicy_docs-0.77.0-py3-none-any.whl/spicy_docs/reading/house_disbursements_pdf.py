"""Read the typeset House disbursement ledger while retaining every native word.

The publisher uses indentation for account hierarchy and two separate money
columns for year-to-date and quarterly figures. Payments, category totals and
office summaries are distinct observations. Scanned pages require separately
qualified OCR; an embedded OCR layer is never accepted as native financial text.
"""

from __future__ import annotations

import hashlib
import json
import re
from copy import deepcopy
from datetime import date
from importlib.metadata import version
from importlib.resources import files

from spicy_docs.reading.disbursement_date_repairs import apply_date_repairs
from spicy_docs.reading.pdf_grid import display_words, literal, visual_lines
from spicy_docs.schemas.senate_expenditure_tables import parse_amount

RULE = "house-disbursement-pdf-pages/1"
MAX_BYTES = 128 * 1024 * 1024
_DATE = re.compile(r"([0-9]{2})/([0-9]{2})/([0-9]{2}|[0-9]{4})\Z")
_POSTED = re.compile(r"([0-9]{2})[-–]([0-9]{2})\Z")
_OFFICE = re.compile(r"(?:(FISCAL YEAR) )?([0-9]{4}) (.+)\Z")
_LEADER = re.compile(r"\s*\.{3,}\s*\Z")
_CONTEXT = ("organizational_group", "organization", "fiscal_or_legislative_year", "program", "cost_category")
# Some printed section headings shift slightly inside their ten-point level.
# Two points includes that typesetting variation without overlapping levels.
_HEADING_TOLERANCE = 2
_DATE_REPAIRS = json.loads(files("spicy_docs.reading").joinpath("house_disbursements_pdf_corrections.json").read_text())


def _clean(value):
    return _LEADER.sub("", value).strip()


def expand_house_ditto_payee(prior):
    """Expand printed DO from a supplied predecessor while retaining its witness.

    The caller establishes the predecessor: native readers track source order;
    structured readers require a separate original-source review.
    """
    if prior is None:
        return None, []
    if (
        not isinstance(prior.get("value"), str)
        or not prior["value"].strip()
        or prior["value"].strip() == "DO"
        or not isinstance(prior.get("origin"), dict)
        or not prior["origin"]
    ):
        raise ValueError("House ditto payee requires a literal predecessor and its source witness")
    value = prior["value"]
    return value, [
        {
            "rule": "printed-ditto-payee",
            "raw_before": "DO",
            "normalized_after": value,
            "witness": deepcopy(prior["origin"]),
        }
    ]


def _date(value, century):
    found = _DATE.fullmatch(value)
    if found is None:
        return None
    month, day, year = found.groups()
    try:
        return date(int(year) + (century if len(year) == 2 else 0), int(month), int(day)).isoformat()
    except ValueError:
        return None


def normalize_house_fields(raw, *, row_kind, period, century=2000):
    """Normalize literal House scalar fields without assigning context or ditto names.

    Native rows and reviewed unpositioned observations share this interpretation.
    Missing observation fields may be null; their raw state stays with the caller.
    Posting dates use the evidenced report year, never a fiscal-account heading.
    """
    if period[1] < period[0] or type(century) is not int or century % 100 or not 1900 <= century <= 9900:
        raise ValueError("House fields require a valid report period and whole century")
    values = {
        field: _clean(raw.get(field) or "") or None
        for field in ("data_source", "document", "vendor_name", "description")
    }
    values.update(transaction_date=None, service_start_date=None, service_end_date=None)
    issues = []
    if row_kind != "transaction":
        return values, issues
    for field in ("service_start_date", "service_end_date"):
        if raw.get(field):
            values[field] = _date(raw[field], century)
            if values[field] is None:
                issues.append("invalid_" + field)
    if raw.get("transaction_date"):
        posted = _POSTED.fullmatch(raw["transaction_date"])
        try:
            if posted is None:
                raise ValueError("Unrecognized posting date")
            values["transaction_date"] = date(period[0].year, int(posted[1]), int(posted[2])).isoformat()
        except ValueError:
            issues.append("invalid_transaction_date")
        if (
            values["transaction_date"]
            and not period[0].isoformat() <= values["transaction_date"] <= period[1].isoformat()
        ):
            issues.append("transaction_date_outside_report_period")
    if (
        values["service_start_date"]
        and values["service_end_date"]
        and values["service_start_date"] > values["service_end_date"]
    ):
        issues.append("reversed_service_dates")
    if values["service_end_date"] and values["service_end_date"] > period[1].isoformat():
        issues.append("service_after_report_period")
    return values, issues


def _header(words):
    candidates = []
    for anchor in (word for word in words if word["text"] == "VOUCHER"):
        band = [word for word in words if abs(word["y"] - anchor["y"]) <= 2]
        labels = {}
        for label in ("DATE", "VOUCHER", "PAYEE", "SERVICE", "DESCRIPTION", "YTD", "QUARTERLY"):
            found = [word for word in band if word["text"] == label]
            if len(found) != 1:
                break
            labels[label] = found[0]
        if len(labels) != 7:
            continue
        amounts = sorted((word for word in band if word["text"] == "AMOUNT"), key=lambda word: word["x"])
        if len(amounts) != 2 or not labels["YTD"]["x"] < amounts[0]["x"] < labels["QUARTERLY"]["x"] < amounts[1]["x"]:
            continue
        candidates.append(
            {
                "left": labels["DATE"]["bbox"][0],
                "voucher_start": labels["VOUCHER"]["bbox"][0],
                "payee_start": labels["PAYEE"]["bbox"][0],
                "service_start": labels["SERVICE"]["bbox"][0],
                "service_end": (labels["SERVICE"]["bbox"][0] + labels["DESCRIPTION"]["bbox"][0]) / 2,
                "description_start": labels["DESCRIPTION"]["bbox"][0],
                "ytd_right": amounts[0]["bbox"][2],
                "quarterly_right": amounts[1]["bbox"][2],
                "body_top": max(word["bbox"][3] for word in band) + 1,
                "word_indices": [word["index"] for word in band],
            }
        )
    return candidates[0] if len(candidates) == 1 else None


def _money(line, right):
    found = []
    for word in line:
        if abs(word["bbox"][2] - right) > 1:
            continue
        value = parse_amount(word["text"].replace("–", "-").replace("−", "-"))
        if value is not None:
            found.append((word, value))
    if len(found) > 1:
        raise ValueError("Several House money tokens occupy the same printed column")
    return found[0] if found else (None, None)


def _printed_page(words, header, page_height):
    found = [
        word["text"].strip("()")
        for word in words
        if re.fullmatch(r"\(?[0-9]+\)?", word["text"])
        and abs(word["y"] - page_height / 2) <= 5
        and (
            header["left"] - 25 < word["x"] < header["left"]
            or header["quarterly_right"] < word["x"] < header["quarterly_right"] + 25
        )
    ]
    return found[0] if len(found) == 1 else None


def _ledger(words, header, source_page, state, period, century):
    selected = [
        word
        for word in words
        if word["bbox"][0] >= header["left"] - 1
        and word["bbox"][2] <= header["quarterly_right"] + 1
        and word["y"] > header["body_top"]
    ]
    lines, records = [], []
    for number, line in enumerate(visual_lines(selected), 1):
        text = literal(line)
        origin = {"source_page": source_page, "line": number}
        observed = {"line": number, "text": text, "word_indices": [word["index"] for word in line]}
        lines.append(observed)
        ytd_word, ytd = _money(line, header["ytd_right"])
        qtd_word, qtd = _money(line, header["quarterly_right"])
        if ytd is None and qtd is None:
            heading = re.sub(r"—Con\.\Z", "", text).strip()
            continued = heading != text
            indent = line[0]["bbox"][0] - header["left"]
            office = _OFFICE.fullmatch(heading)
            if office and abs(indent - 10) <= _HEADING_TOLERANCE:
                organization = office[3]
                year = ("FISCAL YEAR " if office[1] else "") + office[2]
                if not continued or (state["organization"], state["fiscal_or_legislative_year"]) != (
                    organization,
                    year,
                ):
                    state.update(program=None, cost_category=None, last_payee=None)
                state.update(organization=organization, fiscal_or_legislative_year=year, office_origin=origin)
                observed["role"] = "office_heading"
            elif abs(indent) <= _HEADING_TOLERANCE:
                if not continued or state["organizational_group"] != heading:
                    state.update(
                        organization=None,
                        fiscal_or_legislative_year=None,
                        program=None,
                        cost_category=None,
                        last_payee=None,
                    )
                state["organizational_group"] = heading
                observed["role"] = "group_heading"
            elif abs(indent - 20) <= _HEADING_TOLERANCE:
                if not continued or state["program"] != heading:
                    state["cost_category"] = None
                state["program"] = heading
                observed["role"] = "program_heading"
            elif abs(indent - 30) <= _HEADING_TOLERANCE:
                state["cost_category"] = heading
                observed["role"] = "category_heading"
            else:
                observed["role"] = "unassigned_text"
            continue
        money_indices = {word["index"] for word in (ytd_word, qtd_word) if word}
        content = [word for word in line if word["index"] not in money_indices]
        label = _clean(literal(content))
        raw = {
            "transaction_date": "",
            "data_source": "",
            "document": "",
            "vendor_name": "",
            "service_start_date": "",
            "service_end_date": "",
            "description": label,
            "ytd_amount": ytd_word["text"] if ytd_word else "",
            "qtd_amount": qtd_word["text"] if qtd_word else "",
        }
        issues, normalizations = [], []
        if label.endswith("TOTALS:"):
            kind = "organization_total" if label == "OFFICE TOTALS:" else "subtotal"
        elif ytd is not None:
            kind = "summary"
        else:
            kind = "transaction"
            left = [word for word in content if word["bbox"][0] < header["service_start"] - 1]
            posted = _POSTED.fullmatch(left[0]["text"]) if left else None
            has_posted = bool(posted and abs(left[0]["bbox"][0] - header["left"]) <= 1)
            # Transfers can leave every date cell blank while printing a data
            # source and voucher in their ordinary columns. Payroll names begin
            # at the left margin, so a blank date alone cannot select this form.
            blank_date_voucher = bool(
                left
                and left[0]["text"] in {"AP", "AR", "GL"}
                and header["left"] + 10 < left[0]["bbox"][0] < header["voucher_start"] - 1
                and any(header["voucher_start"] - 1 <= word["bbox"][0] < header["payee_start"] - 1 for word in left)
            )
            if has_posted or blank_date_voucher:
                raw["transaction_date"] = left[0]["text"] if has_posted else ""
                voucher_words = left[1:] if has_posted else left
                raw["data_source"] = literal(
                    [word for word in voucher_words if word["bbox"][0] < header["voucher_start"] - 1]
                )
                raw["document"] = literal(
                    [
                        word
                        for word in voucher_words
                        if header["voucher_start"] - 1 <= word["bbox"][0] < header["payee_start"] - 1
                    ]
                )
                vendor = [word for word in left if word["bbox"][0] >= header["payee_start"] - 1]
            else:
                vendor = left
            raw["vendor_name"] = literal(vendor)
            for field, low, high in (
                ("service_start_date", header["service_start"], header["service_end"]),
                ("service_end_date", header["service_end"], header["description_start"]),
                ("description", header["description_start"], header["quarterly_right"]),
            ):
                raw[field] = literal([word for word in content if low - 1 <= word["bbox"][0] < high - 1])
        values, field_issues = normalize_house_fields(raw, row_kind=kind, period=period, century=century)
        issues.extend(field_issues)
        if kind == "transaction":
            if values["vendor_name"] == "DO":
                values["vendor_name"], payee_audit = expand_house_ditto_payee(state["last_payee"])
                normalizations.extend(payee_audit)
                if state["last_payee"] is None:
                    issues.append("ditto_payee_without_prior_witness")
            else:
                state["last_payee"] = (
                    {"value": values["vendor_name"], "origin": origin} if values["vendor_name"] else None
                )
        if state["organization"] is None:
            issues.append("office_context_unresolved")
        if kind == "transaction":
            for field in ("program", "cost_category"):
                if state[field] is None:
                    issues.append(field + "_context_unresolved")
        record = {
            "line": number,
            "row_kind": kind,
            **{key: state[key] for key in _CONTEXT},
            **values,
            "amount": format(qtd, ".2f") if kind == "transaction" else None,
            "ytd_amount": format(ytd, ".2f") if ytd is not None else None,
            "qtd_amount": format(qtd, ".2f") if qtd is not None else None,
            "raw_fields": raw,
            "word_indices": observed["word_indices"],
            "office_origin": state.get("office_origin"),
            "normalizations": normalizations,
            "repairs": [],
            "issues": issues,
        }
        records.append(record)
        observed["role"] = kind
    return records, lines


def iter_house_disbursements_pages(
    body: bytes,
    *,
    report_period_start: date,
    report_period_end: date,
    pages=None,
    source_page_numbers=None,
    two_digit_year_century=2000,
):
    """Visit every selected page; never treat an unqualified image/OCR layer as payments."""
    import pymupdf

    if not 0 < len(body) <= MAX_BYTES or report_period_end < report_period_start:
        raise ValueError("House PDF byte bound or report period is invalid")
    if (
        type(two_digit_year_century) is not int
        or two_digit_year_century % 100
        or not 1900 <= two_digit_year_century <= 9900
    ):
        raise ValueError("House two-digit dates require an explicit whole century")
    sha = "sha256:" + hashlib.sha256(body).hexdigest()
    backend = version("pymupdf")
    previous = None
    state = {}
    with pymupdf.open(stream=body, filetype="pdf") as document:
        if document.needs_pass or len(document) > 10_000:
            raise ValueError("House PDF is encrypted or exceeds its page bound")
        selected = list(range(1, len(document) + 1)) if pages is None else list(pages)
        if (
            not selected
            or selected != sorted(set(selected))
            or any(type(n) is not int or not 1 <= n <= len(document) for n in selected)
        ):
            raise ValueError("Select distinct ascending House physical PDF pages")
        mapping = dict(source_page_numbers or {})
        if mapping and (
            set(mapping) != set(selected)
            or len(set(mapping.values())) != len(mapping)
            or any(type(n) is not int or n < 1 for n in mapping.values())
        ):
            raise ValueError("House excerpt mapping must uniquely name every selected original page")
        for number in selected:
            page = document[number - 1]
            source_page = mapping.get(number, number)
            words = display_words(page)
            header = _header(words) if len(words) <= 10_000 else None
            image_count = len(page.get_images())
            prior_header = previous["header"] if previous else None
            printed = _printed_page(words, header or prior_header, page.rect.height) if header or prior_header else None
            continuous = bool(
                previous
                and source_page == previous["source_page"] + 1
                and previous["printed_page"]
                and printed
                and int(printed) == int(previous["printed_page"]) + 1
                and list(page.rect) == previous["page_bbox"]
            )
            if not continuous:
                state = {**dict.fromkeys(_CONTEXT), "last_payee": None}
            header_basis = "printed_on_page"
            if header is None and continuous and not image_count and len(words) <= 10_000:
                # The print omits the entire header on continuation pages.
                # Carry its horizontal columns only across consecutive physical
                # AND printed pages of the same geometry, retaining that basis.
                header = {**prior_header, "body_top": 0, "word_indices": []}
                header_basis = "previous_contiguous_printed_page"
            result = {
                "rule": RULE,
                "pymupdf_version": backend,
                "source_sha256": sha,
                "page": number,
                "source_page": source_page,
                "physical_pages": len(document),
                "rotation": page.rotation,
                "page_bbox": list(page.rect),
                "text": page.get_text(),
                "words": words,
                "image_count": image_count,
                "header": header,
                "header_basis": header_basis if header else None,
                "printed_page": printed,
                "records": [],
                "lines": [],
                "issues": [],
            }
            if header is not None and not image_count:
                records, lines = _ledger(
                    words, header, source_page, state, (report_period_start, report_period_end), two_digit_year_century
                )
                result.update(records=records, lines=lines, status="ledger_read")
                previous = {
                    "source_page": source_page,
                    "printed_page": printed,
                    "page_bbox": list(page.rect),
                    "header": header,
                }
            else:
                result["status"] = "image_content_pending" if image_count else "non_ledger_content_pending"
                previous = None
            used = {index for line in result["lines"] for index in line["word_indices"]}
            result["outside_ledger_word_indices"] = [word["index"] for word in words if word["index"] not in used]
            apply_date_repairs(
                result,
                len(body),
                _DATE_REPAIRS,
                printed_page=printed,
                date_fields=("transaction_date", "service_start_date", "service_end_date"),
                service_fields=("service_start_date", "service_end_date"),
            )
            for row in result["records"]:
                if row["repairs"]:
                    future = bool(row["service_end_date"] and row["service_end_date"] > report_period_end.isoformat())
                    issue = "service_after_report_period"
                    if future and issue not in row["issues"]:
                        row["issues"].append(issue)
                    elif not future and issue in row["issues"]:
                        row["issues"].remove(issue)
                        row["repairs"][-1]["resolved_issues"].append(issue)
            yield result
