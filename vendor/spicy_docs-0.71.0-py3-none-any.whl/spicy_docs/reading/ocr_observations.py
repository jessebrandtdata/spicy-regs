"""Bind unplaced OCR text to an exact, measured source-image region.

Source readers decide which rows a region contains and how to associate them.
These shared objects retain input identity without assigning model geometry.
"""

from __future__ import annotations

import base64
import hashlib
import json
import re
from copy import deepcopy
from dataclasses import dataclass

from spicy_docs.extraction import Box, Raster
from spicy_docs.extraction.model import Observation, Recognition
from spicy_docs.extraction.pages import crop


def evidence_sha256(data):
    return "sha256:" + hashlib.sha256(data).hexdigest()


def box_coordinates(box):
    return [box.x0, box.y0, box.x1, box.y1]


@dataclass(frozen=True)
class OcrRegion:
    id: str
    raster: Raster
    row_ids: tuple[str, ...]
    field_block_index: int | None = None


@dataclass(frozen=True)
class OcrView:
    region: OcrRegion
    reading: Recognition | Observation

    @property
    def text(self):
        """Keep Docling's original VLM lines before Markdown conversion."""
        raw = self.reading.raw
        if isinstance(raw, dict) and "pages" in raw:
            pages = raw["pages"]
            if len(pages) != 1:
                raise ValueError("An OCR view must contain exactly one model page")
            response = pages[0].get("predictions", {}).get("vlm_response")
            if response is not None:
                return response["text"]
        if self.reading.text_format != "plain":
            raise ValueError("OCR association requires original plain model lines")
        return self.reading.text

    @property
    def evidence(self):
        return {
            "id": self.region.id,
            "input_sha256": evidence_sha256(self.region.raster.data),
            "response_text_sha256": evidence_sha256(self.text.encode()),
            "configuration_sha256": evidence_sha256(
                json.dumps(self.reading.configuration, sort_keys=True, separators=(",", ":")).encode()
            ),
            "region": box_coordinates(self.region.raster.box),
            "model_geometry": None,
        }


def validate_view_image(image, view):
    """Refuse claimed regions whose actual pixels differ from the source crop."""
    raster = view.region.raster
    expected = image if raster.box == Box() else crop(image, raster.box)
    if expected.data != raster.data or (expected.width, expected.height) != (raster.width, raster.height):
        raise ValueError("OCR view bytes do not match its claimed original-image crop")


def retained_structured_observation(result, image):
    """Read one pinned full-page Gemini observation, keeping geometry absent.

    Checks the actual encoded model input and response, not merely the echoed
    outcome. No source accuracy or review decision follows from this check.
    """
    from spicy_docs.extraction.gemini import read_structured_response

    observations = result.get("observations", [])
    if len(observations) != 1 or image.box != Box():
        raise ValueError("Structured replay requires one complete page observation")
    observation = observations[0]
    config = observation["configuration"]
    if config.get("backend") != "gemini" or config.get("mode") != "structured":
        raise ValueError("Structured replay requires the retained Gemini structured configuration")
    calls = observation["raw"]["calls"]
    if len(calls) != 1 or calls[0]["stage"] != "structured-page":
        raise ValueError("Structured replay requires one retained structured-page call")
    call = calls[0]
    schema = config["outcome_schema"]
    if (
        call["request"]["generationConfig"] != config["generation"]
        or config["generation"].get("responseJsonSchema") != schema
    ):
        raise ValueError("Structured replay configuration differs from its actual request")
    expected = [
        {
            "role": "user",
            "parts": [
                {"inlineData": {"mimeType": image.media_type, "data": base64.b64encode(image.data).decode()}},
                {"text": config["prompts"]["structured"]},
            ],
        }
    ]
    if call["request"]["contents"] != expected:
        raise ValueError("Structured replay image or prompt differs from the actual model input")
    text, outcome = read_structured_response(call["response"], schema)
    if text != observation["text"] or outcome != observation["raw"]["outcome"]:
        raise ValueError("Retained structured outcome differs from its model response")
    images = observation["images"]
    if len(images) != 1 or any(
        images[0].get(key) != value
        for key, value in {
            "sha256": hashlib.sha256(image.data).hexdigest(),
            "bytes": len(image.data),
            "width": image.width,
            "height": image.height,
            "box": {"x0": 0, "y0": 0, "x1": 1, "y1": 1},
        }.items()
    ):
        raise ValueError("Retained structured image declaration differs from its exact input")
    if observation.get("issues") or outcome.get("uncertainties"):
        raise ValueError("Structured observation has unresolved recognition issues")
    return outcome, config


def apply_reviewed_observation_fields(outcome, *, binding, corrections):
    """Apply exactly reviewed existing fields to a copy; retain raw observations.

    This is the unpositioned equivalent of the manual OCR transcription guard:
    source/image/model identities and exact before values must all match. It
    supplies no geometry, review decision, or automatic recognition credit.
    """
    normalized, audit, paths = deepcopy(outcome), [], []
    for rule in corrections:
        if rule.get("method") != "manual_review" or any(rule.get(key) != value for key, value in binding.items()):
            raise ValueError("Reviewed observation correction differs from its source/image/model binding")
        if not rule.get("reason") or not rule.get("review_evidence") or not rule.get("edits"):
            raise ValueError("Reviewed observation correction lacks its reason, review or edits")
        for review in rule["review_evidence"]:
            if not re.fullmatch(r"sha256:[0-9a-f]{64}", review.get("sha256", "")):
                raise ValueError("Reviewed observation correction requires exact independent review pins")
        for edit in rule["edits"]:
            path = edit["path"]
            if not isinstance(path, list) or not path or any(type(key) not in {int, str} for key in path):
                raise ValueError("Reviewed observation correction requires an explicit field path")
            if any(path[: len(prior)] == prior or prior[: len(path)] == path for prior in paths):
                raise ValueError("Reviewed observation correction repeats or overlaps an edited field")
            target = normalized
            try:
                for key in path[:-1]:
                    if isinstance(key, int) and key < 0:
                        raise KeyError(key)
                    target = target[key]
                key = path[-1]
                if isinstance(key, int) and key < 0:
                    raise KeyError(key)
                if target[key] != edit["before"] or type(edit["after"]) is not type(edit["before"]):
                    raise ValueError("Reviewed observation correction differs from its exact before value")
                target[key] = deepcopy(edit["after"])
            except (KeyError, IndexError, TypeError):
                raise ValueError("Reviewed observation correction names a missing field") from None
            paths.append(path)
        audit.append(deepcopy(rule))
    return normalized, audit
